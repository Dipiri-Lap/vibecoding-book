# 프로젝트 규칙 (habit-tracker-cloud)

## 작업 범위
- 이 폴더(C:\vibecoding\habit-tracker-cloud) 안에서만 작업한다.

## 보고
- 보고는 한국어로, 쉬운 말로 한다.

## 비밀 정보
- .env 파일은 절대 열지 않고, 내용을 출력하지 않는다.
- 관리자용 키(service_role, secret)는 쓰지도, 요구하지도 않는다.
- 시험 계정 비밀번호는 화면, 로그, 보고 어디에도 나오면 안 된다.

## 저장(git)
- 저장(commit)은 사용자가 내용을 확인한 뒤에 한다.
