-- 습관 트래커 표 만들기 (Supabase SQL Editor에 통째로 붙여 넣고 Run)
-- 여러 번 실행해도 괜찮게 만들었습니다.

-- ===== 1. 표 =====
create table if not exists public.habits (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null default auth.uid()
             references auth.users (id) on delete cascade,
  name       text not null check (char_length(btrim(name)) between 1 and 50),
  created_at timestamptz not null default now(),
  -- habit_checks가 "같은 주인의 습관"만 가리키게 하려는 장치
  unique (id, user_id)
);

create table if not exists public.habit_checks (
  id         uuid primary key default gen_random_uuid(),
  habit_id   uuid not null,
  user_id    uuid not null default auth.uid(),
  check_date date not null default current_date,
  created_at timestamptz not null default now(),
  unique (habit_id, check_date),
  -- 남의 습관에 내 이름으로 체크를 달 수 없게 막음. 습관이 지워지면 체크도 같이 지워짐
  foreign key (habit_id, user_id)
    references public.habits (id, user_id) on delete cascade
);

create index if not exists habit_checks_user_idx on public.habit_checks (user_id);

-- ===== 2. 습관은 사람당 최대 5개 (서버에서 강제) =====
create or replace function public.limit_habits_per_user()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  -- 동시에 여러 개를 넣어도 5개를 넘지 못하게 사람별로 줄을 세움
  perform pg_advisory_xact_lock(hashtext(new.user_id::text));
  if (select count(*) from public.habits where user_id = new.user_id) >= 5 then
    raise exception '습관은 최대 5개까지 만들 수 있습니다.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

drop trigger if exists habits_limit on public.habits;
create trigger habits_limit
  before insert on public.habits
  for each row execute function public.limit_habits_per_user();

-- ===== 3. 권한: 로그인하지 않은 사람(anon)은 아무것도 못 함 =====
revoke all on public.habits       from anon;
revoke all on public.habit_checks from anon;
grant select, insert, update, delete on public.habits       to authenticated;
grant select, insert, update, delete on public.habit_checks to authenticated;

-- ===== 4. RLS: 자기 것만 =====
alter table public.habits       enable row level security;
alter table public.habit_checks enable row level security;
alter table public.habits       force row level security;
alter table public.habit_checks force row level security;

drop policy if exists habits_select on public.habits;
drop policy if exists habits_insert on public.habits;
drop policy if exists habits_update on public.habits;
drop policy if exists habits_delete on public.habits;

create policy habits_select on public.habits
  for select to authenticated using (user_id = (select auth.uid()));
create policy habits_insert on public.habits
  for insert to authenticated with check (user_id = (select auth.uid()));
create policy habits_update on public.habits
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));
create policy habits_delete on public.habits
  for delete to authenticated using (user_id = (select auth.uid()));

drop policy if exists checks_select on public.habit_checks;
drop policy if exists checks_insert on public.habit_checks;
drop policy if exists checks_update on public.habit_checks;
drop policy if exists checks_delete on public.habit_checks;

create policy checks_select on public.habit_checks
  for select to authenticated using (user_id = (select auth.uid()));
create policy checks_insert on public.habit_checks
  for insert to authenticated with check (user_id = (select auth.uid()));
create policy checks_update on public.habit_checks
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));
create policy checks_delete on public.habit_checks
  for delete to authenticated using (user_id = (select auth.uid()));
