// 실제 Supabase에서 "내 것만 보이고 고쳐진다"를 시험 계정 A, B로 확인합니다.
// 실행: node test-rls.js
// 값은 .env 에서 읽고, 비밀번호/키는 화면에 출력하지 않습니다.
// 시험이 만드는 습관은 끝에 모두 지웁니다(시험 계정 둘의 습관만 건드림).
const fs = require('fs');
const path = require('path');

const env = {};
for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
  const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if (m) env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
}
for (const k of ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'TEST_A_EMAIL', 'TEST_A_PASSWORD', 'TEST_B_EMAIL', 'TEST_B_PASSWORD']) {
  if (!env[k]) { console.error('.env 에 ' + k + ' 가 없습니다.'); process.exit(1); }
}
const URL_ = env.SUPABASE_URL.replace(/\/+$/, '');
const KEY = env.SUPABASE_ANON_KEY;

async function login(email, password) {
  const r = await fetch(URL_ + '/auth/v1/token?grant_type=password', {
    method: 'POST',
    headers: { apikey: KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const j = await r.json();
  if (!j.access_token) throw new Error('시험 계정 로그인 실패 (HTTP ' + r.status + ')');
  return { token: j.access_token, id: j.user.id };
}

// token 이 null 이면 로그인하지 않은 사람(anon 키만 사용)
async function rest(token, method, pathQuery, body) {
  const r = await fetch(URL_ + '/rest/v1/' + pathQuery, {
    method,
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + (token || KEY),
      'Content-Type': 'application/json',
      Prefer: 'return=representation'
    },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let data = null;
  try { data = await r.json(); } catch {}
  return { status: r.status, ok: r.ok, data };
}
const rows = (res) => (res.ok && Array.isArray(res.data) ? res.data : []);

let pass = 0, fail = 0;
function check(name, cond) {
  if (cond) { pass++; console.log('  통과  ' + name); }
  else { fail++; console.log('  실패  ' + name); }
}

async function wipe(u) {
  // 내 습관을 지우면 체크도 같이 지워짐
  await rest(u.token, 'DELETE', 'habits?user_id=eq.' + u.id);
}

(async () => {
  const A = await login(env.TEST_A_EMAIL, env.TEST_A_PASSWORD);
  const B = await login(env.TEST_B_EMAIL, env.TEST_B_PASSWORD);
  check('시험 계정 A, B가 서로 다른 사람', A.id !== B.id);
  await wipe(A); await wipe(B);

  try {
    console.log('\n[준비] A가 습관과 체크를 만든다');
    const ha = await rest(A.token, 'POST', 'habits', { name: 'A의 습관' });
    check('A가 자기 습관을 만들 수 있다', ha.ok && rows(ha).length === 1);
    const habitA = rows(ha)[0];
    const ca = await rest(A.token, 'POST', 'habit_checks', { habit_id: habitA.id, check_date: '2030-01-01' });
    check('A가 자기 습관에 체크할 수 있다', ca.ok && rows(ca).length === 1);
    const checkA = rows(ca)[0];
    const hb = await rest(B.token, 'POST', 'habits', { name: 'B의 습관' });
    check('B가 자기 습관을 만들 수 있다', hb.ok && rows(hb).length === 1);
    const habitB = rows(hb)[0];

    console.log('\n[보기] B는 A의 것을 볼 수 없다');
    check('B의 습관 목록에 A의 습관이 없다',
      !rows(await rest(B.token, 'GET', 'habits?select=id')).some((r) => r.id === habitA.id));
    check('B가 A의 습관 id로 직접 조회해도 안 나온다',
      rows(await rest(B.token, 'GET', 'habits?id=eq.' + habitA.id)).length === 0);
    check('B의 체크 목록에 A의 체크가 없다',
      !rows(await rest(B.token, 'GET', 'habit_checks?select=id')).some((r) => r.id === checkA.id));
    check('B가 A의 체크 id로 직접 조회해도 안 나온다',
      rows(await rest(B.token, 'GET', 'habit_checks?id=eq.' + checkA.id)).length === 0);
    check('B가 A의 user_id로 조회해도 안 나온다',
      rows(await rest(B.token, 'GET', 'habits?user_id=eq.' + A.id)).length === 0 &&
      rows(await rest(B.token, 'GET', 'habit_checks?user_id=eq.' + A.id)).length === 0);

    console.log('\n[고치기] B는 A의 것을 바꾸거나 지울 수 없다');
    check('B가 A의 습관 이름을 바꿔도 0건',
      rows(await rest(B.token, 'PATCH', 'habits?id=eq.' + habitA.id, { name: '해킹' })).length === 0);
    check('B가 A의 습관을 지워도 0건',
      rows(await rest(B.token, 'DELETE', 'habits?id=eq.' + habitA.id)).length === 0);
    check('B가 A의 체크를 바꿔도 0건',
      rows(await rest(B.token, 'PATCH', 'habit_checks?id=eq.' + checkA.id, { check_date: '2030-02-02' })).length === 0);
    check('B가 A의 체크를 지워도 0건',
      rows(await rest(B.token, 'DELETE', 'habit_checks?id=eq.' + checkA.id)).length === 0);
    const still = rows(await rest(A.token, 'GET', 'habits?id=eq.' + habitA.id));
    const stillC = rows(await rest(A.token, 'GET', 'habit_checks?id=eq.' + checkA.id));
    check('A의 습관은 그대로 남아 있다', still.length === 1 && still[0].name === 'A의 습관');
    check('A의 체크는 그대로 남아 있다', stillC.length === 1 && stillC[0].check_date === '2030-01-01');

    console.log('\n[끼어들기] B는 A의 이름으로 만들 수 없다');
    check('B가 user_id를 A로 해서 습관을 만들 수 없다',
      !(await rest(B.token, 'POST', 'habits', { name: '가짜', user_id: A.id })).ok);
    check('B가 A의 습관에 B 이름으로 체크를 달 수 없다',
      !(await rest(B.token, 'POST', 'habit_checks', { habit_id: habitA.id, check_date: '2030-03-03' })).ok);
    check('B가 A의 습관에 A 이름으로 체크를 달 수 없다',
      !(await rest(B.token, 'POST', 'habit_checks', { habit_id: habitA.id, user_id: A.id, check_date: '2030-03-04' })).ok);
    check('B가 자기 습관의 주인을 A로 바꿀 수 없다',
      rows(await rest(B.token, 'PATCH', 'habits?id=eq.' + habitB.id, { user_id: A.id })).length === 0);
    check('A의 체크 수가 늘지 않았다',
      rows(await rest(A.token, 'GET', 'habit_checks?habit_id=eq.' + habitA.id)).length === 1);

    console.log('\n[로그인 안 한 사람] 두 표 모두 보거나 바꿀 수 없다');
    for (const t of ['habits', 'habit_checks']) {
      check(t + ': 조회해도 아무것도 안 나온다', rows(await rest(null, 'GET', t)).length === 0);
      check(t + ': 만들 수 없다',
        !(await rest(null, 'POST', t, t === 'habits'
          ? { name: '익명', user_id: A.id }
          : { habit_id: habitA.id, user_id: A.id, check_date: '2030-04-04' })).ok);
      check(t + ': 바꿔도 0건', rows(await rest(null, 'PATCH', t + '?id=not.is.null',{ created_at: '2000-01-01' })).length === 0);
      check(t + ': 지워도 0건', rows(await rest(null, 'DELETE', t + '?id=not.is.null')).length === 0);
    }
    check('익명 시도 뒤에도 A의 데이터가 그대로다',
      rows(await rest(A.token, 'GET', 'habits?id=eq.' + habitA.id)).length === 1 &&
      rows(await rest(A.token, 'GET', 'habit_checks?id=eq.' + checkA.id)).length === 1);

    console.log('\n[5개 제한]');
    let made = 1;
    for (let i = 2; i <= 5; i++) if ((await rest(A.token, 'POST', 'habits', { name: 'A' + i })).ok) made++;
    check('5개까지는 만들어진다', made === 5);
    check('6번째는 거절된다', !(await rest(A.token, 'POST', 'habits', { name: 'A6' })).ok);
    check('A의 습관은 5개다', rows(await rest(A.token, 'GET', 'habits?select=id')).length === 5);

    console.log('\n[지우기] 습관을 지우면 체크도 같이 지워진다');
    await rest(A.token, 'DELETE', 'habits?id=eq.' + habitA.id);
    check('A의 체크가 같이 사라졌다',
      rows(await rest(A.token, 'GET', 'habit_checks?id=eq.' + checkA.id)).length === 0);
  } finally {
    await wipe(A); await wipe(B);
  }

  console.log('\n결과: 통과 ' + pass + ', 실패 ' + fail);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('시험 중단: ' + e.message); process.exit(1); });
