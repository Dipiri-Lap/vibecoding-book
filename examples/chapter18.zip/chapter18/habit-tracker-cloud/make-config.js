// .env 의 SUPABASE_URL, SUPABASE_ANON_KEY 두 값만 config.js 로 복사합니다.
// 실행: node make-config.js   (값은 화면에 출력하지 않습니다)
const fs = require('fs');
const path = require('path');

const envText = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
const env = {};
for (const line of envText.split(/\r?\n/)) {
  const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if (m) env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
}

const url = env.SUPABASE_URL;
const key = env.SUPABASE_ANON_KEY;
if (!url || !key) {
  console.error('.env 에서 SUPABASE_URL 또는 SUPABASE_ANON_KEY 를 찾지 못했습니다.');
  process.exit(1);
}
// 관리자용 키를 실수로 넣었다면 복사하지 않고 멈춤
if (/service_role|sb_secret_/.test(key) || key.split('.').length === 3 &&
    (() => { try { return JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString()).role === 'service_role'; } catch { return false; } })()) {
  console.error('SUPABASE_ANON_KEY 가 관리자용 키로 보입니다. 복사하지 않고 멈춥니다.');
  process.exit(1);
}

fs.writeFileSync(
  path.join(__dirname, 'config.js'),
  `// make-config.js 가 만든 파일입니다. 공개 키(publishable)만 들어 있습니다.\nwindow.APP_CONFIG = ${JSON.stringify({ url, anonKey: key }, null, 2)};\n`
);
console.log('config.js 를 만들었습니다.');
