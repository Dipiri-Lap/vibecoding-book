'use strict';
// game/index.html 안의 <script id="engine"> 블록(화면 없는 게임 규칙)을 꺼내서 돌려준다.
// 브라우저가 쓰는 규칙과 봇/난이도 표가 쓰는 규칙이 같은 코드가 되도록 하는 장치.
const fs = require('fs');
const path = require('path');

const HTML_PATH = path.join(__dirname, '..', 'game', 'index.html');

function readHtml() {
  return fs.readFileSync(HTML_PATH, 'utf8');
}

function extractScript(html, id) {
  const m = html.match(new RegExp('<script id="' + id + '">([\\s\\S]*?)</script>'));
  if (!m) throw new Error('index.html 에서 <script id="' + id + '"> 를 찾지 못했습니다');
  return m[1];
}

function loadEngine() {
  const code = extractScript(readHtml(), 'engine');
  const fakeWindow = {};
  new Function('window', code)(fakeWindow);
  if (!fakeWindow.SansinEngine) throw new Error('엔진이 SansinEngine 을 내보내지 않았습니다');
  return fakeWindow.SansinEngine;
}

module.exports = { loadEngine, readHtml, extractScript, HTML_PATH };
