# 그림 출처와 라이선스 (CREDITS)

이 게임에 쓴 그림은 모두 **Kenney (www.kenney.nl)** 가 만든 것이고,
**CC0 (Creative Commons Zero, 퍼블릭 도메인)** 라서 상업적으로도 자유롭게 쓸 수 있습니다.
(출처 표시는 필수가 아니지만, 고마운 마음으로 적어 둡니다.)
라이선스 원문: http://creativecommons.org/publicdomain/zero/1.0/

| 묶음 | 파일 | 만든 사람 / 출처 | 라이선스 | 어디에 썼나 |
|---|---|---|---|---|
| Tiny Dungeon (1.0) | `game/assets/kenney-tiny-dungeon/tilemap_packed.png` | Kenney — https://www.kenney.nl | CC0 | 주인공, 적, 보석, 무기 |
| Particle Pack (1.1) | `game/assets/kenney-particle-pack/fx_atlas.png` | Kenney Vleugels (Kenney) — https://www.kenney.nl | CC0 | 쓰러질 때 터지는 효과 |

각 묶음의 `License.txt` 가 같은 폴더에 들어 있으며, 위 내용은 그 파일을 기준으로 적었습니다.
`fx_atlas.png` 는 Particle Pack 의 그림 6장을 가로로 이어 붙인 것입니다.
(Particle Pack License.txt 의 추가 감사: Indigo Ray, Craig Nisbet, Zoltan Erdokovy, Heliagon, ThreeDee, Killst4r, Tim2501 — 필터 틀 제작)

---

## ⑤ UI(단추·창·바·글꼴)

| 묶음 | 파일 | 만든 사람 / 출처 | 라이선스 | 어디에 썼나 |
|---|---|---|---|---|
| UI Pack - Pixel Adventure (2.0) | `game/assets/kenney-ui-pixel-adventure/large_*.png`, `small_*.png` (원본 `Tiles/…/Thick outline/tile_*.png` 중 9장) | Kenney — https://www.kenney.nl/assets/ui-pack-pixel-adventure | CC0 | 위쪽 정보 판, 체력·경험치·보스 체력 바 틀, 보스 이름표, 창 테두리, 단추 |
| 갈무리 Galmuri v2.40.4 | `game/assets/galmuri/Galmuri11.woff2`, `Galmuri11-Bold.woff2` | Lee Minseo (quiple) — https://github.com/quiple/galmuri | SIL Open Font License 1.1 (SIL OFL) | 게임 안의 모든 글자 |

- UI Pack 의 `License.txt` 는 `game/assets/kenney-ui-pixel-adventure/License.txt` 에 있습니다.
  "License: (Creative Commons Zero, CC0)" / "You can use this content for personal, educational, and commercial purposes."
- 갈무리의 `LICENSE.txt` 는 `game/assets/galmuri/LICENSE.txt` 에 같이 넣었습니다(OFL 은 글꼴을 다시 나눠 줄 때 저작권 문구와 라이선스 사본을 함께 넣도록 요구합니다).
  "Copyright (c) 2019–2025 Lee Minseo (quiple@quiple.dev)" / "This font software is licensed under the SIL Open Font License, Version 1.1."
