# -*- coding: utf-8 -*-
"""정리 전후 결과가 똑같은지 확인하는 도구 (읽기 전용 확인용)

폴더를 임시 위치에 복사해서 거기서 주간 보고서·대시보드·예산 계산·테스트를 돌리고,
결과를 '기준선' 폴더에 저장해 둔 정리 전 결과와 비교합니다.
원래 폴더의 파일은 바꾸지 않습니다.

  python check_same.py          # 지금 코드의 결과 = 기준선인지 비교
  python check_same.py --save   # 지금 결과를 기준선으로 저장 (정리를 시작하기 전에만!)

비교 대상
  주간보고_43주/44주.xlsx : 모든 칸의 값 (파일 만든 시각 같은 건 비교하지 않음)
  검산_43주/44주.txt, 대시보드 화면 파일, 두 프로그램의 화면 출력, 예산 계산 결과, 예산 테스트 출력
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import openpyxl

BASE = Path(__file__).resolve().parent
BASELINE = BASE / "기준선"
SKIP = {".git", "기준선", "__pycache__", "node_modules"}

NODE_DUMP = r"""
const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync(process.argv[2],'utf8');
const m=html.match(/<script id="budget-calc">([\s\S]*?)<\/script>/);
const sb={module:{exports:{}}};vm.runInNewContext(m[1],sb);
const {calcBudget,ratioMessage,DEFAULT_CHANNELS}=sb.module.exports;
const ch=(a,b,c,cpa)=>{cpa=cpa||DEFAULT_CHANNELS.map(x=>x.cpa);return [a,b,c].map((r,i)=>({name:DEFAULT_CHANNELS[i].name,ratio:r,cpa:cpa[i]}));};
const cases=[[1000,40,30,30],[250,0,0,100],[777,33.3,33.3,33.4],[12345,12.5,62.5,25],[999,0.1,0.1,99.8],
 [1000,40,30,20],[1000,50,30,30],[1000,0,0,0],[0,40,30,30],[-5,40,30,30],[NaN,40,30,30],[1,40,30,30]];
const out={defaults:DEFAULT_CHANNELS,cases:cases.map(c=>{const r=calcBudget(c[0],ch(c[1],c[2],c[3]));
  return {in:c.map(x=>String(x)),r:JSON.parse(JSON.stringify(r,(k,v)=>typeof v==='number'&&!isFinite(v)?String(v):v)),
          msg:r.ratioSum!==undefined?ratioMessage(r.ratioSum):null};})};
out.custom=calcBudget(1000,ch(40,30,30,[9000,14417,15653]));
console.log(JSON.stringify(out,null,1));
"""


def run(cmd, cwd):
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, env=env)
    return (p.stdout.decode("utf-8", "replace") + p.stderr.decode("utf-8", "replace")), p.returncode


def dump_xlsx(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    out = {}
    for ws in wb.worksheets:
        out[ws.title] = {c.coordinate: c.value for row in ws.iter_rows() for c in row if c.value is not None}
    wb.close()
    return out


def collect(work, dest):
    """work 폴더(복사본)에서 프로그램을 돌려 dest 폴더에 결과를 쓴다."""
    dest.mkdir(parents=True, exist_ok=True)
    norm = lambda s: s.replace(str(work), "<폴더>").replace(str(work).replace("\\", "/"), "<폴더>")
    for wk in (43, 44):
        text, code = run([sys.executable, "weekly_report.py", "--week", str(wk)], work)
        text = re.sub(r"주간보고_\d+주_백업_\d{8}-\d{6}\.xlsx", "주간보고_NN주_백업_<시각>.xlsx", text)
        (dest / f"weekly_{wk}_stdout.txt").write_text(norm(text) + f"\n[종료코드 {code}]\n", encoding="utf-8")
        (dest / f"검산_{wk}주.txt").write_text(norm((work / "보고서" / f"검산_{wk}주.txt").read_text(encoding="utf-8")),
                                             encoding="utf-8")
        (dest / f"주간보고_{wk}주_칸값.json").write_text(
            json.dumps(dump_xlsx(work / "보고서" / f"주간보고_{wk}주.xlsx"), ensure_ascii=False, indent=1, sort_keys=True),
            encoding="utf-8")
    out_html = work / "dashboard_check.html"
    text, code = run([sys.executable, "dashboard.py", "--out", str(out_html)], work)
    (dest / "dashboard_stdout.txt").write_text(norm(text) + f"\n[종료코드 {code}]\n", encoding="utf-8")
    shutil.copyfile(out_html, dest / "dashboard_결과.html")
    (work / "_dump.js").write_text(NODE_DUMP, encoding="utf-8")
    text, code = run(["node", "_dump.js", "budget.html"], work)
    (dest / "budget_계산결과.json").write_text(text, encoding="utf-8")
    text, code = run(["node", "test_budget.js"], work)
    (dest / "test_budget_출력.txt").write_text(text + f"\n[종료코드 {code}]\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--save", action="store_true", help="지금 결과를 기준선으로 저장")
    args = ap.parse_args()

    tmp = Path(tempfile.mkdtemp(prefix="haneul_check_"))
    try:
        work = tmp / "work"
        shutil.copytree(BASE, work, ignore=lambda d, names: [n for n in names if n in SKIP or n.endswith(".pyc")])
        now = tmp / "now"
        collect(work, now)
        if args.save:
            if BASELINE.exists():
                shutil.rmtree(BASELINE)
            shutil.copytree(now, BASELINE)
            print(f"기준선 저장: {BASELINE} ({len(list(BASELINE.iterdir()))}개 파일)")
            return 0
        if not BASELINE.is_dir():
            print("[오류] 기준선 폴더가 없습니다. 정리 전에 python check_same.py --save 를 먼저 하세요.")
            return 2
        bad = 0
        for f in sorted(BASELINE.iterdir()):
            g = now / f.name
            if not g.exists():
                print(f"NG  없음: {f.name}"); bad += 1
            elif f.read_bytes() != g.read_bytes():
                print(f"NG  다름: {f.name}"); bad += 1
            else:
                print(f"OK  같음: {f.name}")
        for g in sorted(now.iterdir()):
            if not (BASELINE / g.name).exists():
                print(f"NG  새로 생김: {g.name}"); bad += 1
        print(f"\n결과: {'모두 같음' if not bad else f'다른 항목 {bad}개 — 위 NG 줄을 확인하세요'}")
        return 1 if bad else 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
