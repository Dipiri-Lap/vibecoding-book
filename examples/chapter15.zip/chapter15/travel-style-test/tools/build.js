// site/index.html 과 site/result/*.html 을 site/js/data.js 내용으로 생성합니다.
// 실행: node tools/build.js
'use strict';
const fs = require('fs');
const path = require('path');
const T = require('../site/js/data.js');

const SITE = path.join(__dirname, '..', 'site');
const CSS_VER = '1';

function esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

const FAVICON =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ctext y='.9em' font-size='90'%3E%E2%9C%88%EF%B8%8F%3C/text%3E%3C/svg%3E";

function head({ title, desc, url, image, imageAlt, base }) {
  return `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="light">
<meta name="theme-color" content="#FFF8F0">
<meta name="referrer" content="no-referrer">
<meta name="robots" content="index, follow">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${esc(url)}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="${esc(T.HOME.title)}">
<meta property="og:locale" content="ko_KR">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${esc(url)}">
<meta property="og:image" content="${esc(image)}">
<meta property="og:image:secure_url" content="${esc(image)}">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="${esc(imageAlt)}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(title)}">
<meta name="twitter:description" content="${esc(desc)}">
<meta name="twitter:image" content="${esc(image)}">
<link rel="icon" href="${FAVICON}">
<link rel="stylesheet" href="${base}css/style.css?v=${CSS_VER}">`;
}

function indexPage() {
  const url = T.SITE_URL + '/';
  const emojis = T.TYPE_ORDER.map((t) => `<span>${T.RESULTS[t].emoji}</span>`).join('');
  return `<!doctype html>
<html lang="ko">
<head>
${head({
  title: T.HOME.title,
  desc: T.HOME.ogDesc,
  url,
  image: T.SITE_URL + '/img/og-home.png',
  imageAlt: T.HOME.title,
  base: ''
})}
</head>
<body class="page-home">
<main class="app">
  <section id="start" class="screen screen-start" aria-labelledby="start-title">
    <div class="start-top">
      <div class="emoji-row" aria-hidden="true">${emojis}</div>
      <h1 id="start-title">나의 여행 스타일<br>테스트</h1>
      <p class="lead">8개 질문으로 알아보는 나의 여행 유형!<br>나는 플래너일까, 모험가일까?</p>
    </div>
    <div class="bottom">
      <button type="button" id="start-btn" class="btn btn-primary">테스트 시작하기</button>
      <p class="note">이름·연락처는 묻지 않아요. 답변은 어디에도 저장되거나 전송되지 않아요.</p>
    </div>
  </section>

  <section id="quiz" class="screen screen-quiz" hidden aria-live="polite">
    <div class="quiz-top">
      <div class="quiz-bar">
        <button type="button" id="back-btn" class="btn-back" aria-label="이전 질문">‹ 이전</button>
        <span id="progress-text" class="progress-text">1 / ${T.QUESTIONS.length}</span>
      </div>
      <div class="progress" aria-hidden="true"><div id="progress-fill" class="progress-fill"></div></div>
    </div>
    <div class="question-wrap">
      <p id="q-num" class="q-num">Q1</p>
      <h2 id="q-text" class="q-text" tabindex="-1"></h2>
    </div>
    <div id="options" class="options bottom"></div>
  </section>

  <noscript><p class="noscript">이 테스트는 자바스크립트가 켜져 있어야 동작해요.</p></noscript>
</main>
<script src="js/data.js"></script>
<script src="js/quiz.js"></script>
</body>
</html>
`;
}

function resultPage(type) {
  const r = T.RESULTS[type];
  const url = T.SITE_URL + '/' + T.resultPath(type);
  const mate = T.RESULTS[r.mate.type];
  const traits = r.traits.map((t) => `<li>${esc(t)}</li>`).join('\n        ');
  const places = r.places
    .map(
      (p) => `<li class="place">
          <span class="place-label">${esc(p.label)}</span>
          <strong class="place-name">${esc(p.name)}</strong>
          <span class="place-why">${esc(p.why)}</span>
        </li>`
    )
    .join('\n        ');
  const others = T.TYPE_ORDER.filter((t) => t !== type)
    .map((t) => {
      const o = T.RESULTS[t];
      return `<li><a class="other" href="${t}.html" style="--c:${o.color};--soft:${o.soft}">
          <span class="other-emoji" aria-hidden="true">${o.emoji}</span>
          <span class="other-text"><strong>${esc(o.name)}</strong><small>${esc(o.summary)}</small></span>
        </a></li>`;
    })
    .join('\n        ');

  return `<!doctype html>
<html lang="ko">
<head>
${head({
  title: r.ogTitle,
  desc: r.ogDesc,
  url,
  image: T.SITE_URL + '/img/og-' + type + '.png',
  imageAlt: r.emoji + ' ' + r.name + ' — ' + r.summary,
  base: '../'
})}
</head>
<body class="page-result" data-type="${type}" data-share-url="${esc(url)}" data-share-title="${esc(r.ogTitle)}" data-share-text="${esc(r.ogDesc)}" style="--c:${r.color};--soft:${r.soft}">
<main class="app result">
  <header class="result-head">
    <a class="brand" href="../index.html">✈️ 나의 여행 스타일 테스트</a>
  </header>

  <section class="hero" aria-labelledby="result-name">
    <p id="result-intro" class="intro">친구의 여행 스타일은</p>
    <div class="hero-emoji" aria-hidden="true">${r.emoji}</div>
    <h1 id="result-name" class="result-name">${esc(r.name)}</h1>
    <p class="summary">${esc(r.summary)}</p>
  </section>

  <section class="card" aria-labelledby="traits-title">
    <h2 id="traits-title">이런 특징이 있어요</h2>
    <ul class="traits">
        ${traits}
    </ul>
  </section>

  <section class="card" aria-labelledby="mate-title">
    <h2 id="mate-title">잘 맞는 여행 메이트</h2>
    <a class="mate" href="${r.mate.type}.html" style="--c:${mate.color};--soft:${mate.soft}">
      <span class="mate-emoji" aria-hidden="true">${mate.emoji}</span>
      <span class="mate-text"><strong>${esc(mate.name)}</strong><small>${esc(r.mate.reason)}</small></span>
    </a>
  </section>

  <section class="card" aria-labelledby="places-title">
    <h2 id="places-title">추천 여행지</h2>
    <ul class="places">
        ${places}
    </ul>
  </section>

  <section class="actions" aria-label="공유와 다시 하기">
    <div id="actions-mine" hidden>
      <button type="button" class="btn btn-primary js-share">친구에게 공유하기</button>
      <a class="btn btn-secondary" href="../index.html?start=1">다시 하기</a>
    </div>
    <div id="actions-friend">
      <a class="btn btn-primary" href="../index.html?start=1">나도 테스트 해보기</a>
      <button type="button" class="btn btn-secondary js-share">이 결과 공유하기</button>
    </div>
  </section>

  <section class="card others" aria-labelledby="others-title">
    <h2 id="others-title">다른 유형 보기</h2>
    <ul class="other-list">
        ${others}
    </ul>
  </section>

  <p class="note foot">이름·연락처는 받지 않으며, 답변은 저장되거나 전송되지 않아요.</p>
</main>
<div id="toast" class="toast" role="status" aria-live="polite" hidden></div>
<script src="../js/result.js"></script>
</body>
</html>
`;
}

function build() {
  fs.mkdirSync(path.join(SITE, 'result'), { recursive: true });
  fs.writeFileSync(path.join(SITE, 'index.html'), indexPage());
  for (const t of T.TYPE_ORDER) {
    fs.writeFileSync(path.join(SITE, T.resultPath(t)), resultPage(t));
  }
}

module.exports = { indexPage, resultPage, build };

if (require.main === module) {
  build();
  console.log('built: index.html + ' + T.TYPE_ORDER.length + ' result pages');
}
