// 카카오톡 미리보기용 PNG(1200×630) 5장을 site/img/ 에 만듭니다.
// 이 PC의 Edge(또는 Chrome)를 화면 없이 실행해 HTML을 캡처합니다. 인터넷 연결은 쓰지 않습니다.
// 실행: node tools/make-images.js
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const T = require('../site/js/data.js');

const OUT = path.join(__dirname, '..', 'site', 'img');
const W = 1200;
const H = 630;

const BROWSERS = [
  process.env.BROWSER_PATH,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
].filter(Boolean);

function findBrowser() {
  const found = BROWSERS.find((p) => fs.existsSync(p));
  if (!found) throw new Error('Edge/Chrome을 찾지 못했어요. BROWSER_PATH 환경 변수로 경로를 알려 주세요.');
  return found;
}

const BASE_CSS = `
*{box-sizing:border-box;margin:0}
html,body{width:${W}px;height:${H}px;overflow:hidden}
body{font-family:"Malgun Gothic","Apple SD Gothic Neo","Noto Sans KR",sans-serif;color:#2A2420;
  display:flex;align-items:center;justify-content:center;word-break:keep-all}
.frame{position:absolute;inset:28px;border-radius:40px;background:#fff;box-shadow:0 20px 60px -30px rgba(0,0,0,.35)}
.content{position:relative;text-align:center;padding:0 90px}
.brand{font-size:30px;font-weight:700;color:#8A7D73;letter-spacing:-.01em}
.emoji{font-family:"Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif;line-height:1}
`;

function resultHtml(r) {
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8"><style>${BASE_CSS}
body{background:${r.soft}}
.frame{border:6px solid ${r.color}}
.emoji{font-size:150px;margin:18px 0 14px}
.name{font-size:78px;font-weight:800;color:${r.color};letter-spacing:-.03em;line-height:1.15}
.summary{font-size:36px;font-weight:700;margin-top:18px;line-height:1.35}
</style></head><body><div class="frame"></div><div class="content">
<div class="brand">✈ 나의 여행 스타일 테스트</div>
<div class="emoji">${r.emoji}</div>
<div class="name">나는 ${r.name}!</div>
<div class="summary">${r.summary}</div>
</div></body></html>`;
}

function homeHtml() {
  const emojis = T.TYPE_ORDER.map((t) => {
    const r = T.RESULTS[t];
    return `<span style="background:${r.soft};border:5px solid ${r.color}">${r.emoji}</span>`;
  }).join('');
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8"><style>${BASE_CSS}
body{background:#FFF1E2}
.frame{border:6px solid #2A2420}
.row{display:flex;gap:26px;justify-content:center;margin-bottom:34px}
.row span{width:132px;height:132px;border-radius:36px;display:flex;align-items:center;justify-content:center;font-size:80px}
.title{font-size:84px;font-weight:800;letter-spacing:-.03em;line-height:1.15}
.sub{font-size:36px;font-weight:700;color:#6E6259;margin-top:18px}
</style></head><body><div class="frame"></div><div class="content">
<div class="row emoji">${emojis}</div>
<div class="title">나의 여행 스타일 테스트</div>
<div class="sub">8개 질문으로 알아보는 나의 여행 유형!</div>
</div></body></html>`;
}

function capture(browser, html, outFile, tmp) {
  const htmlFile = path.join(tmp, path.basename(outFile, '.png') + '.html');
  fs.writeFileSync(htmlFile, html);
  execFileSync(browser, [
    '--headless=new',
    '--disable-gpu',
    '--hide-scrollbars',
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-extensions',
    '--force-device-scale-factor=1',
    '--user-data-dir=' + path.join(tmp, 'profile'),
    `--window-size=${W},${H}`,
    '--screenshot=' + outFile,
    'file:///' + htmlFile.replace(/\\/g, '/')
  ], { stdio: 'pipe', timeout: 60000 });
  // Edge 실행기는 캡처 파일을 다 쓰기 전에 끝날 수 있어서, 파일 크기가 멈출 때까지 기다립니다.
  const deadline = Date.now() + 30000;
  let last = -1;
  while (Date.now() < deadline) {
    const size = fs.existsSync(outFile) ? fs.statSync(outFile).size : -1;
    if (size > 0 && size === last) return;
    last = size;
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 500);
  }
  throw new Error('캡처 실패: ' + outFile);
}

function main() {
  const browser = findBrowser();
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'travel-og-'));
  fs.mkdirSync(OUT, { recursive: true });
  try {
    capture(browser, homeHtml(), path.join(OUT, 'og-home.png'), tmp);
    for (const t of T.TYPE_ORDER) {
      capture(browser, resultHtml(T.RESULTS[t]), path.join(OUT, 'og-' + t + '.png'), tmp);
    }
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  console.log('images: ' + (T.TYPE_ORDER.length + 1) + ' PNG in site/img');
}

if (require.main === module) main();
