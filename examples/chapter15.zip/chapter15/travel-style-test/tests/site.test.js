// 실행: npm test   (Node 18 이상, 설치할 패키지 없음)
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const T = require('../site/js/data.js');
const { indexPage, resultPage } = require('../tools/build.js');

const SITE = path.join(__dirname, '..', 'site');
const PAGES = ['index.html', ...T.TYPE_ORDER.map((t) => T.resultPath(t))];

function read(rel) { return fs.readFileSync(path.join(SITE, rel), 'utf8'); }
function listFiles(dir, base = '') {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
    e.isDirectory() ? listFiles(path.join(dir, e.name), base + e.name + '/') : [base + e.name]
  );
}
function meta(html, prop) {
  const re = new RegExp(`<meta (?:property|name)="${prop}" content="([^"]*)"`);
  const m = html.match(re);
  return m ? m[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"') : null;
}
function pngSize(file) {
  const b = fs.readFileSync(file);
  assert.equal(b.toString('hex', 0, 8), '89504e470d0a1a0a', file + ' 는 PNG가 아님');
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), bytes: b.length };
}

// ── (1) 질문 8개, 결과 4가지 ─────────────────────────
test('질문 8개, 질문마다 선택지 4개이고 네 유형이 하나씩', () => {
  assert.equal(T.QUESTIONS.length, 8);
  for (const q of T.QUESTIONS) {
    assert.ok(q.q.length > 0);
    assert.equal(q.options.length, 4);
    assert.deepEqual(q.options.map((o) => o.type).sort(), [...T.TYPE_ORDER].sort());
  }
});

test('선택지 순서가 질문마다 섞여 있음 (유형 패턴이 티 나지 않게)', () => {
  const orders = new Set(T.QUESTIONS.map((q) => q.options.map((o) => o.type).join(',')));
  assert.ok(orders.size >= 6, '서로 다른 순서가 ' + orders.size + '개뿐');
});

test('결과 4가지, 항목이 모두 채워져 있음 (해외+국내 추천지 포함)', () => {
  assert.equal(T.TYPE_ORDER.length, 4);
  for (const t of T.TYPE_ORDER) {
    const r = T.RESULTS[t];
    for (const k of ['emoji', 'name', 'summary', 'ogTitle', 'ogDesc', 'color', 'soft']) assert.ok(r[k], t + '.' + k);
    assert.ok(r.traits.length >= 3 && r.traits.length <= 4);
    assert.ok(T.RESULTS[r.mate.type] && r.mate.type !== t && r.mate.reason);
    assert.deepEqual(r.places.map((p) => p.label), ['해외', '국내']);
    for (const p of r.places) assert.ok(p.name && p.why);
  }
});

// ── 점수 계산 ───────────────────────────────────────
test('모든 응답 조합(4^8 = 65,536가지)에서 결과가 정해지고, 네 유형이 모두 나올 수 있음', () => {
  const counts = Object.fromEntries(T.TYPE_ORDER.map((t) => [t, 0]));
  const n = T.QUESTIONS.length;
  for (let code = 0; code < 4 ** n; code++) {
    const answers = [];
    let c = code;
    for (let i = 0; i < n; i++) { answers.push(T.TYPE_ORDER[c % 4]); c = Math.floor(c / 4); }
    const r = T.scoreAnswers(answers);
    // 결과는 반드시 최다 득표 유형 중 하나
    const freq = answers.filter((a) => a === r).length;
    for (const t of T.TYPE_ORDER) assert.ok(answers.filter((a) => a === t).length <= freq);
    counts[r]++;
  }
  for (const t of T.TYPE_ORDER) assert.ok(counts[t] > 0, t + ' 가 나올 수 없음');
  // 대칭 구조라 네 유형이 똑같은 확률로 나옴
  assert.equal(new Set(Object.values(counts)).size, 1, JSON.stringify(counts));
});

test('최다 득표가 결과', () => {
  const a = ['planner', 'planner', 'planner', 'foodie', 'healing', 'adventurer', 'planner', 'foodie'];
  assert.equal(T.scoreAnswers(a), 'planner');
});

test('동점이면 Q8 답, Q8이 동점 유형이 아니면 Q7부터 거꾸로', () => {
  // 2:2:2:2 → Q8 답
  assert.equal(T.scoreAnswers(['planner', 'planner', 'adventurer', 'adventurer', 'healing', 'healing', 'foodie', 'foodie']), 'foodie');
  // planner 3, adventurer 3 동점, Q8=healing(동점 아님) → Q7=adventurer
  assert.equal(T.scoreAnswers(['planner', 'planner', 'planner', 'adventurer', 'adventurer', 'foodie', 'adventurer', 'healing']), 'adventurer');
});

test('잘못된 입력은 거부', () => {
  assert.throws(() => T.scoreAnswers(['planner']));
  assert.throws(() => T.scoreAnswers(Array(8).fill('nope')));
});

// ── (2) 공유·미리보기 ───────────────────────────────
test('생성된 페이지가 data.js 최신 내용과 같음 (npm run build 를 빠뜨리지 않았는지)', () => {
  assert.equal(read('index.html'), indexPage());
  for (const t of T.TYPE_ORDER) assert.equal(read(T.resultPath(t)), resultPage(t));
});

test('사이트 주소가 https://travel-style-test.netlify.app', () => {
  assert.equal(T.SITE_URL, 'https://travel-style-test.netlify.app');
});

test('모든 페이지에 카톡 미리보기용 제목·설명·이미지·주소가 절대 주소로 들어 있음', () => {
  for (const p of PAGES) {
    const html = read(p);
    const url = T.SITE_URL + '/' + (p === 'index.html' ? '' : p);
    assert.ok(meta(html, 'og:title'), p + ' og:title');
    assert.ok(meta(html, 'og:description'), p + ' og:description');
    assert.equal(meta(html, 'og:url'), url, p + ' og:url');
    assert.match(html, new RegExp(`<link rel="canonical" href="${url.replace(/[.]/g, '\\.')}">`));
    const img = meta(html, 'og:image');
    assert.ok(img && img.startsWith(T.SITE_URL + '/img/') && img.endsWith('.png'), p + ' og:image: ' + img);
    assert.equal(meta(html, 'og:image:width'), '1200');
    assert.equal(meta(html, 'og:image:height'), '630');
    assert.equal(meta(html, 'og:title'), html.match(/<title>([^<]*)<\/title>/)[1], p + ' title 일치');
  }
});

test('결과마다 미리보기 제목·설명·이미지가 서로 다르고, 결과 내용과 일치', () => {
  const seen = { t: new Set(), d: new Set(), i: new Set() };
  for (const t of T.TYPE_ORDER) {
    const html = read(T.resultPath(t));
    const r = T.RESULTS[t];
    assert.equal(meta(html, 'og:title'), r.ogTitle);
    assert.equal(meta(html, 'og:description'), r.ogDesc);
    assert.equal(meta(html, 'og:image'), `${T.SITE_URL}/img/og-${t}.png`);
    assert.ok(html.includes(`data-share-url="${T.SITE_URL}/result/${t}.html"`), '공유 주소');
    assert.ok(html.includes(r.name) && html.includes(r.places[1].name));
    seen.t.add(r.ogTitle); seen.d.add(r.ogDesc); seen.i.add(meta(html, 'og:image'));
  }
  assert.equal(seen.t.size, 4); assert.equal(seen.d.size, 4); assert.equal(seen.i.size, 4);
});

test('미리보기 이미지가 실제 PNG 1200×630, 1MB 이하', () => {
  for (const p of PAGES) {
    const img = meta(read(p), 'og:image');
    const file = path.join(SITE, img.slice(T.SITE_URL.length + 1));
    assert.ok(fs.existsSync(file), file + ' 없음');
    const s = pngSize(file);
    assert.deepEqual([s.w, s.h], [1200, 630], file);
    assert.ok(s.bytes < 1024 * 1024, file + ' 너무 큼');
  }
});

test('결과 페이지에 공유 버튼, 다시 하기, 다른 유형 3개 링크가 있음', () => {
  for (const t of T.TYPE_ORDER) {
    const html = read(T.resultPath(t));
    assert.ok((html.match(/class="btn [^"]*js-share"/g) || []).length === 2);
    assert.ok(html.includes('href="../index.html?start=1"'));
    const others = [...html.matchAll(/class="other" href="([a-z]+)\.html"/g)].map((m) => m[1]);
    assert.deepEqual(others.sort(), T.TYPE_ORDER.filter((x) => x !== t).sort());
  }
});

test('페이지 안의 상대 링크와 파일 경로가 모두 실제로 존재', () => {
  for (const p of PAGES) {
    const html = read(p);
    const dir = path.dirname(path.join(SITE, p));
    for (const m of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
      const ref = m[1];
      if (/^(https?:|data:)/.test(ref)) continue;
      const file = path.join(dir, ref.split(/[?#]/)[0]);
      assert.ok(fs.existsSync(file), `${p} → ${ref} 없음`);
    }
  }
});

// ── (3) 개인정보·외부 코드 없음 ─────────────────────
test('입력 칸·폼이 없음 (이름·연락처를 받지 않음)', () => {
  for (const p of PAGES) assert.doesNotMatch(read(p), /<(form|input|textarea|select)\b/i, p);
});

test('외부 스크립트·스타일·이미지·폰트를 불러오지 않음', () => {
  for (const p of PAGES) {
    const html = read(p);
    for (const m of html.matchAll(/<(script|link|img|iframe|source|video|audio)\b[^>]*>/gi)) {
      const tag = m[0];
      if (/rel="canonical"/.test(tag)) continue; // 주소 표기용, 불러오지 않음
      assert.doesNotMatch(tag, /(src|href)="(https?:)?\/\//i, `${p}: ${tag}`);
    }
    assert.doesNotMatch(html, /<iframe|<object|<embed/i);
    // 절대 주소는 우리 사이트 주소뿐 (파비콘 SVG의 xmlns 이름표는 불러오는 주소가 아님)
    for (const m of html.matchAll(/https?:\/\/[^\s"'<>)]+/g)) {
      if (m[0] === 'http://www.w3.org/2000/svg') continue;
      assert.ok(m[0].startsWith(T.SITE_URL), `${p}: 외부 주소 ${m[0]}`);
    }
  }
  const css = read('css/style.css');
  assert.doesNotMatch(css, /@import|url\(\s*['"]?(https?:)?\/\//i);
});

test('추적·광고·저장·전송 코드가 없음', () => {
  const banned = [
    /\bfetch\s*\(/, /XMLHttpRequest/, /sendBeacon/, /WebSocket/, /EventSource/,
    /localStorage/, /sessionStorage/, /indexedDB/, /document\.cookie/,
    /new\s+Image\s*\(/, /gtag|googletagmanager|google-analytics|analytics|adsbygoogle|pixel|facebook|kakao\.min|Kakao\./i
  ];
  const files = listFiles(SITE).filter((f) => /\.(js|html|css)$/.test(f));
  for (const f of files) {
    const src = read(f);
    for (const re of banned) assert.doesNotMatch(src, re, `${f}: ${re}`);
    for (const m of src.matchAll(/https?:\/\/[^\s"'<>)]+/g)) {
      assert.ok(m[0].startsWith(T.SITE_URL) || m[0] === 'http://www.w3.org/2000/svg', `${f}: 외부 주소 ${m[0]}`);
    }
  }
});

// ── (4) Netlify Drop용 정적 파일만 ──────────────────
test('site 폴더에는 정적 파일(html/css/js/png)만 있고 시작 파일 index.html이 있음', () => {
  const files = listFiles(SITE);
  assert.ok(files.includes('index.html'));
  for (const f of files) assert.match(f, /\.(html|css|js|png)$/, f);
});

test('모바일 화면 설정 (viewport, 한국어)', () => {
  for (const p of PAGES) {
    const html = read(p);
    assert.match(html, /<meta name="viewport" content="width=device-width, initial-scale=1/);
    assert.match(html, /<html lang="ko">/);
    assert.doesNotMatch(html, /user-scalable=no|maximum-scale/, '확대를 막지 않음');
  }
});
