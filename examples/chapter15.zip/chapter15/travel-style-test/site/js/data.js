/* 나의 여행 스타일 테스트 — 질문·결과 데이터와 점수 계산
 * 브라우저에서는 window.TravelTest, Node(테스트·빌드)에서는 require()로 사용합니다.
 * 응답은 어디에도 저장하거나 전송하지 않습니다.
 */
(function (root) {
  'use strict';

  // 사이트 주소는 이 한 곳에서만 관리합니다. (바꾸면 `npm run build` 다시 실행)
  var SITE_URL = 'https://travel-style-test.netlify.app';

  var TYPE_ORDER = ['planner', 'adventurer', 'healing', 'foodie'];

  var QUESTIONS = [
    {
      q: '여행 가기 한 달 전, 나는?',
      options: [
        { text: '일정표 초안이 이미 있다. 날짜별로 탭까지 나눠 둠', type: 'planner' },
        { text: '비행기표 끊었으면 준비 끝', type: 'adventurer' },
        { text: '예약한 숙소 사진만 스무 번째 보는 중', type: 'healing' },
        { text: '지도 앱에 저장한 맛집이 벌써 50개', type: 'foodie' }
      ]
    },
    {
      q: '숙소 고를 때 제일 중요한 건?',
      options: [
        { text: '근처에 유명한 빵집이 있는지', type: 'foodie' },
        { text: '역에서 걸어서 몇 분인지, 동선 효율', type: 'planner' },
        { text: '침대 푹신함, 욕조, 수영장', type: 'healing' },
        { text: '그날 가서 정한다. 게스트하우스도 OK', type: 'adventurer' }
      ]
    },
    {
      q: '여행 첫날 아침, 눈 뜨자마자',
      options: [
        { text: '조식은 포기 못 하지만… 5분만 더', type: 'healing' },
        { text: '창밖을 보고 끌리는 방향으로 일단 나간다', type: 'adventurer' },
        { text: '어젯밤 찾아 둔 현지인 브런치 맛집으로 직행', type: 'foodie' },
        { text: '오늘 일정표 확인, 8시 출발에 맞춰 준비', type: 'planner' }
      ]
    },
    {
      q: '계획에 없던 비가 쏟아진다!',
      options: [
        { text: '비 맞는 것도 추억! 골목 탐험 시작', type: 'adventurer' },
        { text: '이럴 줄 알고 준비한 플랜 B, 실내 코스 가동', type: 'planner' },
        { text: '비 오는 날엔 감성 카페지. 창가 자리 사수', type: 'foodie' },
        { text: '오히려 좋아. 빗소리 들으며 숙소에서 낮잠', type: 'healing' }
      ]
    },
    {
      q: '친구가 “여기 진짜 유명한데 1시간 줄 서야 해”라고 한다면',
      options: [
        { text: '1시간이 대수야? 이미 줄 서 있음', type: 'foodie' },
        { text: '1시간 서 있을 체력이면 숙소 가서 쉬고 싶다', type: 'healing' },
        { text: '대기 시간 반영해서 남은 일정부터 다시 짠다', type: 'planner' },
        { text: '줄 서는 대신 옆 골목 아무 가게나 도전', type: 'adventurer' }
      ]
    },
    {
      q: '여행 중 내 사진첩은',
      options: [
        { text: '침대, 수영장, 노을… 거의 같은 구도', type: 'healing' },
        { text: '명소 인증샷, 안내판, 영수증까지 꼼꼼한 기록용', type: 'planner' },
        { text: '흔들린 사진투성이지만 이야깃거리는 가득', type: 'adventurer' },
        { text: '음식 80%, 카페 인테리어 20%', type: 'foodie' }
      ]
    },
    {
      q: '여행 예산, 여기에는 돈 안 아낀다!',
      options: [
        { text: '현지 투어, 액티비티, 처음 해 보는 체험', type: 'adventurer' },
        { text: '먹는 데 쓰는 돈은 아까운 돈이 아니다', type: 'foodie' },
        { text: '시간을 아껴 주는 교통비 (택시, 교통 패스)', type: 'planner' },
        { text: '숙소. 무조건 숙소', type: 'healing' }
      ]
    },
    {
      q: '여행에서 돌아온 나는',
      options: [
        { text: '거기서 먹은 그 맛이 계속 생각나서 비슷한 집 검색 중', type: 'foodie' },
        { text: '다음 여행 파일을 벌써 새로 만들었다', type: 'planner' },
        { text: '여행 후유증으로 이틀은 더 쉬어야 한다', type: 'healing' },
        { text: '“그때 진짜 웃겼잖아” 썰이 한가득', type: 'adventurer' }
      ]
    }
  ];

  var RESULTS = {
    planner: {
      emoji: '🗓️',
      name: '꼼꼼 플래너형',
      summary: '여행 가서도 엑셀 켜는 사람, 그게 바로 당신',
      traits: [
        '일정표가 있어야 마음 편히 놀 수 있어요',
        '친구들은 몰라요, 당신 덕분에 막차를 탔다는 걸',
        '플랜 B, 플랜 C까지 준비돼 있어요',
        '일정이 틀어지면 3초 멈칫하지만 금방 다시 짜요'
      ],
      mate: { type: 'healing', reason: '당신이 짜면 군말 없이 따라와 줘요' },
      places: [
        { label: '해외', name: '일본 교토', why: '1분도 안 늦는 기차, 동선 짜는 맛이 있는 도시' },
        { label: '국내', name: '경주', why: '유적지마다 동선 퍼즐을 맞추는 재미, 마무리는 황리단길' }
      ],
      ogTitle: '나는 🗓️ 꼼꼼 플래너형!',
      ogDesc: '여행 가서도 엑셀 켜는 사람. 너의 여행 스타일은? 8개 질문으로 알아보기',
      color: '#4F6BED',
      soft: '#EEF1FF'
    },
    adventurer: {
      emoji: '🎒',
      name: '즉흥 모험가형',
      summary: '계획? 그건 공항 가는 길에 생각하면 돼',
      traits: [
        '길을 잃어도 “오히려 좋아”를 외치는 사람',
        '여행의 하이라이트는 늘 계획에 없던 순간이에요',
        '현지인과 금방 친해지는 친화력이 있어요',
        '다만 숙소 체크인 시간은 가끔 까먹어요'
      ],
      mate: { type: 'foodie', reason: '헤매다 들어간 골목에서 숨은 맛집을 찾아 줘요' },
      places: [
        { label: '해외', name: '베트남 하노이와 사파', why: '오토바이 물결, 즉석 투어, 예측 불가한 하루' },
        { label: '국내', name: '울릉도', why: '배가 뜰지 말지부터 모험, 섬 한 바퀴 즉흥 드라이브' }
      ],
      ogTitle: '나는 🎒 즉흥 모험가형!',
      ogDesc: '계획은 공항 가는 길에. 너의 여행 스타일은? 8개 질문으로 알아보기',
      color: '#E8702A',
      soft: '#FFF0E6'
    },
    healing: {
      emoji: '🛌',
      name: '힐링 충전형',
      summary: '숙소 수영장이 곧 여행지',
      traits: [
        '여행의 목적은 ‘쉬는 것’, 그 자체예요',
        '관광지 세 곳보다 늦잠 한 번이 더 소중해요',
        '좋은 숙소를 고르는 안목만큼은 최고예요',
        '같이 간 친구들의 체력 방전을 막아 주는 사람'
      ],
      mate: { type: 'planner', reason: '알아서 다 짜 주니 당신은 쉬기만 하면 돼요' },
      places: [
        { label: '해외', name: '발리 우붓', why: '정글 뷰 수영장, 마사지, 아무것도 안 해도 되는 하루' },
        { label: '국내', name: '제주 서귀포', why: '오션뷰 숙소에서 귤 까먹으며 바다 멍' }
      ],
      ogTitle: '나는 🛌 힐링 충전형!',
      ogDesc: '숙소 수영장이 곧 여행지. 너의 여행 스타일은? 8개 질문으로 알아보기',
      color: '#16A085',
      soft: '#E5F6F2'
    },
    foodie: {
      emoji: '🍜',
      name: '맛집·감성 탐방형',
      summary: '동선은 맛집이 정하고, 남은 시간은 카페가 정한다',
      traits: [
        '여행지를 고르는 기준이 ‘뭘 먹을 수 있나’예요',
        '저장해 둔 맛집 리스트가 곧 여행 일정이에요',
        '사진첩만 봐도 그 도시의 맛이 느껴져요',
        '하루 다섯 끼도 가능한 위장의 소유자'
      ],
      mate: { type: 'adventurer', reason: '같이 헤매다 보면 리스트에 없던 인생 맛집을 만나요' },
      places: [
        { label: '해외', name: '대만 타이베이', why: '야시장, 우육면, 골목마다 감성 카페' },
        { label: '국내', name: '전주', why: '한옥마을 길거리 음식부터 가맥집까지, 하루 다섯 끼 코스' }
      ],
      ogTitle: '나는 🍜 맛집·감성 탐방형!',
      ogDesc: '동선은 맛집이 정한다. 너의 여행 스타일은? 8개 질문으로 알아보기',
      color: '#E0456B',
      soft: '#FFEDF1'
    }
  };

  var HOME = {
    title: '나의 여행 스타일 테스트',
    ogDesc: '8개 질문으로 알아보는 나의 여행 유형! 나는 플래너일까, 모험가일까?'
  };

  /**
   * answers: 질문 순서대로 고른 유형 키 배열 (예: ['planner','foodie',...])
   * 가장 많이 고른 유형이 결과. 동점이면 마지막 질문부터 거꾸로 보며
   * 동점 유형 중 가장 나중에 고른 유형으로 정합니다.
   */
  function scoreAnswers(answers) {
    if (!Array.isArray(answers) || answers.length !== QUESTIONS.length) {
      throw new Error('answers must have ' + QUESTIONS.length + ' items');
    }
    var counts = {};
    TYPE_ORDER.forEach(function (t) { counts[t] = 0; });
    answers.forEach(function (t) {
      if (!(t in counts)) throw new Error('unknown type: ' + t);
      counts[t] += 1;
    });
    var max = Math.max.apply(null, TYPE_ORDER.map(function (t) { return counts[t]; }));
    var tied = TYPE_ORDER.filter(function (t) { return counts[t] === max; });
    if (tied.length === 1) return tied[0];
    for (var i = answers.length - 1; i >= 0; i--) {
      if (tied.indexOf(answers[i]) !== -1) return answers[i];
    }
    return tied[0]; // 도달하지 않음
  }

  function resultPath(type) {
    return 'result/' + type + '.html';
  }

  var api = {
    SITE_URL: SITE_URL,
    TYPE_ORDER: TYPE_ORDER,
    QUESTIONS: QUESTIONS,
    RESULTS: RESULTS,
    HOME: HOME,
    scoreAnswers: scoreAnswers,
    resultPath: resultPath
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.TravelTest = api;
})(typeof window !== 'undefined' ? window : this);
