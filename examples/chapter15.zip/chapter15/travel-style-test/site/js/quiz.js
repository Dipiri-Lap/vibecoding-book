/* 질문 화면. 답변은 이 페이지의 메모리에만 있고, 결과 페이지로 이동하면 사라집니다. */
(function () {
  'use strict';
  var T = window.TravelTest;
  var answers = [];

  var startEl = document.getElementById('start');
  var quizEl = document.getElementById('quiz');
  var qNum = document.getElementById('q-num');
  var qText = document.getElementById('q-text');
  var optionsEl = document.getElementById('options');
  var progressText = document.getElementById('progress-text');
  var progressFill = document.getElementById('progress-fill');
  var backBtn = document.getElementById('back-btn');
  var locked = false;

  function show(el) {
    startEl.hidden = el !== startEl;
    quizEl.hidden = el !== quizEl;
    window.scrollTo(0, 0);
  }

  function render() {
    var i = answers.length;
    var item = T.QUESTIONS[i];
    var total = T.QUESTIONS.length;
    qNum.textContent = 'Q' + (i + 1);
    qText.textContent = item.q;
    progressText.textContent = (i + 1) + ' / ' + total;
    progressFill.style.width = ((i + 1) / total) * 100 + '%';
    backBtn.textContent = i === 0 ? '‹ 처음으로' : '‹ 이전';

    optionsEl.innerHTML = '';
    item.options.forEach(function (opt) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'option';
      b.textContent = opt.text;
      b.addEventListener('click', function () { choose(opt.type, b); });
      optionsEl.appendChild(b);
    });
    quizEl.classList.remove('enter');
    void quizEl.offsetWidth; // 애니메이션 재시작
    quizEl.classList.add('enter');
    locked = false;
  }

  function choose(type, btn) {
    if (locked) return;
    locked = true;
    btn.classList.add('picked');
    answers.push(type);
    setTimeout(function () {
      if (answers.length === T.QUESTIONS.length) {
        var result = T.scoreAnswers(answers);
        // ?me=1 은 "내 결과" 화면 표시용. 결과 페이지에서 주소창에서 바로 지워집니다.
        window.location.href = T.resultPath(result) + '?me=1';
      } else {
        render();
      }
    }, 180);
  }

  function begin() {
    answers = [];
    show(quizEl);
    render();
  }

  document.getElementById('start-btn').addEventListener('click', begin);
  backBtn.addEventListener('click', function () {
    if (answers.length === 0) { show(startEl); return; }
    answers.pop();
    render();
  });

  // 뒤로 가기로 이 페이지에 돌아오면(bfcache) 새로 시작
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) { answers = []; show(startEl); }
  });

  if (/[?&]start=1\b/.test(window.location.search)) {
    if (window.history.replaceState) window.history.replaceState(null, '', window.location.pathname);
    begin();
  }
})();
