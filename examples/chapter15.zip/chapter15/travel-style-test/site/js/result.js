/* 결과 화면: 내 결과/친구 결과 표시 전환, 공유하기, 링크 복사 */
(function () {
  'use strict';
  var body = document.body;
  var shareUrl = body.getAttribute('data-share-url');
  var shareTitle = body.getAttribute('data-share-title');
  var shareText = body.getAttribute('data-share-text');

  // 테스트를 막 끝내고 온 경우(?me=1)만 "내 결과" 모드. 공유되는 주소에는 붙지 않습니다.
  if (/[?&]me=1\b/.test(window.location.search)) {
    document.getElementById('result-intro').textContent = '당신의 여행 스타일은';
    document.getElementById('actions-mine').hidden = false;
    document.getElementById('actions-friend').hidden = true;
    if (window.history.replaceState) window.history.replaceState(null, '', window.location.pathname);
  }

  var toast = document.getElementById('toast');
  var toastTimer;
  function showToast(msg) {
    toast.textContent = msg;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.hidden = true; }, 2600);
  }

  function legacyCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }

  function copyLink() {
    var done = function () { showToast('링크를 복사했어요! 카톡 대화창에 붙여 넣어 보내 주세요.'); };
    var fail = function () { window.prompt('아래 링크를 길게 눌러 복사해 주세요.', shareUrl); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(shareUrl).then(done, function () {
        if (legacyCopy(shareUrl)) done(); else fail();
      });
    } else if (legacyCopy(shareUrl)) {
      done();
    } else {
      fail();
    }
  }

  function share() {
    if (navigator.share) {
      navigator.share({ title: shareTitle, text: shareText, url: shareUrl }).catch(function (err) {
        // 사용자가 공유창을 닫은 경우는 조용히 무시, 그 외 오류는 링크 복사로 대체
        if (!err || err.name !== 'AbortError') copyLink();
      });
    } else {
      copyLink();
    }
  }

  var buttons = document.querySelectorAll('.js-share');
  for (var i = 0; i < buttons.length; i++) buttons[i].addEventListener('click', share);
})();
