# 나의 여행 스타일 테스트

질문 8개, 결과 4가지 심리테스트입니다. 서버, 외부 코드, 개인정보 수집 없이 동작하는 정적 사이트예요.
사이트 주소: **https://travel-style-test.netlify.app**

## 폴더 구성

| 경로 | 내용 |
|---|---|
| `site/` | **Netlify Drop에 올리는 폴더 (이 폴더만 올리면 됩니다)** |
| `site/js/data.js` | 질문·결과 문구, 사이트 주소, 점수 계산. 문구 수정은 여기서 |
| `site/index.html`, `site/result/*.html` | `data.js`로 자동 생성되는 페이지 (직접 고치지 마세요) |
| `site/img/og-*.png` | 카톡 미리보기 이미지 5장 (1200×630) |
| `tools/` | 페이지 생성, 이미지 생성, 로컬 미리보기 서버 |
| `tests/` | 자동 테스트 |

## 문구를 고쳤을 때

```bash
npm run build
```

```bash
npm run images
```

```bash
npm test
```

`build`는 페이지를, `images`는 미리보기 이미지를 다시 만들어요. 이미지 문구(유형 이름·한 줄 요약)를 바꾼 경우에만 `images`가 필요해요. `npm test`가 전부 통과하면 올려도 됩니다.

내 PC에서 미리 보기: `npm run serve` 실행 후 http://localhost:8080

## Netlify Drop에 올리기

1. Netlify에 로그인한 상태에서 https://app.netlify.com/drop 를 엽니다. (로그인하지 않고 올린 사이트는 잠시 뒤 사라질 수 있어요)
2. **`site` 폴더**를 통째로 끌어다 놓습니다. (상위 폴더 `travel-style-test`가 아니라 `site`)
3. 임의 주소(예: `random-name-123.netlify.app`)가 생기면 **Site configuration → Change site name**에서 `travel-style-test`로 바꿉니다.
   - 이 이름을 이미 누가 쓰고 있다면 다른 이름을 고르고, `site/js/data.js`의 `SITE_URL`을 그 주소로 바꾼 다음 `npm run build`와 `npm test`를 실행하고 다시 올려 주세요. 미리보기 이미지 주소가 이 값으로 들어가기 때문에 꼭 맞아야 해요.
4. **수정본을 다시 올릴 때**: Drop 첫 화면에 다시 올리면 새 사이트가 생겨요. 기존 사이트의 **Deploys** 탭에 `site` 폴더를 끌어다 놓아야 같은 주소로 업데이트됩니다.

## 카톡 미리보기 확인 (올린 뒤에 직접)

1. 카톡 "나와의 채팅"에 아래 주소를 하나씩 보내 보세요. 제목, 설명, 이미지가 결과마다 다르게 나와야 해요.
   - https://travel-style-test.netlify.app/
   - https://travel-style-test.netlify.app/result/planner.html
   - https://travel-style-test.netlify.app/result/adventurer.html
   - https://travel-style-test.netlify.app/result/healing.html
   - https://travel-style-test.netlify.app/result/foodie.html
2. 테스트를 끝까지 해 보고 **친구에게 공유하기**를 눌러 보세요. 휴대폰 공유창에서 카카오톡을 고르면 결과 링크가 전송돼요.
   카톡 안에서 링크를 연 경우처럼 공유창이 안 뜨는 환경에서는 링크가 복사되니, 대화창에 붙여 넣으면 돼요.
3. 미리보기가 예전 모습으로 나오면 카톡이 저장해 둔 미리보기 때문이에요.
   카카오 개발자 사이트의 공유 디버거(https://developers.kakao.com/tool/debugger/sharing)에 카카오 계정으로 로그인하고, 주소를 넣어 **캐시 초기화**를 누르면 새로 반영돼요.

## 지키는 원칙

- 이름·연락처 입력 칸이 없고, 답변은 그 페이지 안에서만 쓰고 저장하거나 전송하지 않아요.
- 외부 스크립트, 폰트, 분석·광고 코드가 없어요. 모든 파일이 `site/` 안에 있어요. (`npm test`가 매번 검사)
- 동점일 때는 Q8 답을 따르고, Q8 답이 동점 유형이 아니면 Q7, Q6… 순서로 거꾸로 보며 동점 유형 중 가장 나중에 고른 것으로 정해요.
