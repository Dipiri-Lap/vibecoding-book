@echo off
chcp 65001 > nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
where python > nul 2>&1
if %errorlevel%==0 (
    python weekly_report.py %*
) else (
    py -3 weekly_report.py %*
)
echo.
if %errorlevel%==0 (
    start "" "%~dp0보고서"
)
pause
