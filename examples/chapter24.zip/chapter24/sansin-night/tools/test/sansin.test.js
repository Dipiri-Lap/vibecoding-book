'use strict';
// 실행: node --test tools/test/sansin.test.js
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadEngine, readHtml, extractScript } = require('../load-engine');
const { buildTable } = require('../difficulty-table');

const E = loadEngine();
const json = x => JSON.stringify(x);

function freshGame(seed) {
  const g = new E.Game({ seed: seed === undefined ? 1 : seed });
  g.spawnTimer = 1e9;           // 규칙 하나만 보려고 자동 등장을 끈다
  g.player.atkCd = 1e9;         // 자동 공격도 끈다 (필요한 테스트에서 켠다)
  return g;
}

// ---------- seed / speed ----------
test('seed가 같으면 봇 한 판의 결과가 완전히 같다', () => {
  for (const kind of ['novice', 'expert']) {
    for (const seed of [7, 42]) {
      assert.equal(json(E.runBotGame(kind, seed)), json(E.runBotGame(kind, seed)), kind + ' seed ' + seed);
    }
  }
});

test('seed가 같으면 같은 입력에서 판의 상태가 틱마다 똑같다', () => {
  const a = new E.Game({ seed: 7 }), b = new E.Game({ seed: 7 });
  for (let i = 0; i < 1500; i++) {
    const ix = Math.cos(i / 40), iy = Math.sin(i / 55);
    a.input.x = b.input.x = ix; a.input.y = b.input.y = iy;
    a.tick(); b.tick();
    if (i % 100 === 0) assert.equal(json(a.snapshot()), json(b.snapshot()), 'tick ' + i);
  }
  assert.equal(json(a.snapshot()), json(b.snapshot()));
});

test('seed가 다르면 판이 달라진다', () => {
  const results = new Set();
  for (let seed = 1; seed <= 10; seed++) results.add(json(E.runBotGame('novice', seed)));
  assert.ok(results.size > 5, '서로 다른 결과 수: ' + results.size);
});

test('?seed=7 / ?speed=10 / ?bot= 주소 읽기', () => {
  assert.deepEqual({ ...E.parseParams('?seed=7&speed=10') }, { seed: 7, speed: 10, bot: null });
  assert.equal(E.parseParams('').seed, null);
  assert.equal(E.parseParams('').speed, 1);
  assert.equal(E.parseParams('?speed=abc').speed, 1);
  assert.equal(E.parseParams('?speed=-3').speed, 1);
  assert.equal(E.parseParams('?speed=100000').speed, 100);
  assert.equal(E.parseParams('?seed=zzz').seed, null);
  assert.equal(E.parseParams('?bot=expert').bot, 'expert');
  assert.equal(E.parseParams('?bot=hacker').bot, null);
});

test('speed 배수: 같은 실제 시간에 speed=10이면 10배 진행한다', () => {
  function ticksAfter(speed, seconds) {
    const g = new E.Game({ seed: 7 });
    const r = new E.Runner(g, { speed });
    const frames = Math.round(seconds * 60);
    for (let i = 0; i < frames; i++) r.frame(1000 / 60);
    return g.tickCount;
  }
  const t1 = ticksAfter(1, 2), t10 = ticksAfter(10, 2), t2 = ticksAfter(2, 2);
  assert.ok(Math.abs(t1 - 120) <= 2, 'speed1: ' + t1);
  assert.ok(Math.abs(t10 - 1200) <= 3, 'speed10: ' + t10);
  assert.ok(Math.abs(t2 - 240) <= 2, 'speed2: ' + t2);
});

test('speed를 올려도 결과는 같다 (시간만 빨라질 뿐 판은 똑같다)', () => {
  function run(speed) {
    const g = new E.Game({ seed: 7 });
    const r = new E.Runner(g, { speed, bot: E.makeBot('expert', 7) });
    let guard = 0;
    while (g.tickCount < 3000 && guard++ < 100000) r.frame(1000 / 60);
    // 틱 수가 정확히 같아지도록 남는 틱은 같은 방식으로 맞춘다
    while (g.tickCount < 3000) { r.bot.act(g); g.tick(); }
    return json(g.snapshot());
  }
  assert.equal(run(1), run(10));
});

test('프레임이 크게 늘어져도(탭 전환 등) 한 번에 0.1초(×speed)까지만 진행한다', () => {
  const g = new E.Game({ seed: 7 });
  const r = new E.Runner(g, { speed: 1 });
  r.frame(60000);
  assert.ok(g.tickCount <= 7, 'tick ' + g.tickCount);
});

// ---------- 봇이 끝까지 돈다 ----------
test('봇 두 종류가 20판씩 끝까지 돈다 (멈추지 않고 결과를 낸다)', () => {
  for (const kind of ['novice', 'expert']) {
    for (let seed = 1; seed <= 20; seed++) {
      const r = E.runBotGame(kind, seed, 180);
      assert.ok(Number.isFinite(r.time) && r.time > 0 && r.time <= 180.01, kind + ' ' + seed + ' time=' + r.time);
      assert.equal(typeof r.survived, 'boolean');
      assert.ok(r.level >= 1);
    }
  }
});

test('봇이 레벨업 강화를 스스로 골라서 판이 멈추지 않는다', () => {
  const g = new E.Game({ seed: 3 });
  const bot = E.makeBot('expert', 3);
  let sawChoices = false;
  for (let i = 0; i < 60 * 90 && !g.over; i++) {
    bot.act(g);
    if (g.choices) sawChoices = true;
    g.tick();
  }
  assert.ok(g.level > 1, '레벨 ' + g.level);
  assert.equal(sawChoices, false, 'act 뒤에는 고르기 대기가 남아 있으면 안 됨');
});

test('숙련 봇이 초보 봇보다 평균적으로 오래 버틴다', () => {
  const avg = kind => { let s = 0; for (let i = 1; i <= 30; i++) s += E.runBotGame(kind, i).time; return s / 30; };
  const n = avg('novice'), x = avg('expert');
  assert.ok(x > n, '초보 평균 ' + n.toFixed(1) + ' / 숙련 평균 ' + x.toFixed(1));
});

// ---------- 규칙 ----------
test('이동: 방향대로 움직이고 놀이터 밖으로 나가지 않는다', () => {
  const g = freshGame();
  const x0 = g.player.x;
  g.input.x = 1; g.input.y = 0;
  for (let i = 0; i < 30; i++) g.tick();
  assert.ok(g.player.x > x0 + 40, 'x ' + g.player.x);
  for (let i = 0; i < 600; i++) g.tick();
  assert.equal(g.player.x, E.W - g.player.r);
  g.input.x = -1; g.input.y = -1;
  for (let i = 0; i < 1200; i++) g.tick();
  assert.equal(g.player.x, g.player.r);
  assert.equal(g.player.y, g.player.r);
});

test('이동: 대각선도 같은 속도(빨라지지 않는다)', () => {
  const a = freshGame(), b = freshGame();
  a.input.x = 1; a.input.y = 0;
  b.input.x = 1; b.input.y = 1;
  for (let i = 0; i < 30; i++) { a.tick(); b.tick(); }
  const da = Math.hypot(a.player.x - E.W / 2, a.player.y - E.H / 2);
  const db = Math.hypot(b.player.x - E.W / 2, b.player.y - E.H / 2);
  assert.ok(Math.abs(da - db) < 0.01, da + ' vs ' + db);
});

test('적: 주인공 쪽으로 몰려온다', () => {
  const g = freshGame();
  g.enemies.push({ x: 20, y: 20, r: 7, hp: 999, maxHp: 999, speed: 50, dmg: 8 });
  const d0 = Math.hypot(g.player.x - 20, g.player.y - 20);
  for (let i = 0; i < 60; i++) g.tick();
  const e = g.enemies[0];
  assert.ok(Math.hypot(g.player.x - e.x, g.player.y - e.y) < d0 - 40);
});

test('적: 시간이 지나면 저절로 계속 나타난다', () => {
  const g = new E.Game({ seed: 5 });
  g.player.atkCd = 1e9;
  for (let i = 0; i < 60 * 10; i++) g.tick();
  assert.ok(g.enemies.length >= 5, '10초 뒤 적 ' + g.enemies.length);
});

test('자동 공격: 가장 가까운 적을 쏘아 쓰러뜨리면 보석이 남는다', () => {
  const g = freshGame();
  g.player.atkCd = 0;
  const p = g.player;
  g.enemies.push({ x: p.x + 150, y: p.y, r: 7, hp: 5, maxHp: 5, speed: 0, dmg: 8 });     // 멀리
  g.enemies.push({ x: p.x + 60, y: p.y, r: 7, hp: 5, maxHp: 5, speed: 0, dmg: 8 });      // 가까이
  for (let i = 0; i < 40 && g.kills === 0; i++) g.tick();
  assert.equal(g.kills, 1);
  assert.equal(g.gems.length + Math.floor(g.xp), 1, '보석이 생겨야 함');
  assert.equal(g.enemies.length, 1);
  assert.ok(g.enemies[0].x > p.x + 100, '가까운 쪽이 먼저 쓰러져야 함');
});

test('자동 공격: 사거리 밖의 적은 쏘지 않는다', () => {
  const g = freshGame();
  g.player.atkCd = 0;
  g.enemies.push({ x: g.player.x, y: g.player.y - 300, r: 7, hp: 5, maxHp: 5, speed: 0, dmg: 8 });
  for (let i = 0; i < 20; i++) g.tick();
  assert.equal(g.shots.length, 0);
});

test('보석 줍기: 닿으면 경험치가 오르고 보석이 사라진다', () => {
  const g = freshGame();
  g.gems.push({ x: g.player.x + 3, y: g.player.y, v: 1 });
  g.tick();
  assert.equal(g.gems.length, 0);
  assert.equal(g.xp, 1);
});

test('보석 줍기: 가까이 가면 끌려온다', () => {
  const g = freshGame();
  g.gems.push({ x: g.player.x + 30, y: g.player.y, v: 1 });
  for (let i = 0; i < 40; i++) g.tick();
  assert.equal(g.gems.length, 0);
});

test('레벨업: 경험치가 차면 판이 멈추고 강화 3개가 나온다 (서로 다른 3개)', () => {
  const g = freshGame();
  g.xp = g.xpNext - 1;
  g.gems.push({ x: g.player.x, y: g.player.y, v: 1 });
  g.tick();
  assert.equal(g.level, 2);
  assert.ok(g.choices);
  assert.equal(g.choices.length, 3);
  assert.equal(new Set(g.choices.map(c => c.id)).size, 3);
  const t = g.t;
  assert.equal(g.tick(), false);
  assert.equal(g.t, t, '고르는 동안 시간이 흐르면 안 됨');
  assert.equal(g.levelUpTimes.length, 1);
});

test('레벨업: 고르면 판이 다시 흐르고, 다음 레벨업에는 경험치가 더 필요하다', () => {
  const g = freshGame();
  const need1 = g.xpNext;
  g.xp = g.xpNext - 1;
  g.gems.push({ x: g.player.x, y: g.player.y, v: 1 });
  g.tick();
  assert.equal(g.choose(5), false, '없는 번호는 거절');
  assert.equal(g.choose(0), true);
  assert.equal(g.choices, null);
  assert.ok(g.xpNext > need1);
  assert.equal(g.tick(), true);
});

test('강화 네 가지가 각자 수치를 바꾼다 (공격 속도, 공격력, 이동 속도, 체력)', () => {
  assert.deepEqual(E.UPGRADES.map(u => u.id).sort(), ['attackSpeed', 'damage', 'maxHp', 'moveSpeed']);
  const get = id => E.UPGRADES.find(u => u.id === id);
  const p = () => ({ atkInterval: 0.5, dmg: 10, speed: 110, maxHp: 100, hp: 50 });
  let q = p(); get('attackSpeed').apply(q); assert.ok(q.atkInterval < 0.5);
  q = p(); get('damage').apply(q); assert.ok(q.dmg > 10);
  q = p(); get('moveSpeed').apply(q); assert.ok(q.speed > 110);
  q = p(); get('maxHp').apply(q); assert.ok(q.maxHp > 100 && q.hp > 50);
});

test('체력: 적에게 닿으면 줄고, 잠깐 무적이며, 0이 되면 끝난다', () => {
  const g = freshGame();
  const p = g.player;
  g.enemies.push({ x: p.x, y: p.y, r: 7, hp: 999, maxHp: 999, speed: 0, dmg: 8 });
  g.tick();
  assert.equal(p.hp, 92);
  g.tick();
  assert.equal(p.hp, 92, '무적 시간 동안 안 깎임');
  let guard = 0;
  while (!g.over && guard++ < 60 * 30) g.tick();
  assert.equal(g.over, true);
  assert.equal(p.hp, 0);
  assert.ok(g.deathTime > 0);
  const t = g.t;
  assert.equal(g.tick(), false);
  assert.equal(g.t, t, '끝난 뒤에는 시간이 안 흐름');
});

// ---------- 화면 파일 ----------
test('index.html: 세로 화면용 설정이 있고 가로 스크롤이 없다', () => {
  const html = readHtml();
  assert.match(html, /<meta name="viewport"[^>]*width=device-width/);
  assert.match(html, /overflow:\s*hidden/);
  assert.match(html, /touch-action:\s*none/);
  assert.ok(E.H > E.W, '놀이터가 세로형');
});

test('index.html: 외부 주소나 라이브러리를 쓰지 않는다', () => {
  const html = readHtml();
  assert.doesNotMatch(html, /<script[^>]+src=/i);
  // 링크 미리보기용 <meta> 의 주소(og:url, og:image)만 예외. 브라우저가 따로 불러가는 요청이 아니다
  const withoutPreviewMeta = html.replace(/<meta property="og:(url|image)" content="[^"]*">/g, '');
  assert.doesNotMatch(withoutPreviewMeta, /https?:\/\//i);
  assert.doesNotMatch(html, /<link[^>]+href=/i);
});

const SITE = 'https://sansin-night.netlify.app/';
test('링크 미리보기: 제목·설명·이미지·주소 태그가 있고 주소는 사이트 주소로 시작한다', () => {
  const html = readHtml();
  const meta = p => { const m = html.match(new RegExp('<meta property="' + p + '" content="([^"]+)">')); return m && m[1]; };
  assert.ok(meta('og:title'), 'og:title');
  assert.ok(meta('og:description'), 'og:description');
  assert.equal(meta('og:url'), SITE);
  assert.ok(meta('og:image').startsWith(SITE), 'og:image 는 사이트 주소로 시작');
  assert.match(html, /<meta name="description" content="[^"]+">/);
  assert.match(html, /<meta name="twitter:card" content="summary_large_image">/);
  // 같은 이름의 파일이 game 폴더 안에 실제로 있고 1200x630 PNG 이다
  const file = path.join(GAME, meta('og:image').slice(SITE.length));
  assert.ok(fs.existsSync(file), '없는 미리보기 그림: ' + file);
  const b = fs.readFileSync(file);
  assert.equal(b.slice(1, 4).toString(), 'PNG');
  assert.equal(b.readUInt32BE(16), 1200);
  assert.equal(b.readUInt32BE(20), 630);
  assert.equal(meta('og:image:width'), '1200');
  assert.equal(meta('og:image:height'), '630');
});

// 가짜 화면 틀(stub)에 화면 코드를 올려서 실제로 돌려 본다
// opts.stayOnTitle=true 면 처음 시작 화면에서 멈춘 채로 돌려준다. 아니면 '시작' 단추를 눌러 판을 시작한 상태로 돌려준다
function runPage(search, innerWidth, innerHeight, withImages, opts) {
  opts = opts || {};
  const html = readHtml();
  const listeners = { canvas: {}, win: {} };
  const rafQueue = [];
  const drawCalls = { n: 0, image: 0, texts: [], fills: [], strokes: [], rects: [], fontsUsed: new Set() };
  const state = {};
  const fonts = [];
  const noopCtx = new Proxy({}, {
    get(t, k) {
      if (k === 'measureText') return () => ({ width: 10 });
      if (k === 'fillRect') return (x, y, w, h) => { drawCalls.n++; drawCalls.rects.push({ x, y, w, h, color: state.fillStyle }); };
      if (k === 'drawImage') return () => { drawCalls.n++; drawCalls.image++; };
      if (k === 'fillText') return (t) => { drawCalls.n++; drawCalls.texts.push(String(t)); drawCalls.fills.push({ t: String(t), color: state.fillStyle }); };
      if (k === 'strokeText') return (t) => { drawCalls.n++; drawCalls.strokes.push({ t: String(t), color: state.strokeStyle, width: state.lineWidth }); };
      return (...a) => { drawCalls.n++; };
    },
    set(t, k, v) { state[k] = v; if (k === 'font') drawCalls.fontsUsed.add(v); return true; }
  });
  const makeEl = () => {
    const el = {
      style: {}, className: '', textContent: '', innerHTML: '', children: [],
      appendChild(c) { this.children.push(c); },
      addEventListener(t, f) { this.listeners = this.listeners || {}; this.listeners[t] = f; }
    };
    return el;
  };
  const canvas = makeEl();
  canvas.getContext = () => noopCtx;
  canvas.addEventListener = (t, f) => { listeners.canvas[t] = f; };
  canvas.setPointerCapture = () => {};
  const overlay = makeEl(), panel = makeEl();
  const els = { game: canvas, overlay, panel };
  const win = {
    SansinEngine: E, innerWidth, innerHeight, devicePixelRatio: 2,
    location: { search },
    addEventListener: (t, f) => { listeners.win[t] = f; },
    requestAnimationFrame: f => { rafQueue.push(f); }
  };
  const doc = {
    getElementById: id => els[id],
    // withImages=true면 그림 파일이 다 불러와진 것처럼 흉내 낸다
    createElement: tag => (tag === 'img' && withImages) ? { complete: true, naturalWidth: 192, src: '' } : makeEl(),
    fonts: { load() { fonts.push([].slice.call(arguments)); return Promise.resolve(); } }
  };
  new Function('window', 'document', extractScript(html, 'main'))(win, doc);
  let ts = 0;
  const frames = (n, step) => {
    for (let i = 0; i < n; i++) { ts += step === undefined ? 1000 / 60 : step; const f = rafQueue.shift(); f(ts); }
  };
  const page = { win, canvas, overlay, panel, listeners, frames, drawCalls, rafQueue, fonts, state };
  frames(1);                                     // 처음 시작 화면이 뜬다
  if (!opts.stayOnTitle) {
    const startBtn = panel.children.find(c => c.textContent === '시작');
    startBtn.listeners.click();                  // '시작' 단추를 누른다
    frames(1);
    assert.equal(overlay.className, '', '시작하면 창이 닫힘');
  }
  return page;
}
// 가짜 화면 요소 안쪽 글자까지 모아서 읽는다
function textOf(el) { return (el.textContent || '') + (el.children || []).map(textOf).join(''); }

test('화면 코드: 오류 없이 시작해서 계속 그린다', () => {
  const page = runPage('?seed=7', 390, 844);
  page.frames(120);
  assert.ok(page.drawCalls.n > 100, '그리기 호출 ' + page.drawCalls.n);
  assert.equal(page.win.__sansin.game.seed, 7);
  assert.ok(page.win.__sansin.game.tickCount >= 115);
});

test('화면 코드: 캔버스가 폰 크기 안에 들어간다 (가로로 삐져나가지 않음)', () => {
  for (const [w, h] of [[390, 844], [320, 568], [1000, 600], [360, 400]]) {
    const page = runPage('', w, h);
    const cw = parseInt(page.canvas.style.width, 10), ch = parseInt(page.canvas.style.height, 10);
    assert.ok(cw <= w && ch <= h, w + 'x' + h + ' -> ' + cw + 'x' + ch);
    assert.ok(cw > 0 && ch > 0);
  }
});

test('화면 코드: 손가락을 오른쪽으로 끌면 주인공이 오른쪽으로 간다', () => {
  const page = runPage('?seed=7', 390, 844);
  const g = () => page.win.__sansin.game;
  page.frames(2);
  const x0 = g().player.x, y0 = g().player.y;
  page.listeners.canvas.pointerdown({ pointerId: 1, clientX: 100, clientY: 400 });
  page.listeners.canvas.pointermove({ pointerId: 1, clientX: 150, clientY: 400 });
  page.frames(30);
  assert.ok(g().player.x > x0 + 20, 'x ' + x0 + ' -> ' + g().player.x);
  assert.ok(Math.abs(g().player.y - y0) < 1);
  page.listeners.canvas.pointerup({ pointerId: 1 });
  const xs = g().player.x;
  page.frames(10);
  assert.equal(g().player.x, xs, '손가락을 떼면 멈춤');
  page.listeners.canvas.pointerdown({ pointerId: 2, clientX: 200, clientY: 400 });
  page.listeners.canvas.pointermove({ pointerId: 2, clientX: 200, clientY: 340 });
  page.frames(30);
  assert.ok(g().player.y < y0 - 20, '위로 끌면 위로 간다');
});

test('화면 코드: 방향키와 WASD로 움직인다', () => {
  const page = runPage('?seed=7', 390, 844);
  const g = () => page.win.__sansin.game;
  page.frames(2);
  const x0 = g().player.x, y0 = g().player.y;
  page.listeners.win.keydown({ code: 'ArrowLeft', preventDefault() {} });
  page.frames(20);
  assert.ok(g().player.x < x0 - 15);
  page.listeners.win.keyup({ code: 'ArrowLeft' });
  page.listeners.win.keydown({ code: 'KeyS', preventDefault() {} });
  page.frames(20);
  assert.ok(g().player.y > y0 + 15);
});

test('화면 코드: ?speed=10이면 같은 시간에 10배 진행한다', () => {
  const a = runPage('?seed=7', 390, 844), b = runPage('?seed=7&speed=10', 390, 844);
  a.frames(60); b.frames(60);
  const ta = a.win.__sansin.game.tickCount, tb = b.win.__sansin.game.tickCount;
  assert.ok(Math.abs(tb / ta - 10) < 0.5, ta + ' vs ' + tb);
});

test('화면 코드: ?bot=novice이면 봇이 직접 한 판을 끝까지 돌리고, 쓰러지면 다시 하기가 뜬다', () => {
  const page = runPage('?seed=7&speed=100&bot=novice', 390, 844);
  let guard = 0;
  while (!page.win.__sansin.game.over && guard++ < 20000) page.frames(1);
  const g = page.win.__sansin.game;
  assert.ok(g.over, '끝나야 함');
  page.frames(2);
  assert.equal(page.overlay.className, 'on');
  assert.ok(page.panel.children.some(c => c.textContent === '다시 하기'));
});

test('화면 코드: 레벨업하면 강화 3개 버튼이 뜨고, 1~3 키로 고를 수 있다', () => {
  const page = runPage('?seed=7', 390, 844);
  const g = () => page.win.__sansin.game;
  page.frames(2);
  g().xp = g().xpNext;          // 경험치를 채워서 레벨업을 일으킨다
  page.frames(2);
  assert.ok(g().choices, '강화 선택이 떠야 함');
  page.frames(1);
  assert.equal(page.overlay.className, 'on');
  const buttons = page.panel.children.filter(c => c.className === 'choice');
  assert.equal(buttons.length, 3);
  buttons.forEach((b, i) => assert.match(textOf(b), new RegExp('^' + (i + 1) + '\. .+')));
  const t = g().t;
  page.frames(10);
  assert.equal(g().t, t, '고르는 동안 시간이 안 흐름');
  page.listeners.win.keydown({ code: 'Digit2', preventDefault() {} });
  assert.equal(g().choices, null);
  page.frames(5);
  assert.ok(g().t > t);
  assert.equal(page.overlay.className, '');
});

// ---------- 난이도 표 도구 ----------
test('난이도 표 도구: 판수를 주면 두 봇의 표와 세 가지 기준 줄을 만든다', () => {
  const { text, stats, checks } = buildTable(E, 12);
  assert.equal(stats.novice.n, 12);
  assert.equal(stats.expert.n, 12);
  assert.match(text, /초보 봇/);
  assert.match(text, /숙련 봇/);
  assert.match(text, /재미의 기준 확인/);
  assert.equal(checks.length, 3);
  for (const k of ['novice', 'expert']) {
    assert.equal(stats[k].buckets.reduce((a, b) => a + b, 0), 12, '구간 합이 판수와 같아야 함');
    assert.equal(stats[k].buckets[stats[k].buckets.length - 1], stats[k].survived, '"3분 버팀" 칸 = 3분 버틴 판 수');
  }
  // 같은 규칙을 쓰는지: 표의 숫자가 runBotGame 결과와 일치
  let survived = 0;
  for (let s = 1; s <= 12; s++) if (E.runBotGame('expert', s, 180).survived) survived++;
  assert.equal(stats.expert.survived, survived);
});

// ---------- ② 그림 입히기 ----------
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..', '..');
const GAME = path.join(ROOT, 'game');

function pngSize(file) {
  const b = fs.readFileSync(file);
  assert.equal(b.slice(1, 4).toString(), 'PNG', file + ' 은 PNG 가 아님');
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}

test('그림: index.html 이 가리키는 그림 파일이 모두 존재한다', () => {
  const html = readHtml();
  const refs = [...html.matchAll(/'(assets\/[^']+\.png)'/g)].map(m => m[1]);
  assert.ok(refs.length >= 2, '그림 경로 ' + refs.length + '개');
  for (const r of refs) assert.ok(fs.existsSync(path.join(GAME, r)), '없는 그림: ' + r);
});

test('그림: 쓰는 그림은 모두 game/assets 안의 Kenney 폴더에 있고 License.txt 가 있다', () => {
  const html = readHtml();
  const refs = [...html.matchAll(/'(assets\/[^']+\.png)'/g)].map(m => m[1]);
  for (const r of refs) {
    assert.match(r, /^assets\/kenney-[a-z-]+\//, r);
    const dir = path.dirname(path.join(GAME, r));
    const lic = fs.readFileSync(path.join(dir, 'License.txt'), 'utf8');
    assert.match(lic, /Creative Commons Zero|CC0/, r + ' 의 License.txt');
  }
  assert.doesNotMatch(html, /\.(jpg|jpeg|gif|svg|webp)/i, 'Kenney png 외 그림 금지');
});

test('그림: 고른 칸 번호가 그림 파일 크기 안에 있다', () => {
  const html = readHtml();
  const tiny = pngSize(path.join(GAME, 'assets/kenney-tiny-dungeon/tilemap_packed.png'));
  const fx = pngSize(path.join(GAME, 'assets/kenney-particle-pack/fx_atlas.png'));
  const tiles = (tiny.w / 16) * (tiny.h / 16);
  const cells = fx.w / 32;
  const tb = html.match(/var TILES = \{([\s\S]*?)\};/)[1];
  const nums = tb.replace(/\/\/.*$/gm, '').match(/\d+/g).map(Number);
  assert.ok(nums.length >= 7, '주인공1 + 적4 + 보석1 + 무기1 = 7칸, 실제 ' + nums.length);
  for (const n of nums) assert.ok(n >= 0 && n < tiles, '타일 ' + n + ' / 총 ' + tiles);
  const fb = html.match(/var FX = \{([\s\S]*?)\};/)[1].replace(/\/\/.*$/gm, '').match(/\d+/g).map(Number);
  for (const n of fb) assert.ok(n >= 0 && n < cells, '효과 칸 ' + n + ' / 총 ' + cells);
});

test('CREDITS.md: 쓴 그림 묶음의 출처와 라이선스가 적혀 있다', () => {
  const c = fs.readFileSync(path.join(ROOT, 'CREDITS.md'), 'utf8');
  assert.match(c, /Tiny Dungeon/);
  assert.match(c, /Particle Pack/);
  assert.match(c, /Kenney/);
  assert.match(c, /CC0/);
  assert.match(c, /kenney\.nl/);
  assert.match(c, /tilemap_packed\.png/);
  assert.match(c, /fx_atlas\.png/);
});

test('그림: 그림이 불러와지면 그림으로 그리고, 못 불러오면 도형으로 대신 그린다', () => {
  const withImg = runPage('?seed=7', 390, 844, true);
  withImg.frames(60);
  assert.ok(withImg.drawCalls.image > 60, '그림 그리기 호출 ' + withImg.drawCalls.image);
  const noImg = runPage('?seed=7', 390, 844, false);
  noImg.frames(60);
  assert.equal(noImg.drawCalls.image, 0, '그림 없으면 도형만');
  assert.ok(noImg.drawCalls.n > 100);
});

test('효과: 적을 맞히면 데미지 숫자, 쓰러뜨리면 터짐이 나온다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.spawnTimer = 1e9;
  g.player.atkCd = 0;
  g.enemies.push({ x: g.player.x + 50, y: g.player.y, r: 7, hp: 999, maxHp: 999, speed: 0, dmg: 8, kind: 1, hitAt: -1 });
  let guard = 0;
  while (!g.enemies[0].hitAt || g.enemies[0].hitAt < 0) { page.frames(1); if (guard++ > 120) break; }
  assert.ok(g.enemies[0].hitAt > 0, '맞은 시각이 기록됨(깜빡임용)');
  assert.ok(page.drawCalls.texts.includes('10'), '데미지 숫자 10 이 그려져야 함');
  const imgBefore = page.drawCalls.image;
  g.enemies[0].hp = 1;                                 // 다음 한 방에 쓰러진다
  for (let i = 0; i < 60 && g.enemies.length; i++) page.frames(1);
  assert.equal(g.enemies.length, 0, '쓰러져야 함');
  assert.ok(g.kills >= 1);
  assert.ok(page.drawCalls.image > imgBefore + 2, '터짐 그림이 그려져야 함');
});

test('효과: 주인공이 맞으면 붉은 데미지 숫자가 나오고 깜빡인다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.spawnTimer = 1e9; g.player.atkCd = 1e9;
  g.enemies.push({ x: g.player.x, y: g.player.y, r: 7, hp: 999, maxHp: 999, speed: 0, dmg: 8, kind: 0, hitAt: -1 });
  page.frames(3);
  assert.equal(g.player.hp, 92);
  assert.ok(page.drawCalls.texts.includes('8'), '받은 피해 숫자 8');
  assert.ok(g.player.hurtCd > 0, '맞은 뒤 깜빡임(무적) 구간');
});

test('효과: 효과를 기록해도(events 켜도) 규칙과 결과는 그대로다', () => {
  for (const kind of ['novice', 'expert']) {
    const a = new E.Game({ seed: 11 }), b = new E.Game({ seed: 11, events: true });
    const ba = E.makeBot(kind, 11), bb = E.makeBot(kind, 11);
    for (let i = 0; i < 60 * 40; i++) { ba.act(a); bb.act(b); a.tick(); b.tick(); b.events.length = 0; }
    assert.equal(json(a.snapshot()), json(b.snapshot()), kind);
  }
});

test('효과: 빨리 감기 100배에서도 효과 기록이 매 프레임 비워진다', () => {
  const page = runPage('?seed=7&speed=100&bot=expert', 390, 844, true);
  for (let i = 0; i < 300 && !page.win.__sansin.game.over; i++) page.frames(1);
  assert.ok(page.drawCalls.n > 0);
  assert.ok(page.win.__sansin.game.events.length === 0, '효과 기록은 매 프레임 비워진다');
});

// ---------- ② 고침: 큰 그림, 바닥 타일, 또렷한 데미지 숫자 ----------
test('크기: 부딪히는 범위가 그림 크기에 맞게 두 배가 됐다', () => {
  assert.equal(E.CFG.player.r, 16);
  assert.equal(new E.Game({ seed: 1 }).player.r, 16);
  const g = new E.Game({ seed: 1 });
  g.spawnTimer = 0; g.tick();
  assert.equal(g.enemies[0].r, 14);
  assert.equal(E.CFG.gemR, 12);
  assert.equal(E.CFG.shot.r, 6);
});

test('크기: 화면에 그리는 그림이 크고 부딪히는 범위 안쪽을 덮는다', () => {
  const html = readHtml();
  const sizes = { hero: /TILES\.hero, p\.x, p\.y, (\d+)/, enemy: /en\.x, en\.y, (\d+)/, gem: /TILES\.gem, ge\.x, ge\.y \+ bob \* 2, (\d+)/ };
  const r = { hero: E.CFG.player.r, enemy: 14, gem: E.CFG.gemR };
  for (const k of Object.keys(sizes)) {
    const size = Number(html.match(sizes[k])[1]);
    assert.ok(size >= 28, k + ' 그림 크기 ' + size);
    assert.ok(size / 2 >= r[k] && size / 2 <= r[k] * 1.5, k + ': 그림 반지름 ' + size / 2 + ' / 부딪힘 ' + r[k]);
  }
});

test('바닥: tiny-dungeon 바닥 타일을 깔아 그린다', () => {
  const html = readHtml();
  const tiny = pngSize(path.join(GAME, 'assets/kenney-tiny-dungeon/tilemap_packed.png'));
  const nums = html.match(/var FLOOR = \[([^\]]*)\]/)[1].split(',').map(Number);
  for (const n of nums) assert.ok(n >= 0 && n < (tiny.w / 16) * (tiny.h / 16), '바닥 칸 ' + n);
  // 무늬 없는 한 가지 색 타일만 허용 (0번 갈색 맨땅, 48번 모래 맨땅). 돌무더기·막대·벽 무늬 타일은 금지
  assert.ok(nums.length >= 1 && nums.length <= 2, '바닥 종류 ' + nums.length);
  for (const n of nums) assert.ok([0, 48].includes(n), '무늬 있는 바닥 칸 ' + n);
  const dark = Number(html.match(/rgba\(0,0,0,([\d.]+)\)'; ctx\.fillRect\(0, 0, W, H\)/)[1]);
  assert.ok(dark >= 0.45, '바닥 어둡기 ' + dark);
  const a = runPage('?seed=7', 390, 844, true), b = runPage('?seed=7', 390, 844, false);
  a.frames(1); b.frames(1);
  assert.ok(a.drawCalls.image >= 200, '한 프레임에 바닥 타일 ' + a.drawCalls.image + '개');
  assert.equal(b.drawCalls.image, 0);
});

test('데미지 숫자: 흰색 글자에 검은 굵은 테두리, 충분히 크다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.spawnTimer = 1e9; g.player.atkCd = 0;
  g.enemies.push({ x: g.player.x + 60, y: g.player.y, r: 14, hp: 999, maxHp: 999, speed: 0, dmg: 8, kind: 0, hitAt: -1 });
  for (let i = 0; i < 40; i++) page.frames(1);
  const white = page.drawCalls.fills.filter(f => f.t === '10');
  assert.ok(white.length > 0, '데미지 숫자 10');
  assert.ok(white.every(f => f.color === '#ffffff'), '글자색 ' + [...new Set(white.map(f => f.color))]);
  const st = page.drawCalls.strokes.filter(f => f.t === '10');
  assert.ok(st.length > 0 && st.every(f => f.color === '#000000' && f.width >= 4), '테두리 ' + json(st[0]));
  const fontSize = Number(readHtml().match(/NUM_FONT_PX = (\d+)/)[1]);
  assert.ok(fontSize >= 16, '글자 크기 ' + fontSize);
});

// ---------- ③ 강화와 보스 ----------
// 실제 판에서 강화를 고르는 것과 똑같이 g.choose() 로 적용한다
function pick(g, id) {
  const u = E.UPGRADES.find(x => x.id === id);
  g.choices = [u];
  assert.equal(g.choose(0), true);
}
// 꿈쩍 않는 튼튼한 표적을 사거리 안에 세워 두고 seconds 초 동안 쏜 뒤 준 피해 합계를 돌려준다
function damageDealt(g, seconds) {
  const p = g.player;
  const dummy = { x: p.x + 120, y: p.y, r: 14, hp: 1e9, maxHp: 1e9, speed: 0, dmg: 0, kind: 0, hitAt: -1 };
  g.enemies.push(dummy);
  g.player.atkCd = 0;
  for (let i = 0; i < Math.round(seconds * 60); i++) g.tick();
  return 1e9 - dummy.hp;
}

test('강화 효과(공격 속도): 고르면 같은 시간에 실제로 더 많이 쏜다', () => {
  const a = freshGame(), b = freshGame();
  pick(b, 'attackSpeed'); pick(b, 'attackSpeed'); pick(b, 'attackSpeed');
  assert.ok(Math.abs(b.player.atkInterval - 0.5 * 0.85 ** 3) < 1e-9, '간격 ' + b.player.atkInterval);
  const da = damageDealt(a, 6), db = damageDealt(b, 6);
  assert.ok(db > da * 1.3, '기본 ' + da + ' → 3번 강화 ' + db);
});

test('강화 효과(공격 속도): 아무리 골라도 간격이 0.1초 밑으로 내려가지 않는다', () => {
  const g = freshGame();
  for (let i = 0; i < 30; i++) pick(g, 'attackSpeed');
  assert.equal(g.player.atkInterval, 0.1);
});

test('강화 효과(공격력): 고르면 한 방에 실제로 더 많이 깎는다', () => {
  const a = freshGame(), b = freshGame();
  pick(b, 'damage');
  assert.equal(b.player.dmg, a.player.dmg + 4);
  const da = damageDealt(a, 3), db = damageDealt(b, 3);
  assert.ok(da > 0 && da % 10 === 0, '기본은 한 방 10: ' + da);
  assert.ok(db > 0 && db % 14 === 0, '강화 뒤 한 방 14: ' + db);
});

test('강화 효과(이동 속도): 고르면 같은 시간에 실제로 더 멀리 간다', () => {
  const dist = g => { const x0 = g.player.x; g.input.x = 1; for (let i = 0; i < 60; i++) g.tick(); return g.player.x - x0; };
  const a = freshGame(), b = freshGame();
  pick(b, 'moveSpeed');
  const da = dist(a), db = dist(b);
  assert.ok(Math.abs(da - 110) < 0.5, '기본 1초 ' + da);
  assert.ok(Math.abs(db / da - 1.1) < 0.01, '강화 뒤 ' + db);
});

test('강화 효과(체력): 최대 체력이 늘고 20 회복되며, 실제로 더 오래 버틴다', () => {
  const survive = g => {
    const p = g.player;
    g.enemies.push({ x: p.x, y: p.y, r: 14, hp: 1e9, maxHp: 1e9, speed: 0, dmg: 8, kind: 0, hitAt: -1 });
    let n = 0; while (!g.over && n++ < 60 * 60) g.tick();
    return g.deathTime;
  };
  const a = freshGame(), b = freshGame();
  b.player.hp = 60;
  pick(b, 'maxHp');
  assert.equal(b.player.maxHp, 120);
  assert.equal(b.player.hp, 80, '20 회복');
  b.player.hp = b.player.maxHp;
  const ta = survive(a), tb = survive(b);
  assert.ok(tb > ta + 1, '기본 ' + ta.toFixed(1) + '초 → 강화 ' + tb.toFixed(1) + '초');
});

test('강화 효과: 여러 번 고르면 쌓이고, 네 가지가 서로의 수치를 건드리지 않는다', () => {
  const g = freshGame();
  const base = { ...g.player };
  pick(g, 'damage'); pick(g, 'damage');
  assert.equal(g.player.dmg, base.dmg + 8);
  assert.equal(g.player.speed, base.speed);
  assert.equal(g.player.atkInterval, base.atkInterval);
  assert.equal(g.player.maxHp, base.maxHp);
  pick(g, 'moveSpeed');
  assert.equal(g.player.dmg, base.dmg + 8);
  assert.ok(g.player.speed > base.speed);
});

test('강화 설명: 네 가지 모두 이름과 설명이 있다', () => {
  for (const u of E.UPGRADES) { assert.ok(u.name.length > 0 && u.desc.length > 0, u.id); }
});

test('보스: 3분 전에는 없고, 3분이 되면 정확히 한 마리 등장한다', () => {
  const g = freshGame();
  g.t = 179.5;
  for (let i = 0; i < 20; i++) g.tick();            // 179.5 ~ 179.83초
  assert.equal(g.boss, null);
  assert.equal(g.bossSpawned, false);
  assert.ok(!g.enemies.some(e => e.boss));
  for (let i = 0; i < 20; i++) g.tick();            // 180초를 넘김
  assert.ok(g.t >= 180);
  assert.ok(g.boss, '보스가 나와야 함');
  assert.equal(g.bossSpawned, true);
  assert.equal(g.enemies.filter(e => e.boss).length, 1);
  assert.ok(g.bossAt >= 180 && g.bossAt < 180.1, '등장 시각 ' + g.bossAt);
  for (let i = 0; i < 600; i++) g.tick();
  assert.equal(g.enemies.filter(e => e.boss).length, 1, '계속 한 마리');
});

test('보스: 일반 적보다 훨씬 크고 튼튼하고 세다', () => {
  const g = freshGame();
  g.t = 179.99;
  g.tick(); g.tick();
  const b = g.boss;
  assert.ok(b.r >= 28 && b.r >= 2 * 14, '크기 ' + b.r);
  assert.ok(b.hp >= 20 * 21, '체력 ' + b.hp + ' (일반 적 3분 체력 약 21)');
  assert.ok(b.dmg > 8, '공격력 ' + b.dmg);
  assert.equal(b.hp, b.maxHp);
});

test('보스: 걸어서 주인공 쪽으로 다가온다', () => {
  const g = freshGame();
  g.t = 179.99; g.tick(); g.tick();
  const d0 = Math.hypot(g.player.x - g.boss.x, g.player.y - g.boss.y);
  for (let i = 0; i < 120; i++) g.tick();
  assert.ok(Math.hypot(g.player.x - g.boss.x, g.player.y - g.boss.y) < d0 - 30);
});

test('보스: 쓰러뜨리면 승리하고 판이 멈춘다', () => {
  const g = freshGame();
  g.t = 179.99; g.tick(); g.tick();
  const p = g.player, b = g.boss;
  b.x = p.x + 80; b.y = p.y; b.speed = 0; b.hp = 15;     // 한 방 10 → 두 방
  g.player.atkCd = 0;
  let n = 0;
  while (!g.over && n++ < 600) g.tick();
  assert.equal(g.over, true);
  assert.equal(g.won, true, '이겨야 함');
  assert.ok(g.winTime >= 180, '승리 시각 ' + g.winTime);
  assert.equal(g.deathTime, null, '졌다고 기록되면 안 됨');
  assert.ok(p.hp > 0);
  assert.equal(g.enemies.some(e => e.boss), false);
  const t = g.t;
  assert.equal(g.tick(), false);
  assert.equal(g.t, t, '이긴 뒤에는 시간이 안 흐름');
  assert.equal(g.snapshot().won, true);
});

test('보스: 보스가 살아 있으면 다른 적을 다 잡아도 승리가 아니다', () => {
  const g = freshGame();
  g.t = 179.99; g.tick(); g.tick();
  g.enemies = g.enemies.filter(e => e.boss);
  g.boss.speed = 0; g.boss.x = 10; g.boss.y = 10;
  for (let i = 0; i < 300; i++) g.tick();
  assert.equal(g.won, false);
  assert.equal(g.over, false);
});

test('패배: 보스에게 맞아 체력이 0이 되면 지고, 이긴 것으로 기록되지 않는다', () => {
  const g = freshGame();
  g.t = 179.99; g.tick(); g.tick();
  const p = g.player, b = g.boss;
  b.x = p.x; b.y = p.y; b.speed = 0;
  let n = 0;
  while (!g.over && n++ < 600) g.tick();
  assert.equal(g.over, true);
  assert.equal(g.won, false);
  assert.equal(p.hp, 0);
  assert.ok(g.deathTime >= 180, '쓰러진 시각 ' + g.deathTime);
  assert.equal(g.winTime, null);
  assert.equal(g.boss.hp > 0, true);
  const t = g.t;
  assert.equal(g.tick(), false);
  assert.equal(g.t, t);
  assert.equal(g.snapshot().deathTime, g.deathTime);
});

test('보스: 3분 전의 판은 난수를 더 쓰지 않아서 같은 seed면 늘 똑같다', () => {
  const run = () => {
    const g = new E.Game({ seed: 7 }), bot = E.makeBot('expert', 7);
    for (let i = 0; i < 60 * 60; i++) { bot.act(g); g.tick(); }
    return g;
  };
  const a = run(), b = run();
  assert.equal(json(a.snapshot()), json(b.snapshot()));
  assert.equal(a.bossSpawned, false);
});

test('보스: 봇이 보스전까지 끝까지 돌고(이기거나 지거나), 같은 seed면 결과가 같다', () => {
  for (const kind of ['novice', 'expert']) {
    for (let seed = 1; seed <= 12; seed++) {
      const r = E.runBotGame(kind, seed, 360);
      assert.ok(Number.isFinite(r.time) && r.time > 0 && r.time <= 360.01, kind + seed + ' time=' + r.time);
      if (r.bossSpawned) assert.ok(r.time >= 180, '보스가 나왔는데 시간이 ' + r.time);
      if (r.won) assert.ok(r.bossSpawned && r.survived);
      assert.equal(json(r), json(E.runBotGame(kind, seed, 360)), kind + seed);
    }
  }
});

test('보스: 숙련 봇은 보스를 이길 수 있지만 매번 이기지는 못한다', () => {
  let expertWins = 0;
  for (let seed = 1; seed <= 40; seed++) if (E.runBotGame('expert', seed, 360).won) expertWins++;
  assert.ok(expertWins >= 1, '숙련 봇 승리 ' + expertWins + '판 (이길 수 있어야 함)');
  assert.ok(expertWins < 40, '숙련 봇이 40판 모두 이기면 보스가 너무 약함');
});

// ----- 화면: 보스 그림, 체력바, 승리 화면 -----
test('보스 그림: 일반 적·주인공·보석·무기와 다른 칸이고, 두 배 크기로 그린다', () => {
  const html = readHtml();
  const boss = Number(html.match(/boss: (\d+),/)[1]);
  const tiny = pngSize(path.join(GAME, 'assets/kenney-tiny-dungeon/tilemap_packed.png'));
  assert.ok(boss >= 0 && boss < (tiny.w / 16) * (tiny.h / 16));
  const enemies = html.match(/enemies: \[([^\]]*)\]/)[1].split(',').map(Number);
  const others = [...enemies, Number(html.match(/hero: (\d+)/)[1]), Number(html.match(/gem: (\d+)/)[1]), Number(html.match(/shot: (\d+)/)[1])];
  assert.ok(!others.includes(boss), '보스 그림이 다른 것과 겹침');
  const bossSize = Number(html.match(/TILES\.boss, bs\.x, bs\.y, (\d+)/)[1]);
  const enemySize = Number(html.match(/en\.x, en\.y, (\d+)/)[1]);
  assert.ok(bossSize >= enemySize * 2 - 1, '보스 ' + bossSize + ' / 일반 적 ' + enemySize);
  assert.ok(bossSize / 2 >= E.CFG.boss.r && bossSize / 2 <= E.CFG.boss.r * 1.5);
});

test('화면 코드: 3분이 되면 보스 그림·체력바·이름·"보스 등장!"이 그려진다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.spawnTimer = 1e9; g.t = 179.9;
  page.frames(3);
  assert.equal(g.boss, null, '아직 3분 전');
  assert.ok(!page.drawCalls.texts.includes('붉은 도깨비'));
  page.frames(10);
  assert.ok(g.boss && g.boss.hp > 0, '보스 등장');
  page.frames(2);
  assert.ok(page.drawCalls.texts.includes('붉은 도깨비'), '보스 이름(체력바)');
  assert.ok(page.drawCalls.texts.includes('보스 등장!'), '등장 알림');
});

test('화면 코드: 보스를 쓰러뜨리면 "승리!" 화면과 다시 하기 버튼이 뜬다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.spawnTimer = 1e9; g.t = 179.95;
  page.frames(6);
  assert.ok(g.boss, '보스 등장');
  g.enemies = [g.boss];
  g.boss.x = g.player.x + 60; g.boss.y = g.player.y; g.boss.speed = 0; g.boss.hp = 5;
  g.player.atkCd = 0;
  let n = 0;
  while (!g.over && n++ < 300) page.frames(1);
  assert.equal(g.won, true, '이겨야 함');
  page.frames(2);
  assert.equal(page.overlay.className, 'on');
  assert.ok(page.panel.children.some(c => c.textContent === '승리!'), '승리 제목');
  assert.ok(!page.panel.children.some(c => c.textContent === '쓰러졌다'));
  assert.ok(page.panel.children.some(c => c.textContent === '다시 하기'));
});

test('화면 코드: ?speed=10으로 3분을 빨리 돌리면 보스가 나오고 끝(승리 또는 패배) 화면이 뜬다', () => {
  for (const bot of ['expert', 'novice']) {
    const page = runPage('?seed=3&speed=10&bot=' + bot, 390, 844, true);
    const g = page.win.__sansin.game;
    let sawBoss = false, n = 0;
    while (!g.over && n++ < 20000) { page.frames(1); if (g.boss) sawBoss = true; }
    assert.ok(g.over, bot + ': 끝나야 함');
    page.frames(2);
    assert.equal(page.overlay.className, 'on');
    const titles = page.panel.children.map(c => c.textContent);
    assert.ok(titles.includes(g.won ? '승리!' : '쓰러졌다'), bot + ' 화면 ' + titles.join('|'));
    if (g.won) assert.ok(sawBoss);
  }
});

test('난이도 표 도구: 보스전 줄(이김/짐/시간 초과)이 표에 나온다', () => {
  const { text, stats } = buildTable(E, 10);
  assert.match(text, /보스전/);
  for (const k of ['novice', 'expert']) {
    const b = stats[k].boss;
    assert.equal(b.won + b.lost + b.timeout, b.reached, k + ': 이김+짐+시간초과 = 보스까지 간 판');
    assert.equal(b.reached, stats[k].survived, k + ': 보스까지 간 판 = 3분 버틴 판');
  }
});

// ---------- ④ 난이도 맞추기: 줍지 않은 보석은 사라진다 ----------
test('보석 수명: 줍지 않은 보석은 gemLife초 뒤에 사라진다', () => {
  const g = freshGame();
  g.player.x = 20; g.player.y = 20;
  g.gems.push({ x: 340, y: 600, v: 1, life: E.CFG.gemLife });   // 멀리 있어서 못 줍는 보석
  const ticks = Math.round((E.CFG.gemLife - 1) / E.TICK);
  for (let i = 0; i < ticks; i++) g.tick();
  assert.equal(g.gems.length, 1, '수명이 남아 있는 동안은 그대로');
  for (let i = 0; i < Math.round(2 / E.TICK); i++) g.tick();
  assert.equal(g.gems.length, 0, '수명이 끝나면 사라져야 함');
  assert.equal(g.xp, 0, '사라진 보석은 경험치를 주지 않음');
});

test('보석 수명: 새로 떨어진 보석은 수명을 가지고, 수명 안에 주우면 경험치가 오른다', () => {
  assert.equal(E.CFG.gemLife, 12);
  const g = freshGame();
  g.enemies.push({ x: g.player.x + 40, y: g.player.y, r: 14, hp: 1, maxHp: 1, speed: 0, dmg: 0, kind: 0, hitAt: -1 });
  g.shots.push({ x: g.player.x + 40, y: g.player.y, vx: 0, vy: 0, life: 1, dmg: 50 });
  g.tick();
  assert.equal(g.gems.length + Math.floor(g.xp), 1);
  if (g.gems.length) assert.ok(g.gems[0].life > E.CFG.gemLife - 0.1);
});

test('난이도 맞추기: 봇 100판 표에서 재미의 기준 세 가지가 모두 통과한다', () => {
  const t = buildTable(E, 100);
  t.checks.forEach(c => assert.ok(c.ok, c.name + ' → ' + c.value));
});

test('난이도 맞추기: 숙련 봇 화면의 보석이 너무 쌓이지 않는다 (동시에 60개 미만)', () => {
  let worst = 0;
  for (let seed = 1; seed <= 30; seed++) {
    const g = new E.Game({ seed }), bot = E.makeBot('expert', seed);
    while (!g.over && g.t < 180) { bot.act(g); g.tick(); worst = Math.max(worst, g.gems.length); }
  }
  assert.ok(worst < 60, '가장 많이 쌓인 때 ' + worst + '개');
});

// ---------- ⑤ UI 입히기 ----------
const crypto = require('crypto');
const UI_DIR = path.join(GAME, 'assets', 'kenney-ui-pixel-adventure');
const FONT_DIR = path.join(GAME, 'assets', 'galmuri');

test('UI 자료: Kenney UI Pack 그림이 있고 License.txt 가 CC0 이다', () => {
  const lic = fs.readFileSync(path.join(UI_DIR, 'License.txt'), 'utf8');
  assert.match(lic, /UI Pack - Pixel Adventure/);
  assert.match(lic, /Creative Commons Zero, CC0/);
  const need = ['large_0000', 'large_0003', 'large_0032', 'large_0043', 'large_0044', 'large_0045', 'small_0129', 'small_0130', 'small_0131'];
  for (const n of need) {
    const f = path.join(UI_DIR, n + '.png');
    assert.ok(fs.existsSync(f), '없는 파일 ' + n);
    const sz = pngSize(f);
    assert.equal(sz.w, n.startsWith('large') ? 32 : 16, n + ' 가로');
    assert.equal(sz.h, n.startsWith('large') ? 32 : 16, n + ' 세로');
  }
  const html = readHtml();
  for (const n of need) assert.ok(html.includes('assets/kenney-ui-pixel-adventure/' + n + '.png'), 'index.html 이 안 쓰는 그림 ' + n);
});

test('UI 자료: 갈무리 글꼴 파일이 있고 LICENSE.txt 가 SIL OFL 1.1 이다', () => {
  const lic = fs.readFileSync(path.join(FONT_DIR, 'LICENSE.txt'), 'utf8');
  assert.match(lic, /SIL OPEN FONT LICENSE Version 1\.1/);
  assert.match(lic, /Lee Minseo/);
  const html = readHtml();
  for (const f of ['Galmuri11.woff2', 'Galmuri11-Bold.woff2']) {
    const file = path.join(FONT_DIR, f);
    assert.ok(fs.existsSync(file), '없는 글꼴 ' + f);
    assert.equal(fs.readFileSync(file).slice(0, 4).toString(), 'wOF2', f + ' 은 woff2 가 아님');
    assert.ok(html.includes("url('assets/galmuri/" + f + "')"), 'index.html 이 글꼴 ' + f + ' 를 불러와야 함');
  }
});

test('UI 자료: assets 에는 쓰는 폴더만 있고, 글꼴 폴더에는 쓰는 파일과 라이선스만 있다', () => {
  const dirs = fs.readdirSync(path.join(GAME, 'assets')).sort();
  assert.deepEqual(dirs, ['galmuri', 'kenney-particle-pack', 'kenney-tiny-dungeon', 'kenney-ui-pixel-adventure', 'og-image.png']);
  assert.deepEqual(fs.readdirSync(FONT_DIR).sort(), ['Galmuri11-Bold.woff2', 'Galmuri11.woff2', 'LICENSE.txt']);
});

test('CREDITS.md: UI Pack 과 갈무리의 출처·라이선스가 적혀 있다', () => {
  const c = fs.readFileSync(path.join(ROOT, 'CREDITS.md'), 'utf8');
  assert.match(c, /UI Pack - Pixel Adventure/);
  assert.match(c, /kenney\.nl\/assets\/ui-pack-pixel-adventure/);
  assert.match(c, /갈무리|Galmuri/);
  assert.match(c, /github\.com\/quiple\/galmuri/);
  assert.match(c, /SIL Open Font License 1\.1/);
  assert.match(c, /LICENSE\.txt/);
});

test('index.html: 창과 단추는 Kenney 그림 테두리로 꾸미고 글자는 갈무리를 쓴다', () => {
  const html = readHtml();
  assert.match(html, /border-image:\s*url\('assets\/kenney-ui-pixel-adventure\/large_0032\.png'\)/, '창 테두리');
  assert.match(html, /border-image:\s*url\('assets\/kenney-ui-pixel-adventure\/large_0000\.png'\)/, '단추');
  assert.match(html, /image-rendering:\s*pixelated/);
  assert.match(html, /font-family:\s*Galmuri11/);
  assert.doesNotMatch(html, /px sans-serif/, "canvas 글자가 기본 글꼴('px sans-serif')로 남아 있음");
});

test('처음 시작 화면: 제목과 시작 단추가 뜨고, 누르기 전에는 판이 흐르지 않는다', () => {
  const page = runPage('?seed=7&speed=10&bot=expert', 390, 844, true, { stayOnTitle: true });
  page.frames(120);
  const g = page.win.__sansin.game;
  assert.equal(page.win.__sansin.started, false);
  assert.equal(page.overlay.className, 'on');
  assert.ok(page.panel.children.some(c => c.textContent === '산신령의 밤'), '제목');
  assert.ok(page.panel.children.some(c => c.textContent === '시작'), '시작 단추');
  assert.equal(g.tickCount, 0, '시작 전에는 한 틱도 안 흐름');
  assert.equal(g.t, 0);
  assert.ok(page.drawCalls.n > 100, '뒤의 놀이터는 그려짐');
});

test('처음 시작 화면: 시작 단추를 누르면 창이 닫히고 판이 흐른다. 판은 기다린 시간과 상관없이 같다', () => {
  const page = runPage('?seed=7', 390, 844, true, { stayOnTitle: true });
  page.frames(30);
  page.panel.children.find(c => c.textContent === '시작').listeners.click();
  page.frames(2);
  assert.equal(page.win.__sansin.started, true);
  assert.equal(page.overlay.className, '');
  page.frames(60);
  const g = page.win.__sansin.game;
  assert.ok(g.tickCount > 50, '판이 흐름 ' + g.tickCount);
  const ref = new E.Game({ seed: 7, events: true });
  for (let i = 0; i < g.tickCount; i++) ref.tick();
  assert.equal(json(g.snapshot()), json(ref.snapshot()), '같은 seed 같은 판');
});

test('처음 시작 화면: Enter 키로도 시작하고, 시작 전의 1~3 키·방향키는 판에 영향이 없다', () => {
  const page = runPage('?seed=7', 390, 844, true, { stayOnTitle: true });
  page.frames(2);
  page.listeners.win.keydown({ code: 'ArrowLeft', preventDefault() {} });
  page.listeners.win.keydown({ code: 'Digit1', preventDefault() {} });
  page.frames(20);
  assert.equal(page.win.__sansin.game.tickCount, 0);
  page.listeners.win.keyup({ code: 'ArrowLeft' });
  page.listeners.win.keydown({ code: 'Enter', preventDefault() {} });
  page.frames(5);
  assert.equal(page.win.__sansin.started, true);
  assert.ok(page.win.__sansin.game.tickCount > 0);
  assert.equal(page.overlay.className, '');
});

test('위쪽 정보: 체력·경험치 바와 레벨·시간이 갈무리 글꼴로 그려진다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(70);
  const t = page.drawCalls.texts;
  for (const want of ['HP', 'EXP', 'Lv 1']) assert.ok(t.includes(want), want + ' 글자');
  assert.ok(t.some(x => /^\d:\d\d$/.test(x)), '시간 0:00 모양');
  assert.ok(page.drawCalls.fontsUsed.size > 0);
  for (const f of page.drawCalls.fontsUsed) assert.match(f, /Galmuri11/, '글꼴 ' + f);
  assert.ok(page.fonts.length >= 2, '글꼴 미리 불러오기 ' + page.fonts.length);
});

test('위쪽 정보: 바는 체력·경험치 비율만큼 채워지고, 그림 틀이 그려진다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.spawnTimer = 1e9; g.player.atkCd = 1e9;
  const w = color => { const r = page.drawCalls.rects.filter(x => x.color === color); return r.length ? r[r.length - 1].w : -1; };
  const full = 150 - 10 * 1.5;                                  // 체력 바 안쪽 길이
  page.frames(1);
  assert.ok(Math.abs(w('#e25b5b') - full) < 0.01, '체력 가득 ' + w('#e25b5b'));
  g.player.hp = g.player.maxHp / 2;
  g.xp = g.xpNext / 4;
  page.frames(1);
  assert.ok(Math.abs(w('#e25b5b') - full / 2) < 0.01, '체력 절반 ' + w('#e25b5b'));
  assert.ok(Math.abs(w('#6fb7ff') - (150 - 10) / 4) < 0.01, '경험치 1/4 ' + w('#6fb7ff'));
  const before = page.drawCalls.image;
  page.frames(1);
  assert.ok(page.drawCalls.image - before >= 9 + 3 + 3, '정보 판(9조각) + 바 틀 두 개(3조각씩) 그림 ' + (page.drawCalls.image - before));
  const none = runPage('?seed=7', 390, 844, false);
  none.frames(5);
  assert.equal(none.drawCalls.image, 0, '그림이 없으면 도형으로 대신 그림');
  assert.ok(none.drawCalls.texts.includes('HP'));
});

test('보스: 이름표·체력바가 비율대로 그려진다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.spawnTimer = 1e9; g.player.atkCd = 1e9;
  g.t = E.CFG.boss.time;
  page.frames(2);
  assert.ok(g.boss && g.boss.hp > 0);
  g.boss.speed = 0;
  g.boss.hp = g.boss.maxHp * 0.4;
  page.frames(1);
  const r = page.drawCalls.rects.filter(x => x.color === '#ff4040');
  const inner = (360 - 80) - 10 * 1.5;
  assert.ok(Math.abs(r[r.length - 1].w - inner * 0.4) < 0.01, '보스 체력 40% ' + r[r.length - 1].w);
  assert.ok(page.drawCalls.texts.includes('붉은 도깨비'));
  assert.ok(page.drawCalls.texts.includes('보스 등장!'));
});

test('레벨업 창: 강화 3개가 단추로 뜨고, 단추를 누르면 고른 강화가 적용되어 창이 닫힌다', () => {
  const page = runPage('?seed=7', 390, 844, true);
  page.frames(2);
  const g = page.win.__sansin.game;
  g.xp = g.xpNext;
  page.frames(3);
  assert.ok(g.choices);
  const picks = g.choices.slice();
  const buttons = page.panel.children.filter(c => c.className === 'choice');
  assert.equal(buttons.length, 3);
  buttons.forEach((b, i) => {
    assert.ok(textOf(b).includes(picks[i].name), '이름 ' + picks[i].name);
    assert.ok(textOf(b).includes(picks[i].desc), '설명 ' + picks[i].desc);
  });
  const before = JSON.stringify([g.player.atkInterval, g.player.dmg, g.player.speed, g.player.maxHp]);
  buttons[1].listeners.click();
  assert.equal(g.choices, null);
  const after = JSON.stringify([g.player.atkInterval, g.player.dmg, g.player.speed, g.player.maxHp]);
  assert.notEqual(after, before, '고른 강화가 적용됨: ' + picks[1].id);
  page.frames(3);
  assert.equal(page.overlay.className, '');
  assert.equal(g.level, 2);
});

test('승리·패배 화면: 제목과 요약, 다시 하기 단추. 누르면 시작 화면 없이 바로 새 판이 시작된다', () => {
  const page = runPage('?seed=7&speed=100&bot=novice', 390, 844, true);
  let guard = 0;
  while (!page.win.__sansin.game.over && guard++ < 20000) page.frames(1);
  page.frames(2);
  const kids = page.panel.children;
  assert.ok(kids.some(c => c.textContent === '쓰러졌다'), '패배 제목');
  assert.ok(kids.some(c => /^버틴 시간 \d+:\d\d · 레벨 \d+ · 처치 \d+$/.test(c.textContent)), '패배 요약');
  const oldGame = page.win.__sansin.game;
  kids.find(c => c.textContent === '다시 하기').listeners.click();
  page.frames(3);
  const g = page.win.__sansin.game;
  assert.notEqual(g, oldGame, '새 판 객체');
  assert.equal(g.over, false);
  assert.ok(g.t < 10, '새 판 (빨리 감기 100배로 3프레임 = 약 5초) ' + g.t);
  assert.equal(page.overlay.className, '', '시작 화면이 다시 뜨지 않음');
  assert.equal(page.win.__sansin.started, true);
});

test('규칙 숫자 그대로: 게임 규칙 블록(engine)이 ④ 커밋과 글자 하나까지 같다', () => {
  const code = extractScript(readHtml(), 'engine');
  const hash = crypto.createHash('sha256').update(code).digest('hex');
  assert.equal(hash, '2df4d6571ba2f52a2ac932eef91c5d0cd812db561d83b7c0d8fc39ba070690ca');
  assert.equal(code.length, 13670);
});

test('난이도 표: 봇 100판씩 돌린 표가 ④에서 저장한 reports/difficulty-table.txt 와 똑같다', () => {
  const saved = fs.readFileSync(path.join(ROOT, 'reports', 'difficulty-table.txt'), 'utf8').replace(/\r\n/g, '\n').trim();
  const now = buildTable(E, 100).text.replace(/\r\n/g, '\n').trim();
  assert.equal(now, saved);
});
