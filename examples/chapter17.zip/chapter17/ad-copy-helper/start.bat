@echo off
chcp 65001 >nul
cd /d "%~dp0"
python app.py
if errorlevel 1 (
  echo.
  echo 실행 중 문제가 생겼어요. 위 안내를 확인해 주세요.
  pause
)
