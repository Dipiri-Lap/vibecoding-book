"""테스트: 실제 API 는 절대 부르지 않고 가짜 응답만 쓴다.  실행: python -m unittest -v"""
import contextlib
import http.client
import io
import json
import re
import tempfile
import threading
import unittest
from pathlib import Path

import app

FAKE_KEY = "sk-ant-api03-FAKEKEYFORTESTING-0123456789abcdef"
BASE = Path(app.__file__).resolve().parent
INPUTS = {"name": "물병", "features": "가볍고 보온 12시간", "audience": "등산객"}


def cfg(**over):
    c = app.load_config()
    c.update(over)
    return c


def reply(cands, in_tok=100, out_tok=50):
    text = json.dumps({"candidates": [{"title": t, "description": d} for t, d in cands]}, ensure_ascii=False)
    return {"content": [{"type": "text", "text": text}], "usage": {"input_tokens": in_tok, "output_tokens": out_tok}}


GOOD = [("가벼운 보온병", "하루 종일 따뜻한 물, 등산 가방에 쏙")] * 5  # 제목 7자, 설명 짧음
LONG_TITLE = [("이 제목은 열다섯 글자를 훨씬 넘어가는 긴 제목입니다", "짧은 설명")] * 5


class FakeApi:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = 0

    def __call__(self, system, user):
        r = self.responses[min(self.calls, len(self.responses) - 1)]
        self.calls += 1
        if isinstance(r, Exception):
            raise r
        return r


class Env:
    """임시 폴더 + 가짜 키 + 가짜 API 로 서버를 띄운다."""

    def __init__(self, fake, **cfg_over):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = cfg(**cfg_over)
        self.fake = fake
        self.server = app.create_server(self.cfg, FAKE_KEY, fake, Path(self.tmp.name) / "usage.json", BASE, port=0)
        self.port = self.server.server_address[1]
        self.log = io.StringIO()
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self._redir = contextlib.redirect_stderr(self.log)
        self._redir.__enter__()
        self.thread.start()
        return self

    def __exit__(self, *a):
        self.server.shutdown()
        self.server.server_close()
        self._redir.__exit__(*a)
        self.tmp.cleanup()

    def request(self, method, path, body=None, headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        h = {"Content-Type": "application/json"} if body is not None else {}
        h.update(headers or {})
        conn.request(method, path, json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None, h)
        r = conn.getresponse()
        raw = r.read()
        conn.close()
        return r.status, raw.decode("utf-8"), dict(r.getheaders())


class LengthRules(unittest.TestCase):
    def test_counts_by_program(self):
        c = cfg()
        checked = app.check_lengths([{"title": "열다섯글자까지는괜찮아요아", "description": "x"}], c)
        self.assertEqual(checked[0]["title_len"], len("열다섯글자까지는괜찮아요아"))
        self.assertEqual(checked[0]["title_len"], 13)
        self.assertFalse(checked[0]["title_over"])
        checked = app.check_lengths([{"title": "가" * 16, "description": "나" * 46}], c)
        self.assertTrue(checked[0]["title_over"])
        self.assertTrue(checked[0]["desc_over"])
        checked = app.check_lengths([{"title": "가" * 15, "description": "나" * 45}], c)
        self.assertFalse(checked[0]["title_over"] or checked[0]["desc_over"])

    def test_retry_then_ok(self):
        fake = FakeApi(reply(LONG_TITLE), reply(GOOD))
        with tempfile.TemporaryDirectory() as d:
            res = app.generate(INPUTS, cfg(), fake, app.UsageStore(Path(d) / "u.json"))
        self.assertEqual(fake.calls, 2)
        self.assertEqual(res["violations"], 0)
        self.assertEqual(res["attempts"], 2)
        self.assertEqual(res["tokens"]["total"], 300)  # 재시도 토큰도 합산

    def test_still_over_after_retries_is_flagged(self):
        fake = FakeApi(reply(LONG_TITLE))
        with tempfile.TemporaryDirectory() as d:
            res = app.generate(INPUTS, cfg(), fake, app.UsageStore(Path(d) / "u.json"))
        self.assertEqual(fake.calls, 3)  # 처음 1번 + 다시 받기 2번
        self.assertEqual(res["violations"], 5)
        self.assertTrue(all(c["title_over"] for c in res["candidates"]))

    def test_no_retry_when_zero(self):
        fake = FakeApi(reply(LONG_TITLE))
        with tempfile.TemporaryDirectory() as d:
            app.generate(INPUTS, cfg(), fake, app.UsageStore(Path(d) / "u.json"), max_retries=0)
        self.assertEqual(fake.calls, 1)

    def test_broken_json_is_error_not_crash(self):
        fake = FakeApi({"content": [{"type": "text", "text": "{잘린 응답"}], "usage": {"input_tokens": 1, "output_tokens": 500}})
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(app.AppError):
                app.generate(INPUTS, cfg(), fake, app.UsageStore(Path(d) / "u.json"))


class Diagnostics(unittest.TestCase):
    def test_diagnose_shows_head_and_hides_key(self):
        resp = {"stop_reason": "max_tokens", "content": [{"type": "text", "text": f"서론 {FAKE_KEY} 길게 " * 100}],
                "usage": {"output_tokens": 800}}
        line = app.diagnose(resp, FAKE_KEY)
        self.assertIn("max_tokens", line)
        self.assertIn("서론", line)
        self.assertNotIn(FAKE_KEY, line)
        self.assertIsNone(re.search(r"sk-ant-[A-Za-z0-9_\-]{8,}", line))
        self.assertLess(len(line), 600)

    def test_failure_writes_diagnosis_to_log_without_key(self):
        bad = {"stop_reason": "max_tokens", "content": [{"type": "text", "text": f"{{잘림 {FAKE_KEY}"}],
               "usage": {"input_tokens": 1, "output_tokens": 800}}
        with Env(FakeApi(bad)) as e:
            e.request("POST", "/api/generate", INPUTS)
            log = e.log.getvalue()
            self.assertIn("[진단]", log)
            self.assertNotIn(FAKE_KEY, log)


class CostGuards(unittest.TestCase):
    def test_daily_limit(self):
        with Env(FakeApi(reply(GOOD)), daily_limit=2) as e:
            for _ in range(2):
                self.assertEqual(e.request("POST", "/api/generate", INPUTS)[0], 200)
            status, body, _ = e.request("POST", "/api/generate", INPUTS)
            self.assertEqual(status, 429)
            self.assertIn("한도", body)
            self.assertEqual(e.fake.calls, 2)  # 한도 뒤에는 API 를 부르지 않는다

    def test_default_limits_in_config(self):
        c = app.load_config()
        self.assertEqual(c["daily_limit"], 30)
        self.assertEqual(c["max_tokens"], 500)
        self.assertIsNone(c["price_input_per_million"])
        self.assertIsNone(c["price_output_per_million"])

    def test_max_tokens_sent_to_api(self):
        sent = {}

        class Fake:
            def read(self_inner):
                return json.dumps(reply(GOOD)).encode()

            def __enter__(self_inner):
                return self_inner

            def __exit__(self_inner, *a):
                return False

        import urllib.request as ur

        orig = ur.urlopen

        def fake_urlopen(req, timeout=None):
            sent["body"] = json.loads(req.data.decode())
            return Fake()

        ur.urlopen = fake_urlopen
        try:
            app.make_claude_caller(FAKE_KEY, cfg())("sys", "user")
        finally:
            ur.urlopen = orig
        self.assertEqual(sent["body"]["max_tokens"], 500)
        self.assertEqual(sent["body"]["thinking"], {"type": "disabled"})
        self.assertEqual(sent["body"]["output_config"], {"effort": "low"})
        self.assertEqual(sent["body"]["model"], "claude-haiku-5-5")

    def test_tokens_shown_and_cost_unset(self):
        with Env(FakeApi(reply(GOOD, 120, 80))) as e:
            _, body, _ = e.request("POST", "/api/generate", INPUTS)
            data = json.loads(body)
            self.assertEqual(data["tokens"], {"input": 120, "output": 80, "total": 200})
            self.assertEqual(data["today"]["requests"], 1)
            self.assertEqual(data["today"]["total_tokens"], 200)
            self.assertIsNone(data["cost"])  # 단가를 추측하지 않는다

    def test_cost_when_prices_configured(self):
        with Env(FakeApi(reply(GOOD, 1_000_000, 1_000_000)), price_input_per_million=1, price_output_per_million=2) as e:
            data = json.loads(e.request("POST", "/api/generate", INPUTS)[1])
            self.assertAlmostEqual(data["cost"], 3.0)

    def test_input_limits(self):
        with Env(FakeApi(reply(GOOD))) as e:
            bad = dict(INPUTS, name="가" * 101)
            self.assertEqual(e.request("POST", "/api/generate", bad)[0], 400)
            self.assertEqual(e.request("POST", "/api/generate", dict(INPUTS, features=""))[0], 400)
            self.assertEqual(e.fake.calls, 0)


class KeyNeverLeaks(unittest.TestCase):
    def assertClean(self, text, where):
        self.assertNotIn(FAKE_KEY, text, f"{where}에 키가 있어요")
        self.assertIsNone(re.search(r"sk-ant-[A-Za-z0-9_\-]{8,}", text), f"{where}에 키 모양이 있어요")

    def test_files_in_project_have_no_key(self):
        # .env 는 열지 않고, 나머지 모든 파일에 키 모양 문자열이 없는지 본다
        for p in BASE.rglob("*"):
            if p.is_dir() or ".git" in p.parts or p.name == ".env" or p.suffix == ".pyc":
                continue
            if p.name == "test_app.py":  # 이 파일은 가짜 키를 일부러 갖고 있다
                continue
            self.assertClean(p.read_text(encoding="utf-8", errors="ignore"), p.name)

    def test_served_pages_have_no_key(self):
        with Env(FakeApi(reply(GOOD))) as e:
            for path in ("/", "/index.html", "/api/status"):
                status, body, headers = e.request("GET", path)
                self.assertClean(body, path)
                self.assertClean(json.dumps(headers), path + " 헤더")

    def test_unknown_paths_do_not_serve_files(self):
        with Env(FakeApi(reply(GOOD))) as e:
            for path in ("/.env", "/app.py", "/../.env", "/usage.json", "/config.json"):
                status, body, _ = e.request("GET", path)
                self.assertEqual(status, 404, path)

    def test_success_response_has_no_key(self):
        with Env(FakeApi(reply(GOOD))) as e:
            _, body, headers = e.request("POST", "/api/generate", INPUTS)
            self.assertClean(body, "성공 응답")
            self.assertClean(json.dumps(headers), "성공 헤더")
            self.assertClean(e.log.getvalue(), "로그")

    def test_error_messages_have_no_key(self):
        leaky = [
            app.AppError(f"실패 {FAKE_KEY}"),  # 실수로 키가 섞인 안내 메시지
            RuntimeError(f"upstream said bad key {FAKE_KEY}"),  # 예상 못한 예외
        ]
        for exc in leaky:
            with Env(FakeApi(exc)) as e:
                status, body, _ = e.request("POST", "/api/generate", INPUTS)
                self.assertGreaterEqual(status, 400)
                self.assertClean(body, "오류 응답")
                self.assertClean(e.log.getvalue(), "오류 로그")

    def test_ai_text_echoing_key_is_scrubbed(self):
        evil = [(f"제목 {FAKE_KEY}", "설명")] * 5
        with Env(FakeApi(reply(evil))) as e:
            _, body, _ = e.request("POST", "/api/generate", INPUTS)
            self.assertClean(body, "AI 에코 응답")

    def test_upstream_http_error_body_not_shown(self):
        import urllib.error
        import urllib.request as ur

        orig = ur.urlopen

        def boom(req, timeout=None):
            raise urllib.error.HTTPError(req.full_url, 401, f"bad {FAKE_KEY}", {}, io.BytesIO(FAKE_KEY.encode()))

        ur.urlopen = boom
        try:
            caller = app.make_claude_caller(FAKE_KEY, cfg())
            with Env(caller) as e:
                status, body, _ = e.request("POST", "/api/generate", INPUTS)
                self.assertEqual(status, 502)
                self.assertClean(body, "업스트림 오류 응답")
                self.assertClean(e.log.getvalue(), "업스트림 오류 로그")
        finally:
            ur.urlopen = orig

class LocalOnlySafety(unittest.TestCase):
    def test_foreign_host_and_origin_rejected(self):
        with Env(FakeApi(reply(GOOD))) as e:
            self.assertEqual(e.request("GET", "/", headers={"Host": "evil.example"})[0], 403)
            self.assertEqual(e.request("POST", "/api/generate", INPUTS, headers={"Origin": "http://evil.example"})[0], 403)
            self.assertEqual(e.fake.calls, 0)

    def test_binds_to_loopback_only(self):
        with Env(FakeApi(reply(GOOD))) as e:
            self.assertEqual(e.server.server_address[0], "127.0.0.1")


class FrameProtection(unittest.TestCase):
    """다른 사이트가 이 화면을 몰래 겹쳐 띄우지 못하게 하는 헤더 (모든 응답)."""

    def assertNoFraming(self, headers, where):
        h = {k.lower(): v for k, v in headers.items()}
        self.assertEqual(h.get("x-frame-options"), "DENY", f"{where}: X-Frame-Options")
        self.assertIn("frame-ancestors 'none'", h.get("content-security-policy", ""), f"{where}: CSP frame-ancestors")

    def test_all_kinds_of_responses_have_headers(self):
        with Env(FakeApi(reply(GOOD))) as e:
            self.assertNoFraming(e.request("GET", "/")[2], "화면")
            self.assertNoFraming(e.request("GET", "/api/status")[2], "상태")
            self.assertNoFraming(e.request("GET", "/nothing")[2], "404")
            self.assertNoFraming(e.request("GET", "/", headers={"Host": "evil.example"})[2], "403")
            self.assertNoFraming(e.request("POST", "/api/generate", INPUTS)[2], "생성 성공")
            self.assertNoFraming(e.request("POST", "/api/generate", dict(INPUTS, name=""))[2], "생성 오류")

    def test_page_still_works_with_csp(self):
        # CSP 가 화면 자체의 인라인 스타일·스크립트를 막지 않아야 한다
        with Env(FakeApi(reply(GOOD))) as e:
            csp = {k.lower(): v for k, v in e.request("GET", "/")[2].items()}["content-security-policy"]
            self.assertNotIn("default-src 'none'", csp)
            self.assertNotIn("script-src 'none'", csp)


class SharingFiles(unittest.TestCase):
    """폴더를 나눠 줄 때를 위한 파일들."""

    def test_env_example_exists_with_empty_key(self):
        text = (BASE / ".env.example").read_text(encoding="utf-8")
        lines = [l.strip() for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
        self.assertEqual(lines, ["ANTHROPIC_API_KEY="])

    def test_readme_warns_first(self):
        text = (BASE / "README.md").read_text(encoding="utf-8")
        top = text[:600]
        self.assertIn(".env", top)
        self.assertIn("지", top)
        self.assertIn(".env.example", top)


class KeyLoading(unittest.TestCase):
    def test_reads_env_file_value_without_printing(self):
        import os

        saved = os.environ.pop("ANTHROPIC_API_KEY", None)
        try:
            with tempfile.TemporaryDirectory() as d:
                p = Path(d) / ".env"
                p.write_text(f"ANTHROPIC_API_KEY={FAKE_KEY}\n", encoding="utf-8")
                self.assertEqual(app.load_api_key(p), FAKE_KEY)
                self.assertIsNone(app.load_api_key(Path(d) / "nothing.env"))
        finally:
            if saved is not None:
                os.environ["ANTHROPIC_API_KEY"] = saved


if __name__ == "__main__":
    unittest.main()
