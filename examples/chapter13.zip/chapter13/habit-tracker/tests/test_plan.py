# -*- coding: utf-8 -*-
"""
plan.md '7. 완성의 기준'을 자동으로 확인하는 테스트.

실행 (프로젝트 폴더에서):
    python tests\\test_plan.py            # 전체
    python tests\\test_plan.py --headed   # 브라우저 창을 띄워서 보면서
    python tests\\test_plan.py -k 히트맵   # 문장에 '히트맵'이 들어간 항목만

필요한 것: Python + Playwright(파이썬용) + Chromium (이 컴퓨터에 이미 설치됨).
index.html은 고치지 않고, 브라우저에서 그대로 열어 눌러 본다.
날짜·시각은 브라우저 안의 시계를 가짜로 바꿔서 2026-11-11(한국 시간) 기준으로 맞춘다.
"""
import argparse
import json
import os
import re
import sys
import tempfile
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
# HABIT_INDEX 환경변수로 다른 파일을 시험할 수 있다 (테스트가 버그를 잡는지 볼 때)
INDEX_URL = Path(os.environ.get('HABIT_INDEX', ROOT / 'index.html')).resolve().as_uri()
SAMPLE = ROOT / 'sample-backup.json'
KEY = 'habit-tracker-v1'
EXPORT_KEY = 'habit-tracker-last-export'
CELEBRATE_KEY = 'habit-tracker-last-celebrate'
KST = timezone(timedelta(hours=9))
TMP = Path(tempfile.mkdtemp(prefix='habit-test-'))


def kst(y, m, d, h=12, mi=0, s=0):
    return datetime(y, m, d, h, mi, s, tzinfo=KST)


NOON = kst(2026, 11, 11, 12)  # 기준: 2026년 11월 11일 수요일 낮 12시
DAYS = ['월', '화', '수', '목', '금', '토', '일']


def label(ymd):
    d = datetime.strptime(ymd, '%Y-%m-%d')
    return f'{d.month}월 {d.day}일 {DAYS[d.weekday()]}요일'


def sample():
    return json.loads(SAMPLE.read_text(encoding='utf-8'))


# 진동 호출과 색종이 조각 생성을 몰래 세어 두는 스크립트 (페이지보다 먼저 실행)
INIT_JS = r"""
window.__vibrate = [];
try {
  Object.defineProperty(Navigator.prototype, 'vibrate', {
    configurable: true,
    value: function (p) { window.__vibrate.push(p); return true; }
  });
} catch (e) {}
window.__confetti = 0;
new MutationObserver(function (ms) {
  ms.forEach(function (m) {
    m.addedNodes.forEach(function (n) {
      if (n.classList && n.classList.contains('confetti')) window.__confetti++;
    });
  });
}).observe(document, { childList: true, subtree: true });
"""


class Fail(AssertionError):
    pass


def eq(actual, expected, what):
    if actual != expected:
        raise Fail(f'{what}: 기대 {expected!r}, 실제 {actual!r}')


def ok(cond, what):
    if not cond:
        raise Fail(what)


def exact(text):
    return re.compile('^' + re.escape(text) + '$')


class App:
    """브라우저 창 하나(새 프로필)에서 index.html을 연 상태."""

    browser = None
    headed_slow = 0

    def __init__(self, now=NOON, width=420, data=None, extra_storage=None):
        self.ctx = App.browser.new_context(
            viewport={'width': width, 'height': 800},
            timezone_id='Asia/Seoul', locale='ko-KR', accept_downloads=True)
        self.ctx.set_default_timeout(4000)
        self.ctx.add_init_script(INIT_JS)
        self.ctx.clock.install(time=now)
        self.dialogs = []          # (종류, 문구)
        self.confirm_answer = True  # confirm 창에서 확인(True) / 취소(False)
        self.page = None
        self.open_page()
        if data is not None or extra_storage:
            items = {}
            if data is not None:
                items[KEY] = json.dumps(data, ensure_ascii=False)
            items.update(extra_storage or {})
            self.page.evaluate('(o) => { for (const k in o) localStorage.setItem(k, o[k]); }', items)
            self.reload()

    def open_page(self):
        self.page = self.ctx.new_page()
        self.page.on('dialog', self._on_dialog)
        self.page.goto(INDEX_URL)

    def _on_dialog(self, d):
        self.dialogs.append((d.type, d.message))
        if d.type == 'confirm' and not self.confirm_answer:
            d.dismiss()
        else:
            d.accept()

    def close(self):
        try:
            self.ctx.close()
        except Exception:
            pass

    def reload(self):
        self.page.reload()

    # --- 읽기 ---
    def date(self):
        return self.page.locator('#dateLabel').text_content()

    def names(self):
        return self.page.locator('#checkList .name').all_text_contents()

    def mnames(self):
        return self.page.locator('#manageList .mrow > span').all_text_contents()

    def row(self, name):
        return self.page.locator('#checkList .row').filter(
            has=self.page.locator('.name', has_text=exact(name)))

    def meta(self, name):
        return self.row(name).locator('.meta').text_content()

    def done(self, name):
        return self.row(name).get_attribute('aria-pressed') == 'true'

    def visible(self, sel):
        return self.page.locator(sel).is_visible()

    def storage(self, key=KEY):
        raw = self.page.evaluate('(k) => localStorage.getItem(k)', key)
        return json.loads(raw) if (raw and key == KEY) else raw

    def confetti_made(self):
        return self.page.evaluate('window.__confetti')

    def confetti_now(self):
        return self.page.locator('.confetti').count()

    def vibrations(self):
        return self.page.evaluate('window.__vibrate.length')

    def snapshot(self):
        """습관별 (이름, 체크 여부, 숫자 줄)."""
        return [(n, self.done(n), self.meta(n)) for n in self.names()]

    def cell(self, ymd):
        return self.page.locator('#heatGrid .cell[title^="%s · "]' % label(ymd))

    def level(self, ymd):
        cls = self.cell(ymd).get_attribute('class') or ''
        m = re.search(r'\bl(\d)\b', cls)
        return int(m.group(1)) if m else 0

    def hscroll(self):
        return self.page.evaluate(
            'document.documentElement.scrollWidth > document.documentElement.clientWidth')

    # --- 누르기 ---
    def tap(self, name):
        self.row(name).click()

    def first_add(self, name):
        self.page.fill('#firstName', name)
        self.page.locator('#firstForm button[type=submit]').click()

    def open_manage(self):
        self.page.click('#openManage')

    def close_manage(self):
        self.page.click('#closeManage')

    def add(self, name):
        """관리 화면에서 추가."""
        self.page.fill('#addName', name)
        self.page.click('#addBtn')

    def mrow(self, name):
        return self.page.locator('#manageList .mrow').filter(
            has=self.page.locator('span', has_text=exact(name)))

    def mbtn(self, name, text):
        return self.mrow(name).locator('button', has_text=exact(text))

    def start_rename(self, name):
        self.mbtn(name, '이름 바꾸기').click()
        return self.page.locator('#manageList form input')

    def yesterday(self):
        self.page.click('#viewYesterday')

    def today(self):
        self.page.click('#viewToday')

    def wait_dialogs(self, n, timeout=3.0):
        end = time.time() + timeout
        while len(self.dialogs) < n and time.time() < end:
            self.page.wait_for_timeout(50)

    def import_file(self, path):
        before = len(self.dialogs)
        self.page.set_input_files('#importFile', str(path))
        self.wait_dialogs(before + 1)
        self.page.wait_for_timeout(100)

    def export(self):
        with self.page.expect_download() as info:
            self.page.click('#exportBtn')
        dl = info.value
        dest = TMP / f'{time.time_ns()}-{dl.suggested_filename}'
        dl.save_as(dest)
        return dl.suggested_filename, dest


def write_tmp(name, text):
    p = TMP / name
    p.write_text(text, encoding='utf-8')
    return p


def luminance(rgb):
    nums = [int(x) for x in re.findall(r'\d+', rgb)[:3]]
    return 0.2126 * nums[0] + 0.7152 * nums[1] + 0.0722 * nums[2]


# ======================================================================
TESTS = []


def item(section, text):
    def deco(fn):
        TESTS.append((section, text, fn))
        return fn
    return deco


S1 = '처음 열기와 습관 관리'
S2 = '체크'
S3 = '숫자'
S4 = '잔디 히트맵'
S5 = '백업'
S6 = '쓰기 편함'


@item(S1, '파일을 처음 열면 오늘 날짜와 "첫 습관을 추가하세요", 이름 입력창이 보인다.')
def t_first_open(a):
    eq(a.date(), '11월 11일 수요일', '날짜')
    ok(a.visible('#emptyBox'), '"첫 습관을 추가하세요" 상자가 안 보임')
    eq(a.page.locator('#emptyBox p').text_content(), '첫 습관을 추가하세요', '안내 문구')
    ok(a.visible('#firstName'), '이름 입력창이 안 보임')


@item(S1, '이름을 적고 추가를 누르면 목록에 바로 나타난다.')
def t_add(a):
    a.first_add('물 2L 마시기')
    eq(a.names(), ['물 2L 마시기'], '첫 화면에서 추가 후 목록')
    ok(not a.visible('#emptyBox'), '추가 후에도 "첫 습관을 추가하세요"가 보임')
    a.open_manage()
    a.add('스트레칭')
    eq(a.mnames(), ['물 2L 마시기', '스트레칭'], '관리 화면 목록')
    a.close_manage()
    eq(a.names(), ['물 2L 마시기', '스트레칭'], '오늘 체크 화면 목록')


@item(S1, '빈 이름이나 이미 있는 이름은 추가되지 않는다.')
def t_add_invalid(a):
    a.first_add('')
    a.first_add('    ')
    eq(a.names(), [], '빈 이름 추가 후 목록')
    ok(a.visible('#emptyBox'), '빈 이름인데 첫 화면이 사라짐')
    a.first_add('독서')
    a.open_manage()
    a.add('독서')
    a.add('  독서  ')
    a.add('')
    eq(a.mnames(), ['독서'], '같은 이름·빈 이름 추가 후 목록')
    eq(len(a.storage()['habits']), 1, '저장된 습관 수')


@item(S1, '5개를 추가하면 추가 버튼이 눌리지 않고 "최대 5개" 안내가 보인다.')
def t_max5(a):
    a.open_manage()
    for i, n in enumerate(['하나', '둘', '셋', '넷', '다섯']):
        ok(not a.visible('#maxHint'), f'{i}개일 때 "최대 5개"가 미리 보임')
        a.add(n)
    eq(len(a.mnames()), 5, '습관 수')
    ok(a.page.locator('#addBtn').is_disabled(), '5개인데 추가 버튼이 눌림')
    ok(a.visible('#maxHint'), '"최대 5개" 안내가 안 보임')
    eq(a.page.locator('#maxHint').text_content(), '최대 5개', '안내 문구')
    a.page.locator('#addBtn').click(force=True)
    a.page.locator('#addForm').evaluate('f => f.requestSubmit()')
    eq(len(a.storage()['habits']), 5, '억지로 눌러 본 뒤 습관 수')


@item(S1, '삭제를 누르면 확인 창이 뜨고, 취소하면 그대로, 확인하면 그 습관이 사라진다.')
def t_delete(a):
    a.close()
    a = App(data=sample())
    try:
        a.open_manage()
        a.confirm_answer = False
        a.mbtn('물 2L 마시기', '삭제').click()
        eq(a.dialogs, [('confirm', '‘물 2L 마시기’와 기록을 지울까요?')], '확인 창')
        eq(a.mnames(), ['물 2L 마시기', '스트레칭', '영어 단어', '일기 쓰기'], '취소 후 목록')
        eq(a.storage(), sample(), '취소 후 저장된 기록')
        a.confirm_answer = True
        a.mbtn('물 2L 마시기', '삭제').click()
        eq(len(a.dialogs), 2, '두 번째 확인 창')
        eq(a.mnames(), ['스트레칭', '영어 단어', '일기 쓰기'], '확인 후 목록')
        a.close_manage()
        eq(a.names(), ['스트레칭', '영어 단어', '일기 쓰기'], '확인 후 오늘 체크 화면')
        st = a.storage()
        ok(all('h_a' not in v for v in st['checks'].values()), '지운 습관의 체크 기록이 남아 있음')
    finally:
        a.close()


@item(S1, '‘이름 바꾸기’를 누르고 새 이름을 적어 저장하면 관리 화면과 오늘 체크 화면 모두 새 이름으로 보이고, 연속 달성일·달성률 숫자는 바뀌지 않는다.')
def t_rename(a):
    a.close()
    a = App(data=sample())
    try:
        before = a.meta('스트레칭')
        a.open_manage()
        inp = a.start_rename('스트레칭')
        inp.fill('아침 스트레칭')
        a.page.locator('#manageList form button', has_text='저장').click()
        eq(a.mnames(), ['물 2L 마시기', '아침 스트레칭', '영어 단어', '일기 쓰기'], '관리 화면')
        a.close_manage()
        eq(a.names(), ['물 2L 마시기', '아침 스트레칭', '영어 단어', '일기 쓰기'], '오늘 체크 화면')
        eq(a.meta('아침 스트레칭'), before, '숫자 줄')
        # Enter로도 저장된다
        a.open_manage()
        inp = a.start_rename('영어 단어')
        inp.fill('단어 20개')
        inp.press('Enter')
        ok('단어 20개' in a.mnames(), 'Enter로 저장되지 않음')
    finally:
        a.close()


@item(S1, '이름을 비우거나 다른 습관과 같은 이름으로 저장하면 저장되지 않고, ‘취소’를 누르면 원래 이름 그대로다.')
def t_rename_invalid(a):
    a.close()
    a = App(data=sample())
    try:
        a.open_manage()
        save = a.page.locator('#manageList form button', has_text='저장')
        inp = a.start_rename('스트레칭')
        for bad in ['', '   ', '물 2L 마시기', ' 일기 쓰기 ']:
            inp.fill(bad)
            save.click()
            eq([h['name'] for h in a.storage()['habits']],
               ['물 2L 마시기', '스트레칭', '영어 단어', '일기 쓰기'], f'{bad!r}로 저장한 뒤 기록')
        inp.fill('바뀐 이름')
        a.page.locator('#manageList form button', has_text='취소').click()
        eq(a.mnames(), ['물 2L 마시기', '스트레칭', '영어 단어', '일기 쓰기'], '취소 후 관리 화면')
        inp = a.start_rename('스트레칭')
        inp.fill('또 바뀐 이름')
        inp.press('Escape')
        eq(a.mnames(), ['물 2L 마시기', '스트레칭', '영어 단어', '일기 쓰기'], 'Esc 후 관리 화면')
        a.close_manage()
        eq(a.names(), ['물 2L 마시기', '스트레칭', '영어 단어', '일기 쓰기'], '오늘 체크 화면')
    finally:
        a.close()


@item(S1, '이름을 바꾼 뒤 새로고침해도 새 이름이 남아 있고, 내보낸 파일을 불러와도 새 이름과 기록이 그대로 보인다.')
def t_rename_persist(a):
    a.close()
    a = App(data=sample())
    b = None
    try:
        a.tap('스트레칭')
        a.open_manage()
        inp = a.start_rename('스트레칭')
        inp.fill('아침 스트레칭')
        inp.press('Enter')
        a.reload()
        eq(a.names(), ['물 2L 마시기', '아침 스트레칭', '영어 단어', '일기 쓰기'], '새로고침 후')
        snap = a.snapshot()
        a.open_manage()
        _, path = a.export()
        b = App()
        b.open_manage()
        b.import_file(path)
        b.close_manage()
        eq(b.snapshot(), snap, '불러온 뒤 (이름, 체크, 숫자)')
    finally:
        a.close()
        if b:
            b.close()


@item(S1, '관리 화면에서 ‘↓’를 누르면 그 습관이 한 칸 아래로, ‘↑’를 누르면 한 칸 위로 가고, 닫으면 오늘 체크 화면도 같은 순서로 보인다.')
def t_order(a):
    a.close()
    a = App(data=sample())
    try:
        a.open_manage()
        a.mbtn('물 2L 마시기', '↓').click()
        eq(a.mnames(), ['스트레칭', '물 2L 마시기', '영어 단어', '일기 쓰기'], '↓ 후')
        a.mbtn('영어 단어', '↑').click()
        eq(a.mnames(), ['스트레칭', '영어 단어', '물 2L 마시기', '일기 쓰기'], '↑ 후')
        a.close_manage()
        eq(a.names(), ['스트레칭', '영어 단어', '물 2L 마시기', '일기 쓰기'], '오늘 체크 화면')
    finally:
        a.close()


@item(S1, '맨 위 습관의 ‘↑’와 맨 아래 습관의 ‘↓’는 눌리지 않는다.')
def t_order_edges(a):
    a.close()
    a = App(data=sample())
    try:
        a.open_manage()
        top_up = a.mbtn('물 2L 마시기', '↑')
        bottom_down = a.mbtn('일기 쓰기', '↓')
        ok(top_up.is_disabled(), '맨 위 ↑가 눌림')
        ok(bottom_down.is_disabled(), '맨 아래 ↓가 눌림')
        ok(a.mbtn('물 2L 마시기', '↓').is_enabled(), '맨 위 ↓가 잠김')
        ok(a.mbtn('일기 쓰기', '↑').is_enabled(), '맨 아래 ↑가 잠김')
        ok(a.mbtn('스트레칭', '↑').is_enabled() and a.mbtn('스트레칭', '↓').is_enabled(), '가운데 버튼이 잠김')
        top_up.click(force=True)
        bottom_down.click(force=True)
        eq(a.mnames(), ['물 2L 마시기', '스트레칭', '영어 단어', '일기 쓰기'], '억지로 누른 뒤')
        # 순서를 바꾸면 잠기는 버튼도 따라 바뀐다
        a.mbtn('물 2L 마시기', '↓').click()
        ok(a.mbtn('스트레칭', '↑').is_disabled(), '새 맨 위 ↑가 잠기지 않음')
        ok(a.mbtn('물 2L 마시기', '↑').is_enabled(), '내려간 습관의 ↑가 잠김')
    finally:
        a.close()


@item(S1, '순서를 바꿔도 체크 표시, 연속 달성일, 달성률은 바뀌지 않고, 새로고침하거나 내보낸 파일을 불러와도 바뀐 순서가 남아 있다.')
def t_order_persist(a):
    a.close()
    a = App(data=sample())
    b = None
    try:
        a.tap('물 2L 마시기')
        a.tap('영어 단어')
        before = {n: (d, m) for n, d, m in a.snapshot()}
        a.open_manage()
        a.mbtn('일기 쓰기', '↑').click()
        a.mbtn('물 2L 마시기', '↓').click()
        want = ['스트레칭', '물 2L 마시기', '일기 쓰기', '영어 단어']
        a.close_manage()
        eq(a.names(), want, '바꾼 순서')
        eq({n: (d, m) for n, d, m in a.snapshot()}, before, '체크·숫자')
        a.reload()
        eq(a.names(), want, '새로고침 후 순서')
        a.open_manage()
        _, path = a.export()
        b = App()
        b.open_manage()
        b.import_file(path)
        b.close_manage()
        eq(b.names(), want, '불러온 뒤 순서')
        eq({n: (d, m) for n, d, m in b.snapshot()}, before, '불러온 뒤 체크·숫자')
    finally:
        a.close()
        if b:
            b.close()


# ---------------------------------------------------------------- 체크
@item(S2, '습관 행을 한 번 누르면 체크되고, 다시 누르면 해제된다.')
def t_toggle(a):
    a.first_add('물 2L 마시기')
    ok(not a.done('물 2L 마시기'), '처음부터 체크되어 있음')
    a.tap('물 2L 마시기')
    ok(a.done('물 2L 마시기'), '한 번 눌렀는데 체크 안 됨')
    ok('done' in a.row('물 2L 마시기').get_attribute('class'), '체크 모양이 안 바뀜')
    eq(a.storage()['checks'].get('2026-11-11'), [a.storage()['habits'][0]['id']], '저장된 오늘 체크')
    a.tap('물 2L 마시기')
    ok(not a.done('물 2L 마시기'), '다시 눌렀는데 해제 안 됨')
    ok('2026-11-11' not in a.storage()['checks'], '해제했는데 기록이 남음')


@item(S2, '체크하자마자 그 습관의 연속 달성일과 이번 달 달성률 숫자가 바뀐다.')
def t_toggle_numbers(a):
    a.close()
    a = App(data=sample())
    try:
        eq(a.meta('스트레칭'), '연속 3일 · 최고 3일 · 이번 달 30%', '체크 전')
        a.tap('스트레칭')
        eq(a.meta('스트레칭'), '연속 4일 · 최고 4일 · 이번 달 36%', '체크 직후')
        a.tap('스트레칭')
        eq(a.meta('스트레칭'), '연속 3일 · 최고 3일 · 이번 달 30%', '해제 직후')
    finally:
        a.close()


@item(S2, '체크한 뒤 새로고침하거나 브라우저를 닫았다 열어도 체크가 남아 있다.')
def t_toggle_persist(a):
    a.first_add('물 2L 마시기')
    a.tap('물 2L 마시기')
    a.reload()
    ok(a.done('물 2L 마시기'), '새로고침 후 체크가 사라짐')
    a.page.close()
    a.open_page()
    ok(a.done('물 2L 마시기'), '창을 닫고 다시 연 뒤 체크가 사라짐')


@item(S2, '모든 습관을 체크하면 "오늘 완료"가 보인다.')
def t_complete(a):
    a.close()
    a = App(data=sample())
    try:
        names = a.names()
        for n in names[:-1]:
            a.tap(n)
            ok(not a.visible('#completeMsg'), '다 체크하기 전에 "오늘 완료"가 보임')
        a.tap(names[-1])
        ok(a.visible('#completeMsg'), '"오늘 완료"가 안 보임')
        eq(a.page.locator('#completeMsg').text_content(), '오늘 완료', '문구')
        a.tap(names[0])
        ok(not a.visible('#completeMsg'), '하나 해제했는데 "오늘 완료"가 남음')
    finally:
        a.close()


@item(S2, '마지막 습관을 체크해 모두 완료가 되면 "오늘 완료" 주변에 작은 색종이가 잠깐 튀었다 사라지고, 안드로이드 휴대폰에서는 짧게 진동한다.')
def t_celebrate(a):
    a.close()
    a = App(data=sample())
    try:
        names = a.names()
        for n in names[:-1]:
            a.tap(n)
        eq(a.confetti_made(), 0, '다 체크하기 전 색종이 수')
        a.tap(names[-1])
        ok(a.confetti_made() > 0, '색종이가 나오지 않음')
        eq(a.page.locator('#completeMsg .confetti').count(), a.confetti_now(), '색종이가 "오늘 완료" 밖에 생김')
        eq(a.vibrations(), 1, '진동 요청 횟수')
        a.ctx.clock.run_for(1500)
        eq(a.confetti_now(), 0, '1.5초 뒤 남은 색종이 수')
        eq(a.storage(CELEBRATE_KEY), '2026-11-11', '축하한 날 저장')
    finally:
        a.close()


@item(S2, '이미 모두 완료된 상태로 새로고침하거나, 체크를 해제하거나, ‘어제’ 보기에서 어제를 모두 체크할 때는 효과가 나오지 않는다.')
def t_celebrate_not(a):
    a.close()
    # (1) 이미 다 된 상태로 열기 (축하한 날 기록 없이)
    d = sample()
    d['checks']['2026-11-11'] = ['h_a', 'h_b', 'h_c', 'h_d']
    a = App(data=d)
    try:
        ok(a.visible('#completeMsg'), '"오늘 완료"가 안 보임')
        a.reload()
        eq((a.confetti_made(), a.vibrations()), (0, 0), '새로고침 시 (색종이, 진동)')
        # (2) 해제
        a.tap('물 2L 마시기')
        eq((a.confetti_made(), a.vibrations()), (0, 0), '해제 시 (색종이, 진동)')
    finally:
        a.close()
    # (3) 어제 보기에서 어제를 모두 체크
    a = App(data=sample())
    try:
        a.yesterday()
        a.tap('영어 단어')
        a.tap('일기 쓰기')
        ok(all(a.done(n) for n in a.names()), '어제가 모두 체크되지 않음')
        eq((a.confetti_made(), a.vibrations()), (0, 0), '어제 모두 체크 시 (색종이, 진동)')
        ok(not a.visible('#completeMsg'), '어제 보기에서 "오늘 완료"가 보임')
    finally:
        a.close()


@item(S2, '그날 한 번 효과가 나온 뒤에는 마지막 습관을 해제했다 다시 체크해도, 새로고침 후 다시 해도 효과와 진동이 나오지 않는다. 다음 날 모두 체크하면 다시 한 번 나온다.')
def t_celebrate_once(a):
    a.close()
    a = App(data=sample())
    try:
        for n in a.names():
            a.tap(n)
        first = a.confetti_made()
        ok(first > 0, '처음에 효과가 나오지 않음')
        a.tap('일기 쓰기')
        a.tap('일기 쓰기')
        eq((a.confetti_made(), a.vibrations()), (first, 1), '해제→다시 체크 후 (색종이 누적, 진동 누적)')
        a.reload()
        a.tap('일기 쓰기')
        a.tap('일기 쓰기')
        eq((a.confetti_made(), a.vibrations()), (0, 0), '새로고침 후 다시 했을 때 (색종이, 진동)')
        # 다음 날 (11월 12일 새벽 4시 1분)
        a.ctx.clock.set_system_time(kst(2026, 11, 12, 4, 1))
        a.reload()
        eq(a.date(), '11월 12일 목요일', '다음 날 날짜')
        for n in a.names():
            a.tap(n)
        ok(a.confetti_made() > 0, '다음 날 효과가 나오지 않음')
        eq(a.vibrations(), 1, '다음 날 진동 요청 횟수')
    finally:
        a.close()


@item(S2, '내보낸 백업 파일에는 축하한 날이 들어가지 않는다.')
def t_celebrate_not_in_backup(a):
    a.close()
    a = App(data=sample())
    try:
        for n in a.names():
            a.tap(n)
        eq(a.storage(CELEBRATE_KEY), '2026-11-11', '축하한 날 저장')
        a.open_manage()
        _, path = a.export()
        data = json.loads(path.read_text(encoding='utf-8'))
        eq(sorted(data.keys()), ['checks', 'habits', 'version'], '백업 파일의 항목')
        ok('celebrate' not in path.read_text(encoding='utf-8'), '백업 파일에 축하 기록이 들어 있음')
        eq(data, a.storage(), '백업 파일 = 저장된 기록')
    finally:
        a.close()


@item(S2, '효과가 나오는 동안에도 375px 폭에서 가로 스크롤이 생기지 않고, 습관 행을 바로 누를 수 있다.')
def t_celebrate_layout(a):
    a.close()
    a = App(width=375, data=sample())
    try:
        names = a.names()
        for n in names[:-1]:
            a.tap(n)
        a.tap(names[-1])
        ok(a.confetti_now() > 0, '색종이가 없음')
        for ms in (0, 150, 300, 450, 600):
            if ms:
                a.page.wait_for_timeout(150)
            ok(not a.hscroll(), f'효과 {ms}ms 무렵 가로 스크롤이 생김')
        ok(a.confetti_now() > 0, '확인하는 동안 색종이가 이미 사라짐 (확인 불충분)')
        # 효과가 남아 있는 동안 행을 눌러 본다
        target = names[0]
        box = a.row(target).bounding_box()
        hit = a.page.evaluate(
            '([x, y]) => !!document.elementFromPoint(x, y).closest(".row")',
            [box['x'] + box['width'] / 2, box['y'] + box['height'] / 2])
        ok(hit, '행 가운데를 다른 것이 가림')
        a.tap(target)
        ok(not a.done(target), '효과 중 행을 눌렀는데 해제되지 않음')
    finally:
        a.close()


@item(S2, '‘어제’를 누르면 날짜가 어제로 바뀌고, 어제 체크를 넣고 뺄 수 있다.')
def t_yesterday(a):
    a.close()
    a = App(data=sample())
    try:
        a.yesterday()
        eq(a.date(), '11월 10일 화요일', '어제 날짜')
        ok(a.done('물 2L 마시기') and not a.done('영어 단어'), '어제 체크 표시가 기록과 다름')
        a.tap('영어 단어')
        ok(a.done('영어 단어'), '어제 체크가 안 들어감')
        eq(sorted(a.storage()['checks']['2026-11-10']), ['h_a', 'h_b', 'h_c'], '저장된 어제 체크')
        a.tap('물 2L 마시기')
        ok(not a.done('물 2L 마시기'), '어제 체크가 안 빠짐')
        eq(sorted(a.storage()['checks']['2026-11-10']), ['h_b', 'h_c'], '저장된 어제 체크')
        ok('2026-11-11' not in a.storage()['checks'], '오늘 기록이 잘못 생김')
        a.today()
        eq(a.date(), '11월 11일 수요일', '다시 오늘')
    finally:
        a.close()


@item(S2, '새로고침하면 다시 ‘오늘’ 화면으로 열린다.')
def t_reload_today(a):
    a.close()
    a = App(data=sample())
    try:
        a.yesterday()
        a.reload()
        eq(a.date(), '11월 11일 수요일', '새로고침 후 날짜')
        ok('on' in a.page.locator('#viewToday').get_attribute('class'), '‘오늘’ 버튼이 선택되어 있지 않음')
    finally:
        a.close()


@item(S2, '그저께 이전 날짜로 가거나 그날 체크를 고치는 방법은 화면 어디에도 없다.')
def t_no_older(a):
    a.close()
    a = App(data=sample())
    try:
        def controls():
            return a.page.evaluate('''() => [...document.querySelectorAll(
                'button, input, select, textarea, a[href], [contenteditable], [tabindex]')]
                .filter(e => e.offsetParent !== null)
                .map(e => (e.tagName + ':' + (e.type || '') + ':' + (e.closest('#checkList') ? 'ROW' : e.textContent.trim())))''')
        main = controls()
        eq(sorted(set(main)), sorted({'BUTTON:button:관리', 'BUTTON:button:오늘', 'BUTTON:button:어제', 'BUTTON:button:ROW'}),
           '오늘 체크 화면의 누를 수 있는 것')
        a.yesterday()
        a.yesterday()
        eq(a.date(), '11월 10일 화요일', '‘어제’를 두 번 눌렀을 때 날짜')
        a.open_manage()
        known = ('↑', '↓', '이름 바꾸기', '삭제', '기록 내보내기', '기록 불러오기', '닫기', '추가')
        odd = [c for c in controls()
               if not (c.startswith('INPUT:text:') or (c.startswith('BUTTON:') and c.split(':', 2)[2] in known))]
        eq(odd, [], '관리 화면에 있는 그 밖의 입력·버튼')
        # 오래된 날의 기록은 그대로
        eq({k: v for k, v in a.storage()['checks'].items() if k < '2026-11-10'},
           {k: v for k, v in sample()['checks'].items() if k < '2026-11-10'}, '그저께 이전 기록')
    finally:
        a.close()


@item(S2, '오늘 추가한 습관은 ‘어제’ 화면에서 흐리게 보이고 눌리지 않는다.')
def t_new_habit_yesterday(a):
    a.close()
    a = App(data=sample())
    try:
        a.open_manage()
        a.add('독서')
        a.close_manage()
        a.yesterday()
        r = a.row('독서')
        ok(r.is_disabled(), '‘어제’에서 오늘 추가한 습관이 눌림')
        op = float(r.evaluate('e => getComputedStyle(e).opacity'))
        ok(op < 0.6, f'흐리게 보이지 않음 (불투명도 {op})')
        ok(a.row('물 2L 마시기').is_enabled(), '예전 습관까지 잠김')
        r.click(force=True)
        ok(not a.done('독서'), '억지로 눌렀더니 체크됨')
        st = a.storage()
        new_id = [h['id'] for h in st['habits'] if h['name'] == '독서'][0]
        ok(new_id not in st['checks'].get('2026-11-10', []), '어제 기록에 들어감')
        a.today()
        ok(a.row('독서').is_enabled(), '‘오늘’에서는 눌려야 하는데 잠김')
    finally:
        a.close()


@item(S2, 'PC 시계를 새벽 3시 30분으로 바꾸고 열면 화면 날짜가 전날로 보이고, 4시 1분으로 바꾸면 그날로 보인다.')
def t_4am(a):
    a.close()
    a = App(now=kst(2026, 11, 12, 3, 30))
    try:
        eq(a.date(), '11월 11일 수요일', '11월 12일 3시 30분의 날짜')
        a.first_add('물 2L 마시기')
        a.tap('물 2L 마시기')
        ok('2026-11-11' in a.storage()['checks'], '3시 30분 체크가 전날로 기록되지 않음')
        a.yesterday()
        eq(a.date(), '11월 10일 화요일', '3시 30분의 어제')
    finally:
        a.close()
    a = App(now=kst(2026, 11, 12, 0, 30))
    try:
        eq(a.date(), '11월 11일 수요일', '0시 30분의 날짜')
    finally:
        a.close()
    a = App(now=kst(2026, 11, 12, 4, 1))
    try:
        eq(a.date(), '11월 12일 목요일', '4시 1분의 날짜')
    finally:
        a.close()


@item(S2, '밤 11시 50분에 화면을 열어 두고 새로고침 없이 새벽 4시를 넘기면, 1분 안에 (또는 창을 다시 보는 순간) 화면 날짜가 다음 날(예: 11월 12일 목요일)로 바뀐다.')
def t_cross_4am(a):
    a.close()
    a = App(now=kst(2026, 11, 11, 23, 50), data=sample())
    try:
        eq(a.date(), '11월 11일 수요일', '밤 11시 50분')
        a.ctx.clock.set_system_time(kst(2026, 11, 12, 3, 59, 50))
        a.ctx.clock.run_for(5000)
        eq(a.date(), '11월 11일 수요일', '3시 59분 55초')
        a.ctx.clock.run_for(65000)  # 4시 1분 00초까지
        eq(a.date(), '11월 12일 목요일', '4시를 넘기고 1분 뒤')
    finally:
        a.close()
    # 창을 다시 보는 순간 (타이머가 돌기 전에)
    a = App(now=kst(2026, 11, 11, 23, 50), data=sample())
    try:
        a.ctx.clock.set_system_time(kst(2026, 11, 12, 4, 0, 5))
        eq(a.date(), '11월 11일 수요일', '아직 다시 보지 않았을 때')
        a.page.evaluate('window.dispatchEvent(new Event("focus"))')
        eq(a.date(), '11월 12일 목요일', '창을 다시 본 순간 (focus)')
    finally:
        a.close()
    a = App(now=kst(2026, 11, 11, 23, 50), data=sample())
    try:
        a.ctx.clock.set_system_time(kst(2026, 11, 12, 4, 0, 5))
        a.page.evaluate('document.dispatchEvent(new Event("visibilitychange"))')
        eq(a.date(), '11월 12일 목요일', '탭을 다시 본 순간 (visibilitychange)')
    finally:
        a.close()


@item(S2, '그 상태에서 습관을 체크하면 다음 날(11월 12일)에 기록되고, 전날(11월 11일) 기록은 그대로다. ‘어제’를 누르면 11월 11일이 보인다.')
def t_after_4am_check(a):
    a.close()
    a = App(now=kst(2026, 11, 11, 23, 50), data=sample())
    try:
        a.tap('물 2L 마시기')  # 11월 11일 체크
        a.ctx.clock.set_system_time(kst(2026, 11, 12, 3, 59, 50))
        a.ctx.clock.run_for(70000)
        eq(a.date(), '11월 12일 목요일', '넘긴 뒤 날짜')
        a.tap('스트레칭')
        ch = a.storage()['checks']
        eq(ch.get('2026-11-12'), ['h_b'], '11월 12일 기록')
        eq(ch.get('2026-11-11'), ['h_a'], '11월 11일 기록')
        a.yesterday()
        eq(a.date(), '11월 11일 수요일', '‘어제’ 날짜')
        ok(a.done('물 2L 마시기') and not a.done('스트레칭'), '‘어제’ 화면의 체크 표시')
    finally:
        a.close()
    # 화면이 아직 바뀌기 전(타이머 전)에 눌러도 누른 순간의 날짜로 기록된다
    a = App(now=kst(2026, 11, 11, 23, 50), data=sample())
    try:
        a.ctx.clock.set_system_time(kst(2026, 11, 12, 4, 0, 5))
        a.tap('스트레칭')
        ch = a.storage()['checks']
        eq(ch.get('2026-11-12'), ['h_b'], '화면이 바뀌기 전에 눌렀을 때 11월 12일 기록')
        ok('2026-11-11' not in ch, '화면이 바뀌기 전에 눌렀을 때 11월 11일에 잘못 기록됨')
        eq(a.date(), '11월 12일 목요일', '누른 뒤 날짜')
    finally:
        a.close()


# ---------------------------------------------------------------- 숫자
@item(S3, '11월 1일에 추가하고 1~10일 중 8일 체크한 습관은, 오늘 체크 전 "이번 달 80%", 체크 후 "이번 달 82%"가 보인다.')
def t_rate(a):
    a.close()
    a = App(data=sample())
    try:
        ok(a.meta('물 2L 마시기').endswith('이번 달 80%'), f'체크 전: {a.meta("물 2L 마시기")}')
        a.tap('물 2L 마시기')
        ok(a.meta('물 2L 마시기').endswith('이번 달 82%'), f'체크 후: {a.meta("물 2L 마시기")}')
    finally:
        a.close()


@item(S3, '어제까지 3일 연속 체크한 습관은, 오늘 체크 전 "연속 3일", 체크 후 "연속 4일"이 보인다.')
def t_streak3(a):
    a.close()
    a = App(data=sample())
    try:
        ok(a.meta('스트레칭').startswith('연속 3일 '), f'체크 전: {a.meta("스트레칭")}')
        a.tap('스트레칭')
        ok(a.meta('스트레칭').startswith('연속 4일 '), f'체크 후: {a.meta("스트레칭")}')
    finally:
        a.close()


@item(S3, '어제를 빠뜨린 습관은 "연속 0일", 오늘 체크하면 "연속 1일"이 보인다.')
def t_streak0(a):
    a.close()
    a = App(data=sample())
    try:
        ok(a.meta('영어 단어').startswith('연속 0일 '), f'체크 전: {a.meta("영어 단어")}')
        a.tap('영어 단어')
        ok(a.meta('영어 단어').startswith('연속 1일 '), f'체크 후: {a.meta("영어 단어")}')
    finally:
        a.close()


@item(S3, '그저께까지 3일 연속 체크하고 어제를 빠뜨린 습관은 "연속 0일"이다. ‘어제’에서 체크하면 "연속 4일", 이어서 오늘도 체크하면 "연속 5일"이 된다.')
def t_streak_fill(a):
    a.close()
    a = App(data=sample())
    try:
        ok(a.meta('일기 쓰기').startswith('연속 0일 '), f'처음: {a.meta("일기 쓰기")}')
        a.yesterday()
        a.tap('일기 쓰기')
        ok(a.meta('일기 쓰기').startswith('연속 4일 '), f'어제 체크 후: {a.meta("일기 쓰기")}')
        a.today()
        ok(a.meta('일기 쓰기').startswith('연속 4일 '), f'오늘로 돌아온 뒤: {a.meta("일기 쓰기")}')
        a.tap('일기 쓰기')
        ok(a.meta('일기 쓰기').startswith('연속 5일 '), f'오늘 체크 후: {a.meta("일기 쓰기")}')
    finally:
        a.close()


@item(S3, '오늘 추가한 습관은 체크 전 달성률이 "-", 체크 후 "100%"로 보인다.')
def t_rate_new(a):
    a.close()
    a = App(data=sample())
    try:
        a.open_manage()
        a.add('독서')
        a.close_manage()
        ok(a.meta('독서').endswith('이번 달 -'), f'체크 전: {a.meta("독서")}')
        a.tap('독서')
        ok(a.meta('독서').endswith('이번 달 100%'), f'체크 후: {a.meta("독서")}')
    finally:
        a.close()


def best(a, name):
    """숫자 줄에서 '최고 N일'의 N. 없으면 None."""
    m = re.search(r'최고 (\d+)일', a.meta(name))
    return int(m.group(1)) if m else None


@item(S3, '습관마다 "연속 3일 · 최고 5일 · 이번 달 80%"처럼 연속 달성일과 이번 달 달성률 사이에 최고 연속 기록이 보인다.')
def t_best_format(a):
    a.close()
    a = App(data=sample())
    try:
        eq(a.meta('물 2L 마시기'), '연속 1일 · 최고 4일 · 이번 달 80%', '물 2L 마시기')
        eq(a.meta('스트레칭'), '연속 3일 · 최고 3일 · 이번 달 30%', '스트레칭')
        eq(a.meta('영어 단어'), '연속 0일 · 최고 1일 · 이번 달 10%', '영어 단어')
        eq(a.meta('일기 쓰기'), '연속 0일 · 최고 3일 · 이번 달 30%', '일기 쓰기')
    finally:
        a.close()


@item(S3, '11월 1~4일에 4일 연속 체크한 습관은 지금 연속이 짧아도 "최고 4일"이 보이고, 오늘 체크해도 "최고 4일" 그대로다.')
def t_best_past(a):
    a.close()
    a = App(data=sample())
    try:
        eq(best(a, '물 2L 마시기'), 4, '체크 전 최고')
        a.tap('물 2L 마시기')
        ok(a.meta('물 2L 마시기').startswith('연속 2일 '), f'체크 후: {a.meta("물 2L 마시기")}')
        eq(best(a, '물 2L 마시기'), 4, '체크 후 최고')
        a.reload()
        eq(best(a, '물 2L 마시기'), 4, '새로고침 후 최고')
    finally:
        a.close()


@item(S3, '어제까지 3일 연속 체크한 습관은 오늘 체크 전 "최고 3일", 체크 후 "최고 4일", 해제하면 다시 "최고 3일"이 보인다.')
def t_best_grow(a):
    a.close()
    a = App(data=sample())
    try:
        eq(best(a, '스트레칭'), 3, '체크 전 최고')
        a.tap('스트레칭')
        eq(best(a, '스트레칭'), 4, '체크 후 최고')
        a.tap('스트레칭')
        eq(best(a, '스트레칭'), 3, '해제 후 최고')
    finally:
        a.close()


@item(S3, '그저께까지 3일 연속 체크하고 어제를 빠뜨린 습관은 "최고 3일"이다. ‘어제’에서 체크하면 "최고 4일", 이어서 오늘도 체크하면 "최고 5일"이 된다.')
def t_best_fill(a):
    a.close()
    a = App(data=sample())
    try:
        eq(best(a, '일기 쓰기'), 3, '처음 최고')
        a.yesterday()
        a.tap('일기 쓰기')
        eq(best(a, '일기 쓰기'), 4, '어제 체크 후 최고')
        a.today()
        a.tap('일기 쓰기')
        eq(best(a, '일기 쓰기'), 5, '오늘 체크 후 최고')
        eq(a.meta('일기 쓰기'), '연속 5일 · 최고 5일 · 이번 달 45%', '오늘 체크 후 숫자 줄')
    finally:
        a.close()


@item(S3, '오늘 추가한 습관은 체크 전 "최고 0일", 체크 후 "최고 1일"로 보인다.')
def t_best_new(a):
    a.close()
    a = App(data=sample())
    try:
        a.open_manage()
        a.add('독서')
        a.close_manage()
        eq(a.meta('독서'), '연속 0일 · 최고 0일 · 이번 달 -', '체크 전')
        a.tap('독서')
        eq(a.meta('독서'), '연속 1일 · 최고 1일 · 이번 달 100%', '체크 후')
    finally:
        a.close()


# ---------------------------------------------------------------- 잔디 히트맵
@item(S4, '습관이 있으면 오늘 체크 화면 아래에 "최근 12주"와 12열 × 7줄 칸이 보이고, 맨 오른쪽 열에 오늘 칸이 테두리로 표시된다.')
def t_heat_shape(a):
    ok(not a.visible('#heatBox'), '습관이 없는데 히트맵이 보임')
    a.first_add('물 2L 마시기')
    ok(a.visible('#heatBox'), '히트맵이 안 보임')
    eq(a.page.locator('.heat-title').text_content(), '최근 12주', '제목')
    list_bottom = a.page.locator('#checkList').bounding_box()
    heat_top = a.page.locator('#heatBox').bounding_box()
    ok(heat_top['y'] >= list_bottom['y'] + list_bottom['height'] - 1, '히트맵이 목록 아래에 있지 않음')
    boxes = a.page.locator('#heatGrid .cell').evaluate_all(
        'es => es.map(e => { const r = e.getBoundingClientRect(); return [Math.round(r.x), Math.round(r.y), e.className]; })')
    eq(len(boxes), 84, '칸 수')
    xs = sorted({b[0] for b in boxes})
    ys = sorted({b[1] for b in boxes})
    eq((len(xs), len(ys)), (12, 7), '(열, 줄)')
    today = [b for b in boxes if 'today' in b[2].split()]
    eq(len(today), 1, '오늘 칸 수')
    eq(today[0][0], xs[-1], '오늘 칸의 열 (맨 오른쪽이어야 함)')
    eq(today[0][1], ys[3], '오늘 칸의 줄 (수요일 = 위에서 4번째)')
    eq(a.cell('2026-11-11').get_attribute('class').split().count('today'), 1, '오늘 칸 = 11월 11일')
    outline = a.page.locator('#heatGrid .cell.today').evaluate('e => getComputedStyle(e).outlineStyle')
    ok(outline not in ('none', ''), '오늘 칸에 테두리가 없음')
    # 첫 줄은 일요일, 아직 안 온 날(목~토)은 빈칸
    eq(a.page.locator('#heatGrid .cell').first.get_attribute('title'), '8월 23일 일요일 · 0개', '맨 왼쪽 위 칸')
    eq(a.page.locator('#heatGrid .cell.future').count(), 3, '빈칸(아직 안 온 날) 수')


@item(S4, '예시 백업을 불러오면 11월 8일·9일(3개)이 11월 7일·10일(2개)보다 진하고, 11월 1~4일·6일(1개)은 가장 옅은 색, 11월 5일(0개)과 10월 이전 칸은 회색이다.')
def t_heat_colors(a):
    a.first_add('임시')
    a.open_manage()
    a.import_file(SAMPLE)
    eq(a.dialogs[-1][0], 'confirm', '불러오기 확인 창')
    a.close_manage()
    lv = {f'2026-11-{d:02d}': a.level(f'2026-11-{d:02d}') for d in range(1, 11)}
    eq([lv['2026-11-08'], lv['2026-11-09']], [3, 3], '11월 8·9일 단계')
    eq([lv['2026-11-07'], lv['2026-11-10']], [2, 2], '11월 7·10일 단계')
    eq([lv[f'2026-11-0{d}'] for d in (1, 2, 3, 4, 6)], [1] * 5, '11월 1~4·6일 단계')
    eq(lv['2026-11-05'], 0, '11월 5일 단계')
    older = a.page.locator('#heatGrid .cell').evaluate_all(
        'es => es.filter(e => e.title && !e.title.startsWith("11월")).map(e => e.className)')
    ok(older and all(re.search(r'\bl\d\b', c) is None for c in older), '10월 이전 칸에 색이 있음')

    def lum(ymd):
        return luminance(a.cell(ymd).evaluate('e => getComputedStyle(e).backgroundColor'))
    ok(lum('2026-11-08') < lum('2026-11-07') < lum('2026-11-01') < lum('2026-11-05'),
       '진하기 순서가 3개 > 2개 > 1개 > 0개가 아님')
    eq(lum('2026-11-05'), lum('2026-10-15'), '11월 5일과 10월 칸의 색')
    c5 = a.cell('2026-11-05').evaluate('e => getComputedStyle(e).backgroundColor')
    nums = [int(x) for x in re.findall(r'\d+', c5)[:3]]
    ok(max(nums) - min(nums) < 12, f'0개 칸이 회색이 아님 ({c5})')


@item(S4, '오늘 습관을 체크하거나 ‘어제’에서 체크하면 그날 칸 색이 바로 진해지고, 해제하면 다시 옅어진다.')
def t_heat_live(a):
    a.close()
    a = App(data=sample())
    try:
        eq(a.level('2026-11-11'), 0, '오늘 처음 단계')
        a.tap('물 2L 마시기')
        eq(a.level('2026-11-11'), 1, '오늘 1개 체크')
        a.tap('스트레칭')
        eq(a.level('2026-11-11'), 2, '오늘 2개 체크')
        a.tap('스트레칭')
        eq(a.level('2026-11-11'), 1, '오늘 1개 해제')
        a.yesterday()
        eq(a.level('2026-11-10'), 2, '어제 처음 단계')
        a.tap('영어 단어')
        eq(a.level('2026-11-10'), 3, '어제 체크 후')
        a.tap('영어 단어')
        eq(a.level('2026-11-10'), 2, '어제 해제 후')
    finally:
        a.close()


@item(S4, '375px 폭에서도 히트맵 때문에 가로 스크롤이 생기지 않는다.')
def t_heat_375(a):
    a.close()
    a = App(width=375, data=sample())
    try:
        ok(a.visible('#heatBox'), '히트맵이 안 보임')
        ok(not a.hscroll(), '가로 스크롤이 생김')
        right = a.page.locator('#heatGrid').evaluate('e => e.getBoundingClientRect().right')
        ok(right <= 375, f'히트맵 오른쪽 끝이 화면 밖 ({right}px)')
    finally:
        a.close()


# ---------------------------------------------------------------- 백업
@item(S5, '내보내기를 누르면 `habits-backup-날짜.json` 파일이 다운로드된다.')
def t_export(a):
    a.close()
    a = App(data=sample())
    try:
        a.tap('물 2L 마시기')
        a.open_manage()
        name, path = a.export()
        eq(name, 'habits-backup-2026-11-11.json', '파일 이름')
        eq(json.loads(path.read_text(encoding='utf-8')), a.storage(), '파일 내용 = 저장된 기록')
    finally:
        a.close()
    # 새벽 3시에 내보내면 전날 날짜 (새벽 4시 기준)
    a = App(now=kst(2026, 11, 12, 3, 0), data=sample())
    try:
        a.open_manage()
        name, _ = a.export()
        eq(name, 'habits-backup-2026-11-11.json', '새벽 3시에 내보낸 파일 이름')
    finally:
        a.close()


@item(S5, '다른 브라우저에서 그 파일을 불러오면 습관, 체크, 숫자가 원래 브라우저와 똑같이 보인다.')
def t_other_browser(a):
    a.close()
    a = App(data=sample())
    b = None
    try:
        a.tap('물 2L 마시기')
        a.tap('일기 쓰기')
        snap = a.snapshot()
        heat = a.page.locator('#heatGrid').inner_html()
        a.yesterday()
        snap_y = a.snapshot()
        a.today()
        a.open_manage()
        _, path = a.export()
        b = App()  # 기록이 하나도 없는 새 브라우저 프로필
        b.open_manage()
        b.import_file(path)
        eq(b.dialogs[-1], ('confirm', '습관 4개, 기록 10일치를 불러옵니다. 지금 기록은 지워집니다.'), '확인 창')
        b.close_manage()
        eq(b.snapshot(), snap, '오늘 (이름, 체크, 숫자)')
        eq(b.page.locator('#heatGrid').inner_html(), heat, '히트맵')
        b.yesterday()
        eq(b.snapshot(), snap_y, '어제 (이름, 체크, 숫자)')
        eq(b.storage(), a.storage(), '저장된 기록')
    finally:
        a.close()
        if b:
            b.close()


@item(S5, '불러오기 확인 창에서 취소하면 지금 기록이 그대로 남는다.')
def t_import_cancel(a):
    a.first_add('독서')
    a.tap('독서')
    before = a.storage()
    a.open_manage()
    a.confirm_answer = False
    a.import_file(SAMPLE)
    eq(a.dialogs, [('confirm', '습관 4개, 기록 9일치를 불러옵니다. 지금 기록은 지워집니다.')], '확인 창')
    eq(a.storage(), before, '취소 후 저장된 기록')
    eq(a.mnames(), ['독서'], '취소 후 관리 화면')
    a.close_manage()
    ok(a.done('독서'), '취소 후 체크가 사라짐')


@item(S5, '상관없는 파일을 불러오면 "올바른 백업 파일이 아닙니다"가 뜨고 기록은 바뀌지 않는다.')
def t_import_bad(a):
    a.first_add('독서')
    a.tap('독서')
    before = a.storage()
    a.open_manage()
    bad = sample()
    bad['habits'].append({'id': 'h_a', 'name': '겹치는 id', 'createdAt': '2026-11-01'})
    files = {
        'note.txt': '그냥 메모입니다',
        'empty.json': '',
        'object.json': '{}',
        'array.json': '[]',
        'v2.json': json.dumps({'version': 2, 'habits': [], 'checks': {}}),
        'dup-id.json': json.dumps(bad, ensure_ascii=False),
        'unknown-id.json': json.dumps({'version': 1, 'habits': [], 'checks': {'2026-11-10': ['h_x']}}),
        'six.json': json.dumps({'version': 1, 'checks': {}, 'habits': [
            {'id': f'h_{i}', 'name': f'습관{i}', 'createdAt': '2026-11-01'} for i in range(6)]}, ensure_ascii=False),
    }
    for fname, text in files.items():
        n = len(a.dialogs)
        a.import_file(write_tmp(fname, text))
        eq(a.dialogs[n:], [('alert', '올바른 백업 파일이 아닙니다')], f'{fname} 을 불러왔을 때 뜬 창')
        eq(a.storage(), before, f'{fname} 을 불러온 뒤 기록')


@item(S5, '한 번도 내보내지 않았으면 관리 화면 백업 버튼 아래에 "아직 내보낸 적 없음"이 보인다.')
def t_never_exported(a):
    a.open_manage()
    eq(a.page.locator('#lastExport').text_content(), '아직 내보낸 적 없음', '문구')
    ok(a.visible('#lastExport'), '문구가 안 보임')
    btn = a.page.locator('#exportBtn').bounding_box()
    txt = a.page.locator('#lastExport').bounding_box()
    ok(txt['y'] >= btn['y'] + btn['height'] - 1, '문구가 백업 버튼 아래에 있지 않음')


@item(S5, '내보내기를 누르면 그 자리에 바로 "마지막으로 내보낸 날: 11월 11일 수요일"처럼 오늘 날짜가 보이고, 새로고침해도 남아 있다.')
def t_last_export(a):
    a.first_add('독서')
    a.open_manage()
    a.export()
    eq(a.page.locator('#lastExport').text_content(), '마지막으로 내보낸 날: 11월 11일 수요일', '내보낸 직후')
    a.reload()
    a.open_manage()
    eq(a.page.locator('#lastExport').text_content(), '마지막으로 내보낸 날: 11월 11일 수요일', '새로고침 후')


@item(S5, '불러오기를 해도 마지막으로 내보낸 날은 바뀌지 않고, 내보낸 파일 안에는 이 날짜가 들어가지 않는다.')
def t_last_export_import(a):
    a.close()
    a = App(data=sample(), extra_storage={EXPORT_KEY: '2026-11-05'})
    try:
        a.open_manage()
        eq(a.page.locator('#lastExport').text_content(), '마지막으로 내보낸 날: 11월 5일 목요일', '불러오기 전')
        a.import_file(SAMPLE)
        eq(a.dialogs[-1][0], 'confirm', '확인 창')
        eq(a.storage(EXPORT_KEY), '2026-11-05', '불러온 뒤 저장된 날짜')
        eq(a.page.locator('#lastExport').text_content(), '마지막으로 내보낸 날: 11월 5일 목요일', '불러온 뒤')
        _, path = a.export()
        text = path.read_text(encoding='utf-8')
        eq(sorted(json.loads(text).keys()), ['checks', 'habits', 'version'], '백업 파일의 항목')
        ok('export' not in text, '백업 파일에 내보낸 날이 들어 있음')
    finally:
        a.close()


# ---------------------------------------------------------------- 쓰기 편함
@item(S6, '브라우저 창을 휴대폰 폭(약 375px)으로 줄여도 가로 스크롤 없이 모두 보이고 누를 수 있다.')
def t_375(a):
    a.close()
    a = App(width=375)
    try:
        ok(not a.hscroll(), '빈 화면: 가로 스크롤')
        long_names = ['가나다라마바사아자차카타파하가나다라마바', 'abcdefghijklmnopqrst',
                      'WWWWWWWWWWWWWWWWWWWW', '물 2L 마시기 아침저녁으로 꼭', '1234567890123456789']
        a.first_add(long_names[0])
        a.open_manage()
        for n in long_names[1:]:
            a.add(n)
        eq(len(a.storage()['habits']), 5, '긴 이름 5개 추가')

        def check_screen(where):
            ok(not a.hscroll(), f'{where}: 가로 스크롤이 생김')
            bad = a.page.evaluate('''() => [...document.querySelectorAll('button, input, .name, .meta, .date, .hint')]
                .filter(e => e.offsetParent !== null && e.type !== 'file')
                .map(e => [e.textContent.trim() || e.tagName, e.getBoundingClientRect()])
                .filter(([t, r]) => r.left < 0 || r.right > document.documentElement.clientWidth + 0.5)
                .map(([t, r]) => t + ' (' + Math.round(r.left) + '~' + Math.round(r.right) + ')')''')
            eq(bad, [], f'{where}: 화면 밖으로 나간 것')

        check_screen('관리 화면')
        a.start_rename(long_names[0])
        check_screen('이름 바꾸는 중')
        a.page.locator('#manageList form button', has_text='취소').click()
        a.close_manage()
        for n in long_names:
            a.tap(n)
        check_screen('오늘 체크 화면 (모두 완료)')
        heights = a.page.locator('#checkList .row').evaluate_all('es => es.map(e => e.getBoundingClientRect().height)')
        ok(all(h >= 56 for h in heights), f'행 높이가 56px보다 낮음: {heights}')
        ok(all(a.done(n) for n in long_names), '375px에서 행을 눌러도 체크되지 않음')
        a.yesterday()
        check_screen('어제 보기')
    finally:
        a.close()


# ======================================================================
MANUAL = [
    ('체크', '색종이가 튀는 동안 조각이 "오늘 완료" 글자 뒤로 지나가서 글자가 가려지지 않고 또렷이 읽힌다.'),
    ('체크', '색종이가 튀는 동안 "오늘 완료" 글자 바로 뒤의 흰 바탕 안에는 조각이 보이지 않고, 바탕 밖에서만 조각이 보인다. 효과가 없을 때 흰 바탕은 눈에 띄지 않는다.'),
    ('체크', '(일부) 안드로이드 휴대폰에서 실제로 진동이 느껴지는지 — 테스트는 진동 요청이 한 번 나가는 것까지만 확인'),
    ('체크', '(일부) 색종이가 "작고", "잠깐 튀는" 모양으로 보기 좋은지 — 테스트는 조각이 생겼다가 1.5초 안에 없어지는 것까지만 확인'),
    ('체크', '(일부) 실제 PC 시계를 바꿨을 때 — 테스트는 브라우저 안의 시계를 가짜로 바꿔서 확인'),
    ('백업', '(일부) 정말 다른 브라우저(엣지·휴대폰 등)에서 불러오기 — 테스트는 기록이 없는 새 크롬 프로필에서 확인'),
    ('쓰기 편함', '파일을 열고 습관 5개를 모두 체크하기까지 10초가 안 걸린다. (사람 손으로 재 봐야 함)'),
]


def main():
    ap = argparse.ArgumentParser(description="plan.md '7. 완성의 기준' 자동 테스트")
    ap.add_argument('--headed', action='store_true', help='브라우저 창을 띄워서 실행')
    ap.add_argument('-k', default='', help='문장에 이 글자가 들어간 항목만 실행')
    args = ap.parse_args()

    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    chosen = [t for t in TESTS if args.k in t[1] or args.k in t[0]]
    passed, failed = 0, []
    started = time.time()
    with sync_playwright() as p:
        App.browser = p.chromium.launch(headless=not args.headed)
        section = None
        for sec, text, fn in chosen:
            if sec != section:
                section = sec
                print(f'\n■ {sec}')
            a = App()
            try:
                fn(a)
                passed += 1
                print(f'  [통과] {text}')
            except Exception as e:
                why = str(e) if isinstance(e, Fail) else ''.join(
                    traceback.format_exception_only(type(e), e)).strip()
                failed.append((sec, text, why))
                print(f'  [실패] {text}\n         → {why}')
            finally:
                a.close()
        App.browser.close()

    print('\n' + '=' * 60)
    print(f'자동 확인: {len(chosen)}개 중 통과 {passed}개, 실패 {len(failed)}개'
          f'  ({time.time() - started:.0f}초)')
    if failed:
        print('\n실패한 항목:')
        for sec, text, why in failed:
            print(f'  - [{sec}] {text}\n      → {why}')
    if not args.k:
        print('\n사람이 직접 봐야 하는 항목 (자동으로 확인하지 않음):')
        for sec, text in MANUAL:
            print(f'  - [{sec}] {text}')
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
