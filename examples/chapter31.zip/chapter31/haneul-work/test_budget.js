// budget.html 계산 검사.  실행: node test_budget.js
// budget.html 안의 <script id="budget-calc"> 부분을 그대로 꺼내 실행하므로, 화면과 같은 코드를 검사합니다.
// 예산 비율 = 전체 예산(돈)을 채널에 나누는 비율.
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const assert = require("assert");

const html = fs.readFileSync(path.join(__dirname, "budget.html"), "utf8");
const m = html.match(/<script id="budget-calc">([\s\S]*?)<\/script>/);
if (!m) { console.error("budget.html에서 계산 코드를 찾지 못했습니다."); process.exit(1); }
const sandbox = { module: { exports: {} } };
vm.runInNewContext(m[1], sandbox);
const { calcBudget, ratioMessage, DEFAULT_CHANNELS } = sandbox.module.exports;

const ch = (r1, r2, r3, cpa = [8224, 14417, 15653]) => [
  { name: "네이버", ratio: r1, cpa: cpa[0] },
  { name: "메타", ratio: r2, cpa: cpa[1] },
  { name: "구글", ratio: r3, cpa: cpa[2] },
];
const budgets = r => Array.from(r.rows, x => x.budget);
const convs = r => Array.from(r.rows, x => x.conversions);
const sum = a => a.reduce((s, x) => s + x, 0);

let pass = 0, fail = 0;
function test(name, fn) {
  try { fn(); pass++; console.log("  OK   " + name); }
  catch (e) { fail++; console.log("  FAIL " + name + "\n       " + e.message); }
}

console.log("광고 예산 계산기 테스트 (예산 비율 = 돈 배분)");

test("기본 전환당 비용이 44주 보고서 값", () => {
  assert.deepStrictEqual(Array.from(DEFAULT_CHANNELS, c => c.cpa), [8224, 14417, 15653]);
});

test("목표 1,000건 · 40:30:30 → 전체 11,285,083원", () => {
  const r = calcBudget(1000, ch(40, 30, 30));
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.total, 11285083);
});

test("같은 경우 채널별 예산 4,514,033 / 3,385,525 / 3,385,525원", () => {
  const r = calcBudget(1000, ch(40, 30, 30));
  assert.deepStrictEqual(budgets(r), [4514033, 3385525, 3385525]);
});

test("같은 경우 예상 전환 약 548.9 / 234.8 / 216.3건, 합 1,000건", () => {
  const r = calcBudget(1000, ch(40, 30, 30));
  assert.deepStrictEqual(convs(r).map(x => Math.round(x * 10) / 10), [548.9, 234.8, 216.3]);
  assert.ok(Math.abs(r.convSum - 1000) < 0.001, "전환 합 " + r.convSum);
});

test("돈이 실제로 40:30:30으로 나뉨 (반올림 1원 이내)", () => {
  const r = calcBudget(1000, ch(40, 30, 30));
  [40, 30, 30].forEach((p, i) => assert.ok(Math.abs(r.rows[i].budget - r.total * p / 100) <= 1));
});

test("전환당 비용이 모두 같으면 목표 × 비용, 비율대로 나눔", () => {
  const r = calcBudget(1000, ch(50, 30, 20, [10000, 10000, 10000]));
  assert.strictEqual(r.total, 10000000);
  assert.deepStrictEqual(budgets(r), [5000000, 3000000, 2000000]);
  assert.deepStrictEqual(convs(r), [500, 300, 200]);
});

test("한 채널 100% → 목표 × 그 채널 전환당 비용", () => {
  const r = calcBudget(250, ch(0, 0, 100));
  assert.strictEqual(r.total, 250 * 15653);
  assert.deepStrictEqual(budgets(r), [0, 0, 3913250]);
});

test("50:50 두 채널 → 조화평균 공식과 일치", () => {
  const r = calcBudget(1000, ch(50, 50, 0));
  const expected = Math.round(1000 * 2 * 8224 * 14417 / (8224 + 14417));
  assert.strictEqual(r.total, expected);
});

test("채널별 예산의 합 = 전체 예산 (어색한 숫자에서도)", () => {
  [[777, 33.3, 33.3, 33.4], [1, 40, 30, 30], [12345, 12.5, 62.5, 25], [999, 0.1, 0.1, 99.8]].forEach(([t, a, b, c]) => {
    const r = calcBudget(t, ch(a, b, c));
    assert.strictEqual(sum(budgets(r)), r.total, `${t}건 ${a}/${b}/${c}`);
    assert.ok(budgets(r).every(Number.isInteger));
  });
});

test("33.3+33.3+33.4 = 100%로 인정 (소수 합산 오차 없음)", () => {
  const r = calcBudget(100, ch(33.3, 33.3, 33.4));
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.ratioSum, 100);
  assert.strictEqual(ratioMessage(r.ratioSum), null);
});

test("비율 합 90% → 계산하지 않고 모자람 안내", () => {
  const r = calcBudget(1000, ch(40, 30, 20));
  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.ratioOk, false);
  assert.strictEqual(r.ratioSum, 90);
  assert.strictEqual(r.errors.length, 0);
  assert.match(ratioMessage(r.ratioSum), /90%.*10% 모자람/);
});

test("비율 합 110% → 계산하지 않고 초과 안내", () => {
  const r = calcBudget(1000, ch(50, 30, 30));
  assert.strictEqual(r.ok, false);
  assert.match(ratioMessage(r.ratioSum), /110%.*10% 초과/);
});

test("비율이 모두 0% → 0으로 나누지 않고 안내", () => {
  const r = calcBudget(1000, ch(0, 0, 0));
  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.ratioSum, 0);
});

test("전환당 비용을 고치면 결과에 반영", () => {
  const r = calcBudget(1000, ch(40, 30, 30, [9000, 14417, 15653]));
  const expected = Math.round(1000 / (0.4 / 9000 + 0.3 / 14417 + 0.3 / 15653));
  assert.strictEqual(r.total, expected);
  assert.ok(r.total > 11285083);
});

test("목표 0건 → 예산 0원", () => {
  const r = calcBudget(0, ch(40, 30, 30));
  assert.strictEqual(r.total, 0);
  assert.deepStrictEqual(budgets(r), [0, 0, 0]);
});

test("잘못된 입력은 계산하지 않고 오류 안내", () => {
  assert.strictEqual(calcBudget(-5, ch(40, 30, 30)).ok, false);
  assert.strictEqual(calcBudget(NaN, ch(40, 30, 30)).ok, false);          // 빈 칸
  assert.strictEqual(calcBudget(1000, ch(-10, 60, 50)).ok, false);
  assert.strictEqual(calcBudget(1000, ch(120, 0, 0)).ok, false);
  const r = calcBudget(1000, ch(40, 30, 30, [0, 14417, 15653]));
  assert.strictEqual(r.ok, false);
  assert.match(r.errors[0], /네이버 전환당 비용/);
});

console.log(`\n결과: ${pass}개 통과, ${fail}개 실패`);
process.exit(fail ? 1 : 0);
