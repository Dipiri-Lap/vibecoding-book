@echo off
set "RUN_BAT=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:RUN_BAT,[Text.Encoding]::UTF8); iex $t.Substring($t.IndexOf('#'+'PS-START'))"
echo.
pause
exit /b

#PS-START
# 이 아래는 PowerShell 코드입니다. 폴더에서 가장 최근 .tsv를 찾아 running.html 안의 데이터만 바꿔 넣습니다.
$ErrorActionPreference = 'Stop'
$dir  = Split-Path -Parent $env:RUN_BAT
$html = Join-Path $dir 'running.html'
try {
  if (-not (Test-Path -LiteralPath $html)) { throw "running.html 파일이 이 폴더에 없습니다: $dir" }
  $tsvs = @(Get-ChildItem -LiteralPath $dir -Filter '*.tsv' -File | Sort-Object LastWriteTime -Descending)
  if ($tsvs.Count -eq 0) { throw "폴더에 .tsv 파일이 없습니다. 구글 시트에서 [파일 > 다운로드 > 탭으로 구분된 값(.tsv)]으로 받아 이 폴더에 넣어 주세요." }
  $pick = $null; $data = $null
  foreach ($f in $tsvs) {
    $txt = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)
    $first = ($txt -split "`n")[0]
    if ($first.Contains('날짜') -and $first.Contains('이름') -and $first.Contains('거리') -and $first.Contains('시간')) { $pick = $f; $data = $txt; break }
    Write-Host "[건너뜀] $($f.Name) : 첫 줄에 날짜/이름/거리/시간 칸이 없음"
  }
  if (-not $pick) { throw "러닝 기록 .tsv를 찾지 못했습니다 (첫 줄에 날짜, 이름, 거리, 시간이 있어야 함)." }
  $data = $data.TrimStart([char]0xFEFF).Replace('</', '<\/')
  $page = [IO.File]::ReadAllText($html, [Text.Encoding]::UTF8)
  $a = $page.IndexOf('<!--DATA-START-->'); $b = $page.IndexOf('<!--DATA-END-->')
  if ($a -lt 0 -or $b -lt $a) { throw "running.html 안에서 데이터 자리(DATA-START/DATA-END)를 찾지 못했습니다." }
  $name  = [Net.WebUtility]::HtmlEncode($pick.Name)
  $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm'
  $block = "<!--DATA-START-->`n<script type=`"text/plain`" id=`"sheet-data`" data-source=`"$name`" data-built=`"$stamp`">`n" + $data.TrimEnd() + "`n</script>`n"
  $new = $page.Substring(0, $a) + $block + $page.Substring($b)
  $tmp = $html + '.tmp'
  [IO.File]::WriteAllText($tmp, $new, (New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $tmp -Destination $html -Force
  $rows = @(($data -split "`n") | Where-Object { $_.Trim() -ne '' }).Count - 1
  Write-Host ""
  Write-Host "완료: $($pick.Name) ($rows 줄, 받은 시각 $($pick.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))로 running.html을 다시 만들었습니다." -ForegroundColor Green
  Write-Host "페이지 맨 아래 '검산'에 '모두 일치'가 나오면 끝입니다."
  if (-not $env:RUN_NO_OPEN) { Start-Process -FilePath $html }
} catch {
  Write-Host ""
  Write-Host "[오류] $($_.Exception.Message)" -ForegroundColor Red
}
