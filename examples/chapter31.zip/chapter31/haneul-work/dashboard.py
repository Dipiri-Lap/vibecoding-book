# -*- coding: utf-8 -*-
r"""주차별 광고 대시보드 만들기

구글 시트 '광고 일별 기록'을 TSV로 내려받은 파일을 읽어
dashboard.html (인터넷 없이 열리는 한 파일)을 만듭니다.

이 프로그램은 구글에 직접 접속하지 않습니다. 사람이 내려받은 파일만 읽습니다.
  구글 시트 → 파일 → 다운로드 → 탭으로 구분된 값(.tsv)
  → 받은 파일을 다운로드\광고시트\ 폴더에 넣기

사용법
  python dashboard.py                 # 다운로드\광고시트\ 에서 가장 최근 .tsv 사용
  python dashboard.py --file 경로.tsv  # 파일을 직접 지정

내려받은 파일은 읽기만 하며 고치지 않습니다(실행 전후 해시로 확인).
"""
import argparse, csv, hashlib, json, re, sys
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent
SHEET_DIR = BASE / "다운로드" / "광고시트"
TEMPLATE = BASE / "dashboard_template.html"
OUT = BASE / "dashboard.html"

CHANNELS = ["네이버", "메타", "구글"]
# 캠페인 → 채널. 채널 칸이 틀리게 적혀 있으면(예: 'Naver') 캠페인을 보고 이 표대로 고친다. (2026-11-10 결정)
# 새 캠페인이 생기면 여기에 한 줄 추가한다. 없으면 프로그램이 멈추고 알려 준다.
CAMPAIGN_CHANNEL = {
    "브랜드검색": "네이버", "가을신상_키워드": "네이버",
    "가을신상_리타겟팅": "메타", "팔로워_유입": "메타",
    "검색_가을신상": "구글", "디스플레이_리마케팅": "구글",
}
HEADER = ["날짜", "채널", "캠페인", "비용", "노출", "클릭", "전환"]
METRICS = ["비용", "노출", "클릭", "전환"]


def stop(msg):
    print(f"\n[멈춤] {msg}\n대시보드는 만들지 않았습니다. 시트를 확인하고 다시 내려받아 실행하세요.")
    sys.exit(1)


def pick_file(arg):
    if arg:
        p = Path(arg)
        if not p.exists():
            stop(f"파일이 없습니다: {p}")
        return p
    files = sorted(SHEET_DIR.glob("*.tsv"), key=lambda p: p.stat().st_mtime)
    if not files:
        stop(f"{SHEET_DIR} 폴더에 .tsv 파일이 없습니다. 시트를 TSV로 내려받아 넣어 주세요.")
    return files[-1]


def parse_date(s, row):
    s = s.strip()
    m = re.fullmatch(r"(\d{4})[-./]\s*(\d{1,2})[-./]\s*(\d{1,2})\.?", s)
    if not m:
        stop(f"{row}행 날짜를 읽을 수 없습니다: '{s}'")
    return date(*map(int, m.groups())).isoformat()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file")
    ap.add_argument("--out", help="만들 html 경로 (기본: dashboard.html)")
    args = ap.parse_args()
    global OUT
    if args.out:
        OUT = Path(args.out)
    src = pick_file(args.file)
    before = hashlib.sha256(src.read_bytes()).hexdigest()

    with open(src, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f, delimiter="\t"))
    header = [h.strip() for h in rows[0]]
    if header[:7] != HEADER:
        stop(f"첫 줄(제목 줄)이 예상과 다릅니다: {header[:7]}\n'광고 일별 기록' 시트를 내려받은 파일인지 확인하세요.")
    width = len(header)
    raw = []
    for i, r in enumerate(rows[1:]):
        if not any(c.strip() for c in r):
            continue                                   # 완전히 빈 줄은 건너뜀
        r = (r + [""] * width)[:width]
        raw.append(dict(zip(header, r), 시트행=i + 2))

    issues, cleaned = [], []
    for r in raw:
        rec = dict(r)
        rec["날짜"] = parse_date(r["날짜"], r["시트행"])
        rec["캠페인"] = r["캠페인"].strip()
        for m in METRICS:
            v = r[m].strip()
            if re.fullmatch(r"\d+", v):
                rec[m] = int(v)
            elif re.fullmatch(r"[\d,]+\s*원?", v) and re.search(r"\d", v):
                rec[m] = int(re.sub(r"[^\d]", "", v))
                issues.append(dict(행=[r["시트행"]], 날짜=rec["날짜"], 채널=r["채널"], 캠페인=rec["캠페인"],
                                   종류="숫자가 아닌 값", 내용=f"{m} 칸이 '{v}' (글자 포함)",
                                   처리=f"쉼표·'원'을 떼고 {rec[m]:,}로 읽음"))
            elif v == "":
                stop(f"{r['시트행']}행 {m} 칸이 비어 있습니다 ({rec['날짜']} {rec['캠페인']}). 아직 안 채운 줄이면 채운 뒤 다시 내려받으세요.")
            else:
                stop(f"{r['시트행']}행 {m} 칸을 숫자로 읽을 수 없습니다: '{v}'")
        camp = rec["캠페인"]
        if camp not in CAMPAIGN_CHANNEL:
            stop(f"{r['시트행']}행 캠페인 '{camp}'을 모릅니다. 새 캠페인이면 dashboard.py 위쪽 CAMPAIGN_CHANNEL에 추가하세요.")
        ch, right = r["채널"].strip(), CAMPAIGN_CHANNEL[camp]
        if ch != right:
            why = "목록에 없는 이름" if ch not in CHANNELS else f"'{camp}'은 {right} 캠페인"
            issues.append(dict(행=[r["시트행"]], 날짜=rec["날짜"], 채널=ch, 캠페인=camp,
                               종류="채널 이름 오류", 내용=f"채널 '{ch}' ({why})",
                               처리=f"캠페인 기준으로 '{right}'로 고쳐 셈"))
        rec["채널"] = right
        cleaned.append(rec)

    # 중복 줄: 날짜·캠페인·숫자 4개가 모두 같으면 한 줄만 센다
    seen, dedup, dup_removed = {}, [], []
    for rec in cleaned:
        key = (rec["날짜"], rec["캠페인"]) + tuple(rec[m] for m in METRICS)
        if key in seen:
            first = seen[key]
            memo = f" 메모: '{rec.get('메모', '')}'" if rec.get("메모", "").strip() else " 메모 없음"
            who = f"{first.get('입력한 사람', '')}, {rec.get('입력한 사람', '')} 두 사람이" \
                if first.get("입력한 사람") != rec.get("입력한 사람") else f"{rec.get('입력한 사람', '')}이(가)"
            issues.append(dict(행=[first["시트행"], rec["시트행"]], 날짜=rec["날짜"], 채널=rec["채널"], 캠페인=rec["캠페인"],
                               종류="중복 줄", 내용=f"{who} 같은 숫자로 두 번 입력.{memo}",
                               처리=f"{rec['시트행']}행을 빼고 한 줄만 셈 (비용 {rec['비용']:,}, 전환 {rec['전환']} 제외)"))
            dup_removed.append(rec)
            continue
        other = next((o for o in dedup if o["날짜"] == rec["날짜"] and o["캠페인"] == rec["캠페인"]), None)
        if other:
            stop(f"{other['시트행']}행과 {rec['시트행']}행이 같은 날({rec['날짜']}) 같은 캠페인({rec['캠페인']})인데 숫자가 다릅니다. 어느 쪽이 맞는지 팀에서 정해 주세요.")
        seen[key] = rec
        dedup.append(rec)

    for r in dedup:
        if r["클릭"] > r["노출"] or r["전환"] > r["클릭"]:
            stop(f"{r['시트행']}행 숫자가 이상합니다(클릭>노출 또는 전환>클릭): {r['날짜']} {r['캠페인']}")

    def week_start(d):
        d = date.fromisoformat(d)
        return (d - timedelta(d.weekday())).isoformat()

    dates = sorted({r["날짜"] for r in dedup})
    d0, d1 = date.fromisoformat(dates[0]), date.fromisoformat(dates[-1])
    all_days = [(d0 + timedelta(n)).isoformat() for n in range((d1 - d0).days + 1)]
    days_in_week = defaultdict(list)
    for d in all_days:
        days_in_week[week_start(d)].append(d)
    # 7일이 다 들어온 주만 대시보드에 넣는다. 첫 주·마지막 주가 덜 찼으면 빼 두고 표시한다.
    weeks = [w for w in sorted(days_in_week) if len(days_in_week[w]) == 7]
    partial = {w: ds for w, ds in days_in_week.items() if len(ds) < 7}
    if len(weeks) < 2:
        stop("7일이 다 찬 주가 2주 미만이라 지난주 대비를 계산할 수 없습니다.")
    used = [r for r in dedup if week_start(r["날짜"]) in weeks]
    held = [r for r in dedup if week_start(r["날짜"]) in partial]

    # 빠진 줄 (대시보드에 들어가는 주만 검사)
    present = {(r["날짜"], r["캠페인"]) for r in used}
    missing = defaultdict(list)
    for w in weeks:
        for d in days_in_week[w]:
            for camp, ch in CAMPAIGN_CHANNEL.items():
                if (d, camp) not in present:
                    missing[(d, ch)].append(camp)
    missing_notes = defaultdict(list)
    for (d, ch), camps in sorted(missing.items()):
        issues.append(dict(행=[], 날짜=d, 채널=ch, 캠페인=", ".join(camps),
                           종류="빠진 줄", 내용=f"이날 {ch} {len(camps)}개 캠페인 줄이 시트에 없음",
                           처리="숫자를 지어내지 않고 0으로 둠. 그 주 그래프에 '기록 빠짐' 표시"))
        missing_notes[week_start(d)].append(f"{d[5:].replace('-', '/')} {ch} {len(camps)}줄")
    for w, ds in sorted(partial.items()):
        issues.append(dict(행=[], 날짜=f"{ds[0]} ~ {ds[-1]}", 채널="전체", 캠페인="",
                           종류="덜 찬 주", 내용=f"{w} 주는 {len(ds)}일치만 있음 (월~일 7일이 안 됨)",
                           처리="카드·그래프에서 빼 둠. 7일이 다 차면 다음에 반영"))

    W = {w: {"합계": dict.fromkeys(METRICS, 0), **{c: dict.fromkeys(METRICS, 0) for c in CHANNELS}} for w in weeks}
    for r in used:
        for k in ("합계", r["채널"]):
            for m in METRICS:
                W[week_start(r["날짜"])][k][m] += r[m]

    # 검산
    checks = []
    for m in METRICS:
        sheet_all = sum(r[m] for r in cleaned)
        sheet_sumfn = sum(int(r[m].strip()) for r in raw if re.fullmatch(r"\d+", r[m].strip()))
        removed, held_v = sum(r[m] for r in dup_removed), sum(r[m] for r in held)
        dash_weeks = sum(W[w]["합계"][m] for w in weeks)
        dash_cells = sum(W[w][c][m] for w in weeks for c in CHANNELS)
        ok = sheet_all - removed - held_v == dash_weeks == dash_cells
        checks.append(dict(지표=m, 시트전체=sheet_all, 시트SUM=sheet_sumfn, 중복제외=removed, 덜찬주=held_v,
                           대시보드주합=dash_weeks, 대시보드채널합=dash_cells, 일치=ok))
    row_check = dict(시트줄=len(raw), 중복제외줄=len(dup_removed), 덜찬주줄=len(held), 사용줄=len(used),
                     기대줄=len(weeks) * 7 * len(CAMPAIGN_CHANNEL), 빠진줄=sum(len(v) for v in missing.values()),
                     캠페인수=len(CAMPAIGN_CHANNEL))
    rows_ok = row_check["사용줄"] + row_check["빠진줄"] == row_check["기대줄"] and \
        row_check["시트줄"] - row_check["중복제외줄"] - row_check["덜찬주줄"] == row_check["사용줄"]

    data = dict(
        source=dict(title="광고 일별 기록", file=src.name, first=weeks[0], last=days_in_week[weeks[-1]][-1]),
        channels=CHANNELS, weeks=weeks, weekly=W,
        missingWeeks={w: " · ".join(v) + " 기록 빠짐" for w, v in missing_notes.items()},
        rows=[[r["시트행"], r["날짜"], r["채널"], r["캠페인"]] + [r[m] for m in METRICS] for r in used],
        issues=issues, checks=checks, rowCheck=row_check,
    )
    html = TEMPLATE.read_text(encoding="utf-8").replace("/*__DATA__*/null", json.dumps(data, ensure_ascii=False))
    OUT.write_text(html, encoding="utf-8")

    after = hashlib.sha256(src.read_bytes()).hexdigest()
    last, prev = W[weeks[-1]]["합계"], W[weeks[-2]]["합계"]
    print(f"읽은 파일: {src}")
    print(f"주: {weeks[0]} ~ {days_in_week[weeks[-1]][-1]} ({len(weeks)}주), 가장 최근 주 {weeks[-1]}")
    print(f"최근 주 비용 {last['비용']:,}원 (지난주 {prev['비용']:,}원), 전환 {last['전환']}건 (지난주 {prev['전환']}건)")
    print(f"이상한 줄 {len(issues)}건 → 대시보드 아래 표에 적음")
    for c in checks:
        print(f"  검산 {c['지표']}: 시트 {c['시트전체']:,} − 중복 {c['중복제외']:,} − 덜 찬 주 {c['덜찬주']:,} = 대시보드 {c['대시보드주합']:,} → {'일치' if c['일치'] else '불일치'}")
    print(f"  검산 줄 수: {'일치' if rows_ok else '불일치'}  /  내려받은 파일 그대로인지: {'그대로' if before == after else '바뀜!'}")
    all_ok = all(c["일치"] for c in checks) and rows_ok and before == after
    print(f"\n결과: {'모두 일치' if all_ok else '불일치 있음 - 위 줄을 확인하세요'}  →  {OUT}")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
