@echo off
chcp 65001 > nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
where python > nul 2>&1
if %errorlevel%==0 (
    python dashboard.py %*
) else (
    py -3 dashboard.py %*
)
if %errorlevel%==0 (
    start "" "%~dp0dashboard.html"
)
echo.
pause
