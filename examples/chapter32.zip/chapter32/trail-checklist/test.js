// 자동 테스트: node test.js
// 실제 크롬을 화면 없이 띄워서 index.html을 열고, 사람이 누르듯 눌러 본다.
// 완성의 기준 2~9번 + items.md 표와 화면 목록이 같은지 확인한다.
const { spawn } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const CHROME = ["C:/Program Files/Google/Chrome/Application/chrome.exe",
  "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"].find(fs.existsSync);
if (!CHROME) { console.log("크롬/엣지를 찾지 못했습니다."); process.exit(2); }

const PORT = 9333;
// 올릴 폴더(public)의 파일과 원본(index.html) 둘 다 같은 시험을 한다
const PAGES = ["index.html", "public/index.html"];
let pageUrl, profile;

// ---- items.md 표 읽기 (정답 기준) ----
const rows = fs.readFileSync(path.join(__dirname, "items.md"), "utf8").split(/\r?\n/)
  .filter(l => /^\|\s*\d+\s*\|/.test(l))
  .map(l => l.split("|").slice(1, -1).map(s => s.trim()))
  .map(c => ({ name: c[1], kind: c[2], w: c[3], t: c[4], c: c[5] }));
const has = (cond, v) => cond === "모두" || cond.split(",").map(s => s.trim()).includes(v);
function expected(w, t, c) {
  const m = new Map();
  for (const r of rows) {
    if (!has(r.w, w) || !has(r.t, t) || !has(r.c, c)) continue;
    if (!m.has(r.name) || (r.kind === "필수" && m.get(r.name) !== "필수")) m.set(r.name, r.kind);
  }
  return m;
}

const results = [];
function check(label, ok, detail) {
  results.push(ok);
  console.log((ok ? "통과  " : "실패  ") + label + (detail ? "  → " + detail : ""));
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function main(file) {
  pageUrl = require("url").pathToFileURL(path.resolve(__dirname, file)).href;
  profile = fs.mkdtempSync(path.join(os.tmpdir(), "trail-test-"));
  results.length = 0;
  console.log("=== " + file + " ===");
  const proc = spawn(CHROME, ["--headless=new", "--disable-gpu", "--no-first-run",
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, "about:blank"], { stdio: "ignore" });
  try {
    let targets;
    for (let i = 0; i < 50; i++) {
      try { targets = await (await fetch(`http://127.0.0.1:${PORT}/json`)).json(); break; } catch { await sleep(200); }
    }
    const page = targets.find(t => t.type === "page");
    const ws = new WebSocket(page.webSocketDebuggerUrl);
    await new Promise(r => ws.addEventListener("open", r));
    let id = 0; const pending = {};
    ws.addEventListener("message", e => {
      const m = JSON.parse(e.data);
      if (m.id && pending[m.id]) { pending[m.id](m); delete pending[m.id]; }
    });
    const send = (method, params = {}) => new Promise(res => { pending[++id] = res; ws.send(JSON.stringify({ id, method, params })); });
    const ev = async expr => {
      const r = await send("Runtime.evaluate", { expression: expr, returnByValue: true, awaitPromise: true });
      if (r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails));
      return r.result.result.value;
    };

    await send("Page.enable");
    await send("Emulation.setDeviceMetricsOverride", { width: 375, height: 812, deviceScaleFactor: 2, mobile: true });
    await send("Page.navigate", { url: pageUrl });
    await sleep(800);

    // 확인 창(confirm)은 화면 없는 크롬에서 눌러 줄 수 없으니, 메시지를 기록하고 정해 둔 답을 돌려주게 바꿔 둔다
    const stubConfirm = `window.__answer = true; window.__msgs = [];
      window.confirm = m => { window.__msgs.push(m); return window.__answer; }; true`;
    await ev(stubConfirm);
    // 화면 쪽 도우미 함수
    await ev(`window.T = {
      pick(w,t,c){ [['weather',w],['temp',t],['course',c]].forEach(([g,v]) =>
        document.querySelector('.choice[data-group="'+g+'"][data-value="'+v+'"]').click()); },
      show(){ document.getElementById('show-btn').click(); },
      back(){ document.getElementById('repick-btn').click(); },
      names(id){ return [...document.querySelectorAll('#'+id+' .item')].map(b=>b.dataset.name); },
      count(){ return document.getElementById('count').textContent; },
      open(w,t,c){ T.back && 0; T.pick(w,t,c); T.show(); }
    }; true`);

    // ---------- 기준 2: 날씨 4, 기온 3, 코스 2개를 눌러 고를 수 있다 ----------
    const nums = await ev(`['weather','temp','course'].map(g => document.querySelectorAll('.choice[data-group="'+g+'"]').length)`);
    check("2. 선택 버튼 개수 날씨4 / 기온3 / 코스2", nums.join() === "4,3,2", "실제 " + nums.join("/"));
    const disabled0 = await ev(`document.getElementById('show-btn').disabled`);
    check("2. 아무것도 안 골랐을 때 '목록 보기'는 눌러지지 않는다", disabled0 === true);
    let allPick = true;
    for (const [g, vals] of [["weather", ["맑음", "흐림", "비", "눈"]], ["temp", ["더움", "선선", "추움"]], ["course", ["짧게", "보통"]]]) {
      for (const v of vals) {
        const ok = await ev(`(() => { document.querySelector('.choice[data-group="${g}"][data-value="${v}"]').click();
          const sel = [...document.querySelectorAll('.choice[data-group="${g}"]')].filter(b=>b.getAttribute('aria-pressed')==='true');
          return sel.length===1 && sel[0].dataset.value==='${v}'; })()`);
        if (!ok) allPick = false;
      }
    }
    check("2. 9개 버튼을 각각 눌러 고를 수 있고, 한 칸에 하나만 선택된다", allPick);
    check("2. 셋 다 고르면 '목록 보기'가 눌러진다", (await ev(`document.getElementById('show-btn').disabled`)) === false);

    // ---------- 기준 3: 비 / 맑음 ----------
    await ev(`T.pick('비','선선','보통'); T.show();`);
    let all = await ev(`T.names('list-required').concat(T.names('list-good'))`);
    check("3. '비'를 고르면 우비, 배낭 방수 덮개가 나온다", all.includes("우비") && all.includes("배낭 방수 덮개"));
    await ev(`T.back(); T.pick('맑음','선선','보통'); T.show();`);
    all = await ev(`T.names('list-required').concat(T.names('list-good'))`);
    check("3. '맑음'을 고르면 우비, 배낭 방수 덮개가 안 나온다", !all.includes("우비") && !all.includes("배낭 방수 덮개"));

    // ---------- 기준 4: 추움 / 더움 ----------
    await ev(`T.back(); T.pick('맑음','추움','짧게'); T.show();`);
    all = await ev(`T.names('list-required').concat(T.names('list-good'))`);
    check("4. '추움'을 고르면 장갑, 보온 옷이 나온다", all.includes("장갑") && all.includes("보온 옷 (플리스, 패딩)"));
    await ev(`T.back(); T.pick('맑음','더움','짧게'); T.show();`);
    all = await ev(`T.names('list-required').concat(T.names('list-good'))`);
    check("4. '더움'을 고르면 장갑, 보온 옷이 안 나온다", !all.includes("장갑") && !all.includes("보온 옷 (플리스, 패딩)"));

    // ---------- 기준 5: 보통 > 짧게 (모든 날씨·기온 조합) ----------
    let more = true, extra = true, detail = [];
    for (const w of ["맑음", "흐림", "비", "눈"]) for (const t of ["더움", "선선", "추움"]) {
      const n = async c => ev(`T.back(); T.pick('${w}','${t}','${c}'); T.show(); T.names('list-required').concat(T.names('list-good'))`);
      const s = await n("짧게"), m = await n("보통");
      if (!(m.length > s.length)) { more = false; detail.push(w + t); }
      if (!(m.includes("점심 도시락") && m.includes("여분 간식") && !s.includes("점심 도시락") && !s.includes("여분 간식"))) extra = false;
    }
    check("5. 12개 날씨·기온 조합 모두에서 '보통'이 '짧게'보다 준비물이 많다", more, detail.join(","));
    check("5. '보통'에만 점심 도시락, 여분 간식이 나온다", extra);

    // ---------- 기준 6: 눌러서 체크 / 개수 변화 ----------
    await ev(`T.back(); T.pick('맑음','선선','보통'); T.show();`);
    const total = await ev(`T.names('list-required').length + T.names('list-good').length`);
    const c0 = await ev(`T.count()`);
    check("6. 처음에는 0 / 전체개수 로 보인다", c0 === `0 / ${total}`, c0);
    await ev(`document.querySelector('.item').click(); document.querySelectorAll('.item')[1].click();`);
    const c2 = await ev(`T.count()`);
    const st = await ev(`[...document.querySelectorAll('.item')].slice(0,3).map(b=>b.getAttribute('aria-pressed'))`);
    check("6. 두 항목을 누르면 체크되고 개수가 2로 바뀐다", c2 === `2 / ${total}` && st.join() === "true,true,false", c2);
    await ev(`document.querySelector('.item').click();`);
    const c1 = await ev(`T.count()`);
    check("6. 체크한 항목을 다시 누르면 해제되고 개수가 1로 줄어든다", c1 === `1 / ${total}`, c1);

    // ---------- 기준 9: 필수 / 있으면 좋은 것 구분 + 표와 일치 (24가지 전부) ----------
    let sepOk = true, tableOk = true, bad = [];
    for (const w of ["맑음", "흐림", "비", "눈"]) for (const t of ["더움", "선선", "추움"]) for (const c of ["짧게", "보통"]) {
      const got = await ev(`T.back(); T.pick('${w}','${t}','${c}'); T.show(); ({req: T.names('list-required'), good: T.names('list-good')})`);
      const exp = expected(w, t, c);
      const expReq = [...exp].filter(([, k]) => k === "필수").map(([n]) => n).sort();
      const expGood = [...exp].filter(([, k]) => k === "좋음").map(([n]) => n).sort();
      if (got.req.length === 0 || got.good.length === 0) sepOk = false;
      if (got.req.slice().sort().join("|") !== expReq.join("|") || got.good.slice().sort().join("|") !== expGood.join("|")) {
        tableOk = false; bad.push(`${w}/${t}/${c}`);
      }
    }
    const heads = await ev(`[...document.querySelectorAll('h2')].map(h=>h.textContent)`);
    check("9. '필수 준비물' / '있으면 좋은 것' 제목이 따로 있다", heads.join() === "필수 준비물,있으면 좋은 것", heads.join());
    check("9. 24가지 조합 모두 필수 칸과 좋음 칸이 둘 다 채워져 나뉘어 보인다", sepOk);
    check("9. 24가지 조합 모두 items.md 표와 항목·구분이 똑같다 (같은 항목은 필수만)", tableOk, bad.slice(0, 3).join(", "));

    // ---------- 기준 7: 닫았다 다시 열어도 체크가 남는다 ----------
    const reopen = async () => {            // 페이지를 완전히 닫았다가(빈 페이지) 같은 주소를 새로 연다
      await send("Page.navigate", { url: "about:blank" }); await sleep(400);
      await send("Page.navigate", { url: pageUrl }); await sleep(800);
      await ev(stubConfirm);
      await ev(`window.T = {
        pick(w,t,c){ [['weather',w],['temp',t],['course',c]].forEach(([g,v]) =>
          document.querySelector('.choice[data-group="'+g+'"][data-value="'+v+'"]').click()); },
        show(){ document.getElementById('show-btn').click(); },
        names(id){ return [...document.querySelectorAll('#'+id+' .item')].map(b=>b.dataset.name); },
        count(){ return document.getElementById('count').textContent; },
        on(){ return [...document.querySelectorAll('.item')].filter(b=>b.getAttribute('aria-pressed')==='true').map(b=>b.dataset.name); }
      }; true`);
    };
    await ev(`T.back(); T.pick('맑음','선선','보통'); T.show(); document.getElementById('reset-btn').click(); true`);
    const total7 = await ev(`T.names('list-required').length + T.names('list-good').length`);
    await ev(`document.querySelectorAll('.item')[0].click(); document.querySelectorAll('.item')[2].click(); document.querySelectorAll('.item')[5].click(); true`);
    const before = await ev(`[...document.querySelectorAll('.item')].filter(b=>b.getAttribute('aria-pressed')==='true').map(b=>b.dataset.name)`);
    await reopen();
    const fresh = await ev(`document.getElementById('screen-list').hidden === true && document.getElementById('screen-pick').hidden === false`);
    check("7. 페이지를 닫았다 다시 열면 고르기 화면부터 시작한다 (새로 열린 상태)", fresh);
    await ev(`T.pick('맑음','선선','보통'); T.show(); true`);
    const after = await ev(`T.on()`);
    const c7 = await ev(`T.count()`);
    check("7. 같은 조건을 고르면 체크했던 3개가 그대로 체크돼 있다",
      before.length === 3 && after.slice().sort().join("|") === before.slice().sort().join("|"), after.join(", "));
    check("7. 체크한 개수도 그대로 3 / 전체로 보인다", c7 === `3 / ${total7}`, c7);
    // 다른 조건으로 가도 같은 이름의 항목은 체크가 유지된다
    await ev(`document.getElementById('repick-btn').click(); T.pick('비','추움','보통'); T.show(); true`);
    const other = await ev(`T.on()`);
    const otherAll = await ev(`T.names('list-required').concat(T.names('list-good'))`);
    const shared = before.filter(n => otherAll.includes(n));
    check("7. 다른 조건에서도 같은 이름 항목(" + shared.join(", ") + ")은 체크가 유지된다",
      shared.length > 0 && shared.every(n => other.includes(n)) && other.length === shared.length, other.join(", "));
    // 저장 내용 확인 (이 폰 안에만 저장: localStorage)
    const raw = await ev(`localStorage.getItem('trail-checklist-checked')`);
    check("7. 저장 위치는 브라우저 localStorage이고 항목 이름만 들어 있다", typeof raw === "string" && Object.keys(JSON.parse(raw)).sort().join("|") === before.slice().sort().join("|"), raw);

    // ---------- 기준 8: 전부 초기화 ----------
    await ev(`document.getElementById('repick-btn').click(); T.pick('맑음','선선','보통'); T.show(); true`);
    const preOn = await ev(`T.on().length`);
    check("8. (준비) 초기화 전에 체크가 3개 있다", preOn === 3, String(preOn));
    // 확인 창에서 '취소'하면 아무것도 지워지지 않는다
    await ev(`window.__msgs = []; window.__answer = false; document.getElementById('reset-btn').click(); true`);
    const keptOn = await ev(`T.on().length`);
    const keptRaw = await ev(`localStorage.getItem('trail-checklist-checked')`);
    const msgs = await ev(`window.__msgs`);
    check("8. '전부 초기화'를 누르면 '정말 지울까요?' 확인 창이 먼저 뜬다", msgs.length === 1 && msgs[0].startsWith("정말 지울까요?"), msgs[0]);
    check("8. 확인 창에서 취소하면 체크 3개와 저장 내용이 그대로 남는다", keptOn === 3 && Object.keys(JSON.parse(keptRaw)).length === 3, `${keptOn}개`);
    await ev(`window.__answer = true; document.getElementById('reset-btn').click(); true`);
    const postOn = await ev(`T.on().length`);
    const cz = await ev(`T.count()`);
    check("8. '전부 초기화'를 누르면 체크가 모두 사라지고 0 / 전체로 바뀐다", postOn === 0 && cz === `0 / ${total7}`, cz);
    check("8. 초기화 버튼이 체크리스트 화면에 보인다", (await ev(`document.getElementById('reset-btn').textContent`)) === "전부 초기화");
    // 눈 오는 날 목록에도 안 보이는 항목까지 포함해 전부 지워지는지: 다른 조건에서 체크 → 초기화 → 원래 조건 확인
    await ev(`document.getElementById('repick-btn').click(); T.pick('눈','추움','보통'); T.show(); document.querySelectorAll('.item')[0].click(); document.querySelectorAll('.item')[1].click(); true`);
    await ev(`document.getElementById('reset-btn').click(); true`);
    const rawAfter = await ev(`localStorage.getItem('trail-checklist-checked')`);
    check("8. 초기화하면 저장된 내용도 비워진다", rawAfter === "{}", rawAfter);
    await reopen();
    await ev(`T.pick('맑음','선선','보통'); T.show(); true`);
    const reopened0 = await ev(`T.count()`);
    check("8. 초기화 후 닫았다 다시 열어도 체크가 돌아오지 않는다", reopened0 === `0 / ${total7}`, reopened0);

    ws.close();
  } finally {
    proc.kill();
    await sleep(300);
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch {}
  }
  const pass = results.filter(Boolean).length;
  console.log(`결과(${file}): ${pass} / ${results.length} 통과`);
  return [pass, results.length];
}

// 공개용 파일 점검: 같은 내용인지, 미리보기 태그, 이미지 크기
function publishChecks() {
  console.log("=== 공개용 파일 점검 ===");
  const r = [];
  const c = (label, ok, d) => { r.push(ok); console.log((ok ? "통과  " : "실패  ") + label + (d ? "  → " + d : "")); };
  const A = fs.readFileSync(path.join(__dirname, "index.html"));
  const B = fs.readFileSync(path.join(__dirname, "public/index.html"));
  c("public/index.html이 index.html과 똑같다", A.equals(B));
  const html = B.toString("utf8");
  const meta = (attr, name) => { const m = html.match(new RegExp('<meta ' + attr + '="' + name + '" content="([^"]*)"')); return m && m[1]; };
  const SITE = "https://sanhaeng-checklist.netlify.app/";
  c("제목·설명 태그가 있다", !!html.match(/<title>[^<]+<\/title>/) && !!meta("name", "description") && !!meta("property", "og:title") && !!meta("property", "og:description"));
  c("og:url이 사이트 주소다", meta("property", "og:url") === SITE, meta("property", "og:url"));
  c("og:image가 사이트 주소로 시작하는 전체 주소다", (meta("property", "og:image") || "").startsWith(SITE), meta("property", "og:image"));
  const imgName = (meta("property", "og:image") || "").slice(SITE.length);
  const png = path.join(__dirname, "public", imgName);
  const ok = fs.existsSync(png);
  const buf = ok ? fs.readFileSync(png) : Buffer.alloc(0);
  c("그 이미지 파일이 public에 있고 PNG이다", ok && buf.slice(1, 4).toString() === "PNG", imgName);
  c("이미지 크기가 1200 x 630이다", ok && buf.readUInt32BE(16) === 1200 && buf.readUInt32BE(20) === 630);
  c("외부 주소로 요청하는 코드가 없다 (og 태그 밖에 http 주소 없음)", !html.replace(/<meta [^>]*>/g, "").match(/https?:\/\//));
  const files = fs.readdirSync(path.join(__dirname, "public")).sort().join(",");
  c("public에는 index.html과 미리보기 이미지만 있다", files === "index.html," + imgName || files === imgName + ",index.html", files);
  return [r.filter(Boolean).length, r.length];
}

(async () => {
  let pass = 0, total = 0;
  for (const f of PAGES) { const [p, t] = await main(f); pass += p; total += t; }
  const [p, t] = publishChecks(); pass += p; total += t;
  console.log(`전체 결과: ${pass} / ${total} 통과`);
  process.exit(pass === total ? 0 : 1);
})().catch(e => { console.log("테스트 실행 오류:", e.message); process.exit(2); });
