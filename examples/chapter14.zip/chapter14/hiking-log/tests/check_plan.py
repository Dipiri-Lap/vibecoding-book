# -*- coding: utf-8 -*-
"""
plan.md '7. 완성의 기준'을 자동으로 확인하는 테스트.

돌리는 방법 (프로젝트 폴더에서):
    python tests/check_plan.py

- index.html은 건드리지 않는다. 파일을 그대로 브라우저(휴대폰 폭 375px)로 열어 눌러 본다.
- 이 컴퓨터에 이미 있는 Python Playwright와 Chromium만 쓴다.
- 매 항목마다 깨끗한 브라우저를 새로 열기 때문에 실제 휴대폰 기록에는 영향이 없다.
- 사람이 직접 봐야 하는 항목(1분 안에 입력 등)은 여기서 확인하지 않는다.
"""
import datetime
import json
import os
import sys
import tempfile
import traceback
from pathlib import Path

from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
# 보통은 프로젝트의 index.html을 연다. (테스트가 잘 잡아내는지 볼 때만 HIKING_HTML로 다른 파일을 지정)
URL = Path(os.environ.get("HIKING_HTML") or (ROOT / "index.html")).resolve().as_uri()
KEY = "hikingRecords.v1"

TODAY = datetime.date.today()
Y = TODAY.year
Y1 = Y - 1
TODAY_S = TODAY.isoformat()

MOBILE = dict(
    viewport={"width": 375, "height": 812},
    device_scale_factor=2,
    is_mobile=True,
    has_touch=True,
    locale="ko-KR",
    accept_downloads=True,
)

TESTS = []


def test(no, title):
    def deco(fn):
        TESTS.append((no, title, fn))
        return fn
    return deco


class Fail(Exception):
    pass


def check(cond, msg):
    if not cond:
        raise Fail(msg)


# ---------------- 도우미 ----------------
_seq = [0]


def rec(date, mountain, course="코스", dur=120, rating=3, memo="", comp=""):
    _seq[0] += 1
    return {"id": "h_%d" % (1000000 + _seq[0]), "date": date, "mountain": mountain,
            "course": course, "durationMin": dur, "rating": rating, "memo": memo,
            "companions": comp}


def open_app(browser, seed=None):
    ctx = browser.new_context(**MOBILE)
    page = ctx.new_page()
    page.goto(URL)
    if seed is not None:
        page.evaluate("([k, r]) => localStorage.setItem(k, JSON.stringify(r))", [KEY, seed])
        page.reload()
    wait_home(page)
    return ctx, page


def wait_home(page):
    page.locator("#vHome").wait_for(state="visible")


def wait_form(page):
    page.locator("#vForm").wait_for(state="visible")


def stored(page):
    return page.evaluate("k => JSON.parse(localStorage.getItem(k) || '[]')", KEY)


def cards(page):
    return page.eval_on_selector_all("#list .card", """els => els.map(e => ({
        id: e.dataset.id,
        mountain: e.querySelector('.mt').textContent,
        course: e.querySelector('.course').textContent,
        rating: e.querySelector('.stars-s').getAttribute('aria-label'),
        text: e.innerText
    }))""")


def mountains(page):
    return [c["mountain"] for c in cards(page)]


def summary(page):
    return (page.text_content("#sumYear"), page.text_content("#sumCount"), page.text_content("#sumTime"))


def visible(page, sel):
    return page.locator(sel).is_visible()


def fill_form(page, date=None, mountain=None, course=None, h=None, m=None, rating=None, memo=None, comp=None):
    if date is not None:
        page.fill("#fDate", date)
    if mountain is not None:
        page.fill("#fMountain", mountain)
    if course is not None:
        page.fill("#fCourse", course)
    if h is not None:
        page.select_option("#fH", str(h))
    if m is not None:
        page.select_option("#fM", str(m))
    if rating is not None:
        page.click('.star[data-v="%d"]' % rating)
    if memo is not None:
        page.fill("#fMemo", memo)
    if comp is not None:
        page.fill("#fComp", comp)


def add_via_ui(page, date=None, mountain="북한산", course="우이동 → 백운대", h=3, m=30, rating=4, memo=None, comp=None):
    page.click("#addBtn")
    wait_form(page)
    fill_form(page, date, mountain, course, h, m, rating, memo, comp)
    page.click("#saveBtn")
    wait_home(page)


def open_card(page, mountain):
    page.locator("#list .card", has_text=mountain).first.click()
    wait_form(page)


def chips(page):
    return page.eval_on_selector_all("#years .ychip", "els => els.map(e => e.textContent)")


def chip_on(page):
    return page.eval_on_selector_all("#years .ychip.on", "els => els.map(e => e.textContent)")


def options(page, list_id):
    return page.eval_on_selector_all("#%s option" % list_id, "els => els.map(e => e.value)")


def overflow(page):
    """가로로 화면 밖으로 삐져나간 요소를 찾는다. (자기 부모가 잘라 내는 것은 제외)"""
    return page.evaluate("""() => {
        const W = document.documentElement.clientWidth;
        const out = [];
        if (document.documentElement.scrollWidth > W + 1) out.push('문서 폭 ' + document.documentElement.scrollWidth + 'px');
        for (const el of document.querySelectorAll('body *')) {
            const r = el.getBoundingClientRect();
            if (!r.width || !r.height) continue;
            if (r.right <= W + 1 && r.left >= -1) continue;
            let clipped = false;
            for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
                const ox = getComputedStyle(p).overflowX;
                if (ox !== 'visible') { const pr = p.getBoundingClientRect(); if (pr.right <= W + 1 && pr.left >= -1) { clipped = true; break; } }
            }
            if (!clipped) out.push((el.id ? '#' + el.id : el.tagName.toLowerCase() + '.' + el.className) + ' (오른쪽 끝 ' + Math.round(r.right) + 'px)');
        }
        return out;
    }""")


class Dialogs:
    """확인창·알림창을 기록하고 정해진 대로 누른다."""
    def __init__(self, page, accept=True):
        self.seen = []
        self.accept = accept
        page.on("dialog", self._on)

    def _on(self, d):
        self.seen.append((d.type, d.message))
        if d.type == "confirm" and not self.accept:
            d.dismiss()
        else:
            d.accept()


# ---------------- 완성의 기준 ----------------

@test(1, "홈 화면이 가로 스크롤 없이 보인다 (375px)")
def t1(browser):
    ctx, page = open_app(browser)
    check(not overflow(page), "빈 홈에서 가로로 넘치는 것: %s" % overflow(page))
    long_name = "아주아주아주긴이름의산" * 4
    seed = [rec("%d-05-01" % Y, long_name, "아주 긴 코스 " * 10, comp="민수, 지영"),
            rec("%d-05-01" % Y1, "북한산", memo="메모 " * 50)]
    page.evaluate("([k, r]) => localStorage.setItem(k, JSON.stringify(r))", [KEY, seed])
    page.reload()
    wait_home(page)
    page.click("#people summary")
    check(not overflow(page), "기록이 있는 홈에서 가로로 넘치는 것: %s" % overflow(page))
    page.click("#addBtn")
    wait_form(page)
    check(not overflow(page), "기록 입력 화면에서 가로로 넘치는 것: %s" % overflow(page))
    page.go_back()
    wait_home(page)
    page.click("#backupBtn")
    page.locator("#vBackup").wait_for(state="visible")
    check(not overflow(page), "백업 화면에서 가로로 넘치는 것: %s" % overflow(page))
    ctx.close()


@test(2, "「기록하기」를 누르면 날짜 칸에 오늘 날짜가 채워져 있다")
def t2(browser):
    ctx, page = open_app(browser)
    page.click("#addBtn")
    wait_form(page)
    v = page.input_value("#fDate")
    check(v == TODAY_S, "날짜 칸 값이 %r (오늘은 %s)" % (v, TODAY_S))
    ctx.close()


@test(4, "필수 항목을 비우면 저장되지 않고 빈 칸이 표시된다 / 메모·함께 간 사람은 비워도 저장된다")
def t4(browser):
    ctx, page = open_app(browser)
    full = dict(date=TODAY_S, mountain="북한산", course="우이동", h=2, m=0, rating=3)
    cases = [("wDate", "날짜", "date"), ("wMountain", "산 이름", "mountain"), ("wCourse", "코스", "course"),
             ("wDur", "걸린 시간", "h"), ("wRating", "별점", "rating")]
    for wrap, label, key in cases:
        page.click("#addBtn")
        wait_form(page)
        args = dict(full)
        args[key] = None
        if key == "date":
            page.fill("#fDate", "")
        fill_form(page, **args)
        page.click("#saveBtn")
        page.wait_for_timeout(150)
        check(visible(page, "#vForm"), "%s을(를) 비웠는데 홈으로 넘어갔다" % label)
        check("invalid" in (page.get_attribute("#" + wrap, "class") or ""), "%s 칸이 빈 칸으로 표시되지 않았다" % label)
        check(page.locator("#%s .err" % wrap).is_visible(), "%s 칸의 안내 문구가 보이지 않는다" % label)
        others = [w for w, _, _ in cases if w != wrap and "invalid" in (page.get_attribute("#" + w, "class") or "")]
        check(not others, "%s만 비웠는데 다른 칸도 빈 칸 표시: %s" % (label, others))
        check(len(stored(page)) == 0, "%s을(를) 비웠는데 저장되었다" % label)
        page.go_back()
        wait_home(page)
    # 0시간 0분도 걸린 시간이 빈 것으로 본다
    page.click("#addBtn")
    wait_form(page)
    fill_form(page, **dict(full, h=0, m=0))
    page.click("#saveBtn")
    page.wait_for_timeout(150)
    check(visible(page, "#vForm") and len(stored(page)) == 0, "0시간 0분인데 저장되었다")
    page.go_back()
    wait_home(page)
    # 메모·함께 간 사람 비워도 저장
    add_via_ui(page, mountain="북한산", course="우이동", h=2, m=0, rating=3)
    s = stored(page)
    check(len(s) == 1 and s[0]["memo"] == "" and s[0]["companions"] == "", "메모·함께 간 사람이 빈 기록이 저장되지 않았다: %s" % s)
    ctx.close()


@test(5, "저장하면 홈으로 돌아오고, 방금 기록이 목록 맨 위에 보인다")
def t5(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "관악산"), rec("%d-01-02" % Y, "도봉산")])
    add_via_ui(page, mountain="수락산")
    check(visible(page, "#vHome"), "저장 후 홈 화면이 아니다")
    check(mountains(page)[0] == "수락산", "맨 위 카드가 %s" % mountains(page)[:1])
    ctx.close()


@test(6, "검색어·연도를 고른 채 맞지 않는 산을 저장하면 가림이 풀리고, 맞는 산이면 그대로 남는다")
def t6(browser):
    ctx, page = open_app(browser, [rec("%d-03-01" % Y, "북한산"), rec("%d-03-01" % Y1, "관악산")])
    # 맞지 않는 경우: 작년 + "관악" 검색 중에 올해 도봉산 저장
    page.click('#years .ychip[data-y="%d"]' % Y1)
    page.fill("#q", "관악")
    add_via_ui(page, mountain="도봉산")
    check("도봉산" in mountains(page), "방금 저장한 도봉산이 목록에 없다: %s" % mountains(page))
    check(page.input_value("#q") == "", "맞지 않는 검색어가 풀리지 않았다: %r" % page.input_value("#q"))
    check(chip_on(page) == ["전체"], "맞지 않는 연도가 풀리지 않았다: %s" % chip_on(page))
    # 검색어만 안 맞는 경우: 연도(올해)는 그대로 남아야 한다
    page.click('#years .ychip[data-y="%d"]' % Y)
    page.fill("#q", "관악")
    add_via_ui(page, mountain="수락산")
    check("수락산" in mountains(page), "수락산이 목록에 없다")
    check(page.input_value("#q") == "", "맞지 않는 검색어가 풀리지 않았다")
    check(chip_on(page) == ["%d년" % Y], "맞는 연도까지 풀렸다: %s" % chip_on(page))
    # 맞는 경우: 올해 + "북한" 검색 중에 올해 북한산 저장
    page.fill("#q", "북한")
    add_via_ui(page, mountain="북한산", course="새 코스")
    check(page.input_value("#q") == "북한", "맞는 검색어가 지워졌다")
    check(chip_on(page) == ["%d년" % Y], "맞는 연도가 풀렸다: %s" % chip_on(page))
    check(mountains(page) == ["북한산", "북한산"], "걸러진 목록이 이상하다: %s" % mountains(page))
    ctx.close()


@test(7, "과거 날짜로 넣은 기록은 날짜 순서에 맞는 자리에 끼어 보인다")
def t7(browser):
    ctx, page = open_app(browser, [rec("%d-03-01" % Y1, "가산"), rec("%d-05-01" % Y1, "다산"), rec("%d-07-01" % Y1, "마산")])
    add_via_ui(page, date="%d-04-15" % Y1, mountain="나산")
    check(mountains(page) == ["마산", "다산", "나산", "가산"], "순서가 %s" % mountains(page))
    ctx.close()


@test(8, "올해 기록을 하나 추가하면 횟수가 1 늘고 총 시간이 입력한 만큼 늘어난다")
def t8(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "관악산", dur=90)])
    before = summary(page)
    check(before == ("%d년" % Y, "1회", "1시간 30분"), "처음 요약이 %s" % (before,))
    add_via_ui(page, mountain="북한산", h=3, m=45)
    after = summary(page)
    check(after == ("%d년" % Y, "2회", "5시간 15분"), "추가 후 요약이 %s (기대: 2회 · 5시간 15분)" % (after,))
    ctx.close()


@test(9, "작년 기록은 목록에는 보이지만 올해 요약에는 더해지지 않는다")
def t9(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "관악산", dur=60)])
    add_via_ui(page, date="%d-12-31" % Y1, mountain="작년산", h=5, m=0)
    check("작년산" in mountains(page), "작년 기록이 목록에 없다")
    check(summary(page)[1:] == ("1회", "1시간"), "요약이 %s" % (summary(page),))
    ctx.close()


@test(10, "카드를 눌러 별점을 바꾸고 저장하면 목록에 바뀐 별점이 보인다")
def t10(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "관악산", rating=5)])
    open_card(page, "관악산")
    check(visible(page, "#delBtn"), "수정 화면에 「삭제」 버튼이 없다")
    page.click('.star[data-v="2"]')
    page.click("#saveBtn")
    wait_home(page)
    check(cards(page)[0]["rating"] == "별점 2점", "카드 별점이 %s" % cards(page)[0]["rating"])
    check(len(stored(page)) == 1, "수정했는데 기록 수가 %d" % len(stored(page)))
    ctx.close()


@test(11, "「삭제」를 누르면 확인창이 뜨고, 확인하면 목록과 요약에서 사라진다")
def t11(browser):
    ctx, page = open_app(browser, [rec(TODAY_S, "관악산", dur=60), rec(TODAY_S, "북한산", dur=120)])
    dlg = Dialogs(page, accept=False)
    open_card(page, "관악산")
    page.click("#delBtn")
    page.wait_for_timeout(150)
    check(dlg.seen and dlg.seen[0][0] == "confirm", "확인창이 뜨지 않았다")
    check(len(stored(page)) == 2, "취소했는데 지워졌다")
    dlg.accept = True
    page.click("#delBtn")
    wait_home(page)
    check(mountains(page) == ["북한산"], "삭제 후 목록이 %s" % mountains(page))
    check(summary(page)[1:] == ("1회", "2시간"), "삭제 후 요약이 %s" % (summary(page),))
    ctx.close()


@test(12, "브라우저를 완전히 닫았다가 다시 열어도 기록이 그대로 있다")
def t12(browser, pw):
    with tempfile.TemporaryDirectory() as prof:
        opts = {k: v for k, v in MOBILE.items()}
        ctx = pw.chromium.launch_persistent_context(prof, **opts)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(URL)
        wait_home(page)
        add_via_ui(page, mountain="북한산")
        ctx.close()
        ctx = pw.chromium.launch_persistent_context(prof, **opts)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(URL)
        wait_home(page)
        ok = mountains(page) == ["북한산"]
        ctx.close()
        check(ok, "다시 열었더니 기록이 없다")


def do_export(page, folder):
    page.click("#backupBtn")
    page.locator("#vBackup").wait_for(state="visible")
    with page.expect_download() as dl:
        page.click("#exportBtn")
    d = dl.value
    path = os.path.join(folder, d.suggested_filename)
    d.save_as(path)
    return d.suggested_filename, path


@test(13, "「내보내기」를 누르면 JSON 파일이 저장된다")
def t13(browser):
    seed = [rec("%d-01-01" % Y, "관악산", memo="바람", comp="민수"), rec("%d-01-01" % Y1, "북한산")]
    ctx, page = open_app(browser, seed)
    with tempfile.TemporaryDirectory() as tmp:
        name, path = do_export(page, tmp)
        check(name == "hiking-backup-%s.json" % TODAY_S, "파일 이름이 %s" % name)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        check(data == stored(page), "파일 내용이 저장된 기록과 다르다")
        check(TODAY_S in page.text_content("#lastExport"), "마지막 내보낸 날짜가 표시되지 않았다: %s" % page.text_content("#lastExport"))
    ctx.close()


@test(14, "저장소가 빈 브라우저에서 그 파일을 「불러오기」 하면 목록과 요약이 똑같이 보인다")
def t14(browser):
    seed = [rec("%d-01-01" % Y, "관악산", dur=95, comp="민수, 지영"), rec("%d-06-01" % Y1, "북한산"),
            rec("%d-02-01" % Y, "도봉산", rating=1)]
    ctx, page = open_app(browser, seed)
    want = (cards(page), summary(page))
    with tempfile.TemporaryDirectory() as tmp:
        _, path = do_export(page, tmp)
        ctx.close()
        ctx2, page2 = open_app(browser)  # 새 브라우저, 저장소 비어 있음
        check(cards(page2) == [], "새 브라우저인데 기록이 있다")
        dlg = Dialogs(page2)
        page2.click("#backupBtn")
        page2.locator("#vBackup").wait_for(state="visible")
        page2.set_input_files("#fileInput", path)
        wait_home(page2)
        check([t for t, _ in dlg.seen] == ["confirm", "alert"], "확인창/알림 순서가 %s" % dlg.seen)
        check("바뀝니다" in dlg.seen[0][1], "불러오기 전 확인 문구가 %r" % dlg.seen[0][1])
        got = (cards(page2), summary(page2))
        check(got == want, "불러온 뒤 화면이 다르다\n  원래: %s\n  지금: %s" % (want, got))
        ctx2.close()


@test(15, "엉뚱한 파일을 불러오면 오류 안내가 뜨고 기존 기록은 지워지지 않는다")
def t15(browser):
    seed = [rec("%d-01-01" % Y, "관악산")]
    ctx, page = open_app(browser, seed)
    before = stored(page)
    dlg = Dialogs(page)
    bad_files = {
        "not-json.json": "이건 JSON이 아니에요",
        "object.json": json.dumps({"hello": 1}),
        "bad-record.json": json.dumps([{"id": "x", "date": "어제", "mountain": "", "course": "a", "durationMin": 1, "rating": 9}]),
        "photo.txt": "abc",
    }
    with tempfile.TemporaryDirectory() as tmp:
        for name, content in bad_files.items():
            p = os.path.join(tmp, name)
            with open(p, "w", encoding="utf-8") as f:
                f.write(content)
            dlg.seen.clear()
            page.click("#backBtn") if visible(page, "#backBtn") else None
            wait_home(page)
            page.click("#backupBtn")
            page.locator("#vBackup").wait_for(state="visible")
            page.set_input_files("#fileInput", p)
            page.wait_for_function("() => true")
            page.wait_for_timeout(300)
            check(dlg.seen and dlg.seen[0][0] == "alert" and "불러올 수 없는" in dlg.seen[0][1],
                  "%s: 오류 안내가 뜨지 않았다 (%s)" % (name, dlg.seen))
            check(not any(t == "confirm" for t, _ in dlg.seen), "%s: 덮어쓰기 확인창이 떴다" % name)
            check(stored(page) == before, "%s: 기존 기록이 바뀌었다" % name)
    page.click("#backBtn")
    wait_home(page)
    check(mountains(page) == ["관악산"], "목록이 %s" % mountains(page))
    ctx.close()


@test(16, "산 이름 후보: 전에 다녀온 산이 한 번씩, 자주 간 산이 위 / 고르면 칸에 채워진 채 저장된다")
def t16(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "관악산"), rec("%d-02-01" % Y, "북한산"),
                                   rec("%d-03-01" % Y, "북한산"), rec("%d-04-01" % Y, "도봉산")])
    page.click("#addBtn")
    wait_form(page)
    opts = options(page, "mountainList")
    check(page.get_attribute("#fMountain", "list") == "mountainList", "산 이름 칸이 후보 목록과 연결되어 있지 않다")
    check(opts[0] == "북한산" and sorted(opts) == sorted(["북한산", "관악산", "도봉산"]),
          "후보가 %s (북한산이 맨 위, 산마다 한 번)" % opts)
    check(opts == ["북한산", "도봉산", "관악산"], "같은 횟수면 최근 간 산이 위여야 한다: %s" % opts)
    fill_form(page, mountain=opts[0], course="새 코스", h=1, m=0, rating=3)
    page.click("#saveBtn")
    wait_home(page)
    check(mountains(page)[0] == "북한산", "후보 값으로 저장되지 않았다")
    ctx.close()


@test(17, "기록이 없으면 산 이름 후보가 없고, 처음 가는 산도 그대로 저장된다")
def t17(browser):
    ctx, page = open_app(browser)
    page.click("#addBtn")
    wait_form(page)
    check(options(page, "mountainList") == [], "기록이 없는데 후보가 %s" % options(page, "mountainList"))
    page.go_back()
    wait_home(page)
    add_via_ui(page, mountain="처음가본산")
    check(mountains(page) == ["처음가본산"], "목록이 %s" % mountains(page))
    ctx.close()


@test(18, "검색 칸에 \"북한\"을 치면 북한이 들어간 기록만 남고 \"「북한」 검색 결과 N건\"이 보인다 / 요약은 그대로")
def t18(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산"), rec("%d-02-01" % Y, "관악산"),
                                   rec("%d-03-01" % Y, "북 한산성"), rec("%d-04-01" % Y1, "북한산")])
    before = summary(page)
    page.fill("#q", "북한")
    got = mountains(page)
    check(sorted(got) == sorted(["북한산", "북 한산성", "북한산"]), "걸러진 목록이 %s (띄어쓰기 무시)" % got)
    check(page.text_content("#qInfo") == "「북한」 검색 결과 3건", "안내가 %r" % page.text_content("#qInfo"))
    check(summary(page) == before, "요약 숫자가 바뀌었다")
    ctx.close()


@test(19, "맞는 산이 없으면 \"기록이 없어요\", 「×」를 누르면 검색어가 지워지고 전체 목록이 보인다")
def t19(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산"), rec("%d-02-01" % Y, "관악산")])
    page.fill("#q", "설악")
    check(cards(page) == [], "카드가 남아 있다")
    check("기록이 없어요" in page.text_content("#list"), "안내가 %r" % page.text_content("#list"))
    check(visible(page, "#qClear"), "「×」 버튼이 안 보인다")
    page.click("#qClear")
    check(page.input_value("#q") == "", "검색어가 지워지지 않았다")
    check(len(cards(page)) == 2, "전체 목록이 다시 보이지 않는다")
    ctx.close()


@test(20, "검색한 상태에서 카드를 수정·저장하고 돌아와도 검색어와 걸러진 목록이 그대로다")
def t20(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산"), rec("%d-02-01" % Y, "관악산")])
    page.fill("#q", "북한")
    open_card(page, "북한산")
    page.click('.star[data-v="1"]')
    page.click("#saveBtn")
    wait_home(page)
    check(page.input_value("#q") == "북한", "검색어가 %r" % page.input_value("#q"))
    check(mountains(page) == ["북한산"], "목록이 %s" % mountains(page))
    check(cards(page)[0]["rating"] == "별점 1점", "수정이 반영되지 않았다")
    ctx.close()


@test(21, "기록이 한 해에만 있으면 연도 버튼이 없고, 작년 기록을 추가하면 「전체 / 올해 / 작년」이 생긴다")
def t21(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산")])
    check(not visible(page, "#years"), "한 해뿐인데 연도 버튼이 보인다")
    add_via_ui(page, date="%d-10-01" % Y1, mountain="관악산")
    check(visible(page, "#years"), "연도 버튼이 생기지 않았다")
    check(chips(page) == ["전체", "%d년" % Y, "%d년" % Y1], "버튼이 %s" % chips(page))
    ctx.close()


@test(22, "작년 버튼을 누르면 그해 기록만 남고 \"N년 기록 N건\" / 요약 그대로 / 「전체」로 복귀")
def t22(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산"), rec("%d-02-01" % Y1, "관악산"),
                                   rec("%d-03-01" % Y1, "도봉산")])
    before = summary(page)
    page.click('#years .ychip[data-y="%d"]' % Y1)
    check(sorted(mountains(page)) == ["관악산", "도봉산"], "목록이 %s" % mountains(page))
    check(page.text_content("#qInfo") == "%d년 기록 2건" % Y1, "안내가 %r" % page.text_content("#qInfo"))
    check(summary(page) == before, "요약 숫자가 바뀌었다")
    page.click('#years .ychip[data-y=""]')
    check(len(cards(page)) == 3, "「전체」를 눌러도 모든 기록이 보이지 않는다")
    ctx.close()


@test(23, "연도를 고른 채 검색하면 그해 그 산만 남고, 수정·저장 후에도 연도와 검색어가 그대로다")
def t23(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산"), rec("%d-02-01" % Y1, "북한산", course="작년코스"),
                                   rec("%d-03-01" % Y1, "관악산")])
    page.click('#years .ychip[data-y="%d"]' % Y1)
    page.fill("#q", "북한")
    check([c["course"] for c in cards(page)] == ["작년코스"], "걸러진 목록이 %s" % cards(page))
    open_card(page, "북한산")
    page.click('.star[data-v="5"]')
    page.click("#saveBtn")
    wait_home(page)
    check(chip_on(page) == ["%d년" % Y1], "고른 연도가 %s" % chip_on(page))
    check(page.input_value("#q") == "북한", "검색어가 %r" % page.input_value("#q"))
    check([c["course"] for c in cards(page)] == ["작년코스"], "목록이 %s" % cards(page))
    ctx.close()


@test(24, "연도 버튼이 많아져도 줄이 바뀌고 가로 스크롤이 생기지 않는다")
def t24(browser):
    ctx, page = open_app(browser, [rec("%d-06-01" % (Y - i), "산%d" % i) for i in range(15)])
    tops = page.eval_on_selector_all("#years .ychip", "els => [...new Set(els.map(e => e.offsetTop))]")
    check(len(chips(page)) == 16, "버튼 수가 %d" % len(chips(page)))
    check(len(tops) >= 2, "버튼이 한 줄에만 있다 (줄바꿈 안 됨)")
    check(not overflow(page), "가로로 넘치는 것: %s" % overflow(page))
    ctx.close()


@test(25, "「함께 간 사람별 횟수」를 누르면 펼쳐지고, \"민수, 지영\"은 따로 세며 많은 순이다")
def t25(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", comp="민수, 지영"), rec("%d-02-01" % Y, "관악산", comp="민수"),
                                   rec("%d-03-01" % Y, "도봉산")])
    check(visible(page, "#people"), "「함께 간 사람별 횟수」가 안 보인다")
    check(page.get_attribute("#people", "open") is None, "처음부터 펼쳐져 있다")
    page.click("#people summary")
    check(page.get_attribute("#people", "open") is not None, "눌러도 펼쳐지지 않는다")
    rows = page.eval_on_selector_all("#peopleList li", "els => els.map(e => e.querySelector('.nm').textContent + ' ' + e.querySelector('.ct').textContent)")
    check(rows == ["민수 2회", "지영 1회"], "목록이 %s" % rows)
    check(page.locator("#peopleList").is_visible(), "펼쳤는데 목록이 안 보인다")
    ctx.close()


@test(26, "연도를 바꾸면 사람별 횟수가 그해로 다시 세어지고, 산 이름 검색에는 영향이 없다")
def t26(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", comp="민수, 지영"), rec("%d-02-01" % Y1, "관악산", comp="민수"),
                                   rec("%d-03-01" % Y1, "도봉산", comp="철수")])
    page.click("#people summary")
    def rows():
        return page.eval_on_selector_all("#peopleList li", "els => els.map(e => e.querySelector('.nm').textContent + ' ' + e.querySelector('.ct').textContent)")
    check(rows() == ["민수 2회", "지영 1회", "철수 1회"], "전체: %s" % rows())
    page.click('#years .ychip[data-y="%d"]' % Y1)
    check(rows() == ["민수 1회", "철수 1회"], "작년: %s" % rows())
    page.fill("#q", "도봉")
    check(rows() == ["민수 1회", "철수 1회"], "검색 후 바뀌었다: %s" % rows())
    page.click('#years .ychip[data-y="%d"]' % Y)
    check(rows() == ["민수 1회", "지영 1회"], "올해: %s" % rows())
    ctx.close()


@test(27, "함께 간 사람을 적은 기록이 하나도 없으면 「함께 간 사람별 횟수」가 안 보인다")
def t27(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산"), rec("%d-02-01" % Y, "관악산", comp=" , ")])
    check(not visible(page, "#people"), "보이면 안 되는데 보인다")
    ctx.close()


@test(28, "「함께 간 사람별 횟수」의 이름을 누르면 그 사람과 함께 간 기록만 남고, 다시 누르면 전체로 돌아온다 / 요약·횟수는 그대로")
def t31(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", comp="민수, 지영"), rec("%d-02-01" % Y, "관악산", comp="민수"),
                                   rec("%d-03-01" % Y, "도봉산", comp="지영"), rec("%d-04-01" % Y, "수락산")])
    before = summary(page)
    page.click("#people summary")

    def pbtn(name):
        return page.locator('#peopleList .pbtn[data-n="%s"]' % name)

    def counts():
        return page.eval_on_selector_all("#peopleList li", "els => els.map(e => e.querySelector('.nm').textContent + ' ' + e.querySelector('.ct').textContent)")

    def pressed(name):
        return page.get_attribute('#peopleList .pbtn[data-n="%s"]' % name, "aria-pressed")

    check(pbtn("민수").count() == 1, "사람 이름을 누를 수 있는 칸이 없다")
    pbtn("민수").click()
    check(sorted(mountains(page)) == ["관악산", "북한산"], "민수와 함께 간 기록만 남아야 하는데 %s" % mountains(page))
    check(summary(page) == before, "요약 숫자가 바뀌었다")
    check(counts() == ["민수 2회", "지영 2회"], "사람별 횟수가 바뀌었다: %s" % counts())
    check("민수" in page.text_content("#qInfo"), "안내 문구에 사람 이름이 없다: %r" % page.text_content("#qInfo"))
    check(pressed("민수") == "true", "고른 이름이 눌린 상태로 표시되지 않았다")
    pbtn("민수").click()
    check(len(cards(page)) == 4, "다시 눌렀는데 전체로 돌아오지 않았다: %s" % mountains(page))
    check(pressed("민수") == "false", "다시 누른 이름이 눌린 상태로 남아 있다")
    ctx.close()


@test(29, "함께 간 사람으로 거른 채 그 사람이 없는 새 기록을 저장하면 사람 거르기만 풀리고 방금 기록이 목록에 보인다")
def t29(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", comp="민수, 지영"), rec("%d-02-01" % Y, "관악산", comp="민수"),
                                   rec("%d-03-01" % Y, "도봉산", comp="지영"), rec("%d-04-01" % Y, "수락산")])
    before = summary(page)
    page.click("#people summary")

    def pbtn(name):
        return page.locator('#peopleList .pbtn[data-n="%s"]' % name)

    def pressed(name):
        return page.get_attribute('#peopleList .pbtn[data-n="%s"]' % name, "aria-pressed")

    # 지영으로 거른 뒤 산 이름 검색과 함께 쓰기
    pbtn("지영").click()
    check(sorted(mountains(page)) == ["도봉산", "북한산"], "지영과 함께 간 기록만 남아야 하는데 %s" % mountains(page))
    page.fill("#q", "북한")
    check(mountains(page) == ["북한산"], "지영 + 북한 검색 결과가 %s" % mountains(page))
    check(summary(page) == before, "검색·사람 필터 중 요약 숫자가 바뀌었다")
    # 지영이 든 적 없는 새 기록을 저장하면 사람 필터가 풀리고, 검색은 맞지 않으니 풀린다
    add_via_ui(page, mountain="수락산")
    check(pressed("지영") == "false", "가리던 사람 필터가 풀리지 않았다")
    check(page.input_value("#q") == "", "가리던 검색어가 풀리지 않았다")
    check("수락산" in mountains(page) and len(cards(page)) == 5, "방금 저장한 기록이 목록에 없다: %s" % mountains(page))
    ctx.close()


@test(32, "코스 후보: 고른 산의 코스만, 최근 코스가 위, 같은 코스는 한 번 / 고르면 칸에 채워진 채 저장된다")
def t28(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", "A코스"), rec("%d-03-01" % Y, "북한산", "B코스"),
                                   rec("%d-02-01" % Y, "북한산", "A코스"), rec("%d-05-01" % Y, "관악산", "C코스")])
    page.click("#addBtn")
    wait_form(page)
    check(page.get_attribute("#fCourse", "list") == "courseList", "코스 칸이 후보 목록과 연결되어 있지 않다")
    page.fill("#fMountain", "북한산")
    page.click("#fCourse")
    opts = options(page, "courseList")
    check(opts == ["B코스", "A코스"], "후보가 %s (기대: B코스, A코스)" % opts)
    fill_form(page, course=opts[0], h=1, m=0, rating=3)
    page.click("#saveBtn")
    wait_home(page)
    check(cards(page)[0]["course"] == "B코스", "후보 값으로 저장되지 않았다")
    ctx.close()


@test(33, "산 이름을 바꾸면 코스 후보도 바뀌고, 빈 칸·처음 가는 산이면 후보가 없다 / 처음 가는 코스도 저장된다")
def t29(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", "A코스"), rec("%d-05-01" % Y, "관악산", "C코스")])
    page.click("#addBtn")
    wait_form(page)
    check(options(page, "courseList") == [], "산 이름이 비었는데 후보가 있다")
    page.fill("#fMountain", "북한산")
    check(options(page, "courseList") == ["A코스"], "북한산: %s" % options(page, "courseList"))
    page.fill("#fMountain", "관악산")
    check(options(page, "courseList") == ["C코스"], "관악산으로 바꾼 뒤: %s" % options(page, "courseList"))
    page.fill("#fMountain", "처음가본산")
    check(options(page, "courseList") == [], "처음 가는 산인데 후보가 %s" % options(page, "courseList"))
    page.fill("#fMountain", "")
    check(options(page, "courseList") == [], "비웠는데 후보가 %s" % options(page, "courseList"))
    fill_form(page, mountain="북한산", course="처음 가는 코스", h=2, m=10, rating=4)
    page.click("#saveBtn")
    wait_home(page)
    check(cards(page)[0]["course"] == "처음 가는 코스", "처음 가는 코스가 저장되지 않았다")
    ctx.close()


@test(34, "검색 칸에 \"백운대\"를 치면 코스에 백운대가 들어간 기록도 나온다 / 요약은 그대로")
def t30(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", "우이동 → 백운대 → 우이동"),
                                   rec("%d-02-01" % Y, "도봉산", "도봉탐방센터 → 신선대"),
                                   rec("%d-03-01" % Y1, "삼각산", "백운대탐방지원센터 → 백운대"),
                                   rec("%d-04-01" % Y, "관악산", "사당 → 연주대")])
    before = summary(page)
    page.fill("#q", "백운대")
    got = [c["mountain"] for c in cards(page)]
    check(sorted(got) == ["북한산", "삼각산"], "코스로 걸러진 목록이 %s (기대: 북한산, 삼각산)" % got)
    check(page.text_content("#qInfo") == "「백운대」 검색 결과 2건", "안내가 %r" % page.text_content("#qInfo"))
    check(summary(page) == before, "요약 숫자가 바뀌었다")
    page.fill("#q", "백 운대")
    check(len(cards(page)) == 2, "띄어쓰기를 넣으면 코스 검색이 안 된다: %s" % mountains(page))
    page.fill("#q", "북한")
    check(mountains(page) == ["북한산"], "산 이름 검색이 그대로 되지 않는다: %s" % mountains(page))
    # 코스에 검색어가 들어간 새 기록을 저장하면 검색어가 그대로 남는다
    page.fill("#q", "백운대")
    add_via_ui(page, mountain="인수봉", course="백운대 우회")
    check(page.input_value("#q") == "백운대", "코스가 맞는데 검색어가 지워졌다")
    check(mountains(page)[0] == "인수봉", "방금 저장한 기록이 맨 위에 없다: %s" % mountains(page))
    ctx.close()


@test(30, "함께 간 사람을 고른 채 연도를 바꿔도 이름은 그대로이고, 그해 그 사람과 함께 간 기록이 없으면 안내가 뜨며, 「전체」로 돌아오면 다시 보인다")
def t30(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", comp="민수"), rec("%d-02-01" % Y1, "관악산", comp="지영")])
    page.click("#people summary")
    page.locator('#peopleList .pbtn[data-n="민수"]').click()
    check(mountains(page) == ["북한산"], "민수 거르기 결과가 %s" % mountains(page))
    # 작년에는 민수와 함께 간 기록이 없다
    page.click('#years .ychip[data-y="%d"]' % Y1)
    check(cards(page) == [],"고른 이름이 풀리고 작년 기록이 전부 보인다: %s" % mountains(page))
    check("「민수」와 함께 간 기록 0건" in page.text_content("#qInfo"), "안내 문구가 %r" % page.text_content("#qInfo"))
    check("「민수」와 함께 간 기록이 없어요" in page.text_content("#list"), "목록 안내가 %r" % page.text_content("#list"))
    # 「전체」로 돌아오면 민수 거르기가 그대로 살아 있다
    page.click('#years .ychip[data-y=""]')
    check(mountains(page) == ["북한산"], "전체로 돌아와도 민수 거르기가 안 돌아온다: %s" % mountains(page))
    check(page.get_attribute('#peopleList .pbtn[data-n="민수"]', "aria-pressed") == "true", "전체에서 민수가 눌린 상태가 아니다")
    ctx.close()


@test(31, "함께 간 사람 이름에 받침이 있으면 「지훈」과, 없으면 「민수」와로 안내 문구의 조사가 맞게 나온다")
def t31(browser):
    ctx, page = open_app(browser, [rec("%d-01-01" % Y, "북한산", comp="지훈, 민수"), rec("%d-02-01" % Y, "관악산", comp="민수"),
                                   rec("%d-03-01" % Y1, "설악산", comp="민수")])
    page.click("#people summary")
    page.locator('#peopleList .pbtn[data-n="지훈"]').click()
    check(page.text_content("#qInfo") == "「지훈」과 함께 간 기록 1건", "받침 있는 이름 안내가 %r" % page.text_content("#qInfo"))
    page.click('#years .ychip[data-y="%d"]' % Y1)
    check("「지훈」과 함께 간 기록이 없어요" in page.text_content("#list"), "받침 있는 이름의 빈 안내가 %r" % page.text_content("#list"))
    page.click('#years .ychip[data-y=""]')
    page.locator('#peopleList .pbtn[data-n="지훈"]').click()
    page.locator('#peopleList .pbtn[data-n="민수"]').click()
    check(page.text_content("#qInfo") == "「민수」와 함께 간 기록 3건", "받침 없는 이름 안내가 %r" % page.text_content("#qInfo"))
    ctx.close()


MANUAL = [
    (1,"실제 휴대폰 화면에서 글씨·버튼 크기가 보기 좋고 잘림이 없는지 (자동 테스트는 375px 폭에서 넘침만 확인)"),
    (3, "필수 항목을 채우고 「저장」까지 1분 안에 끝나는지 (사람이 서서 한 손으로 해 봐야 함)"),
    (12, "실제 휴대폰 브라우저 앱을 완전히 종료했다가 다시 열어도 기록이 남는지"),
    (13, "휴대폰에서 내보낸 파일이 실제로 어디(다운로드 폴더 등)에 저장되는지"),
    (14, "다른 휴대폰(실제 다른 기기)으로 파일을 옮겨 불러오기가 되는지"),
    (16, "산 이름 칸을 누르거나 첫 글자를 쳤을 때 휴대폰 키보드 위에 후보가 뜨고, 눌러서 채워지는지 (후보 목록 내용은 자동 확인, 뜨는 모양은 브라우저마다 달라 사람이 봐야 함)"),
    (32, "코스 칸을 눌렀을 때 후보가 실제로 뜨고 눌러서 채워지는지 (위와 같은 이유)"),
]


def main():
    only = set(int(a) for a in sys.argv[1:] if a.isdigit())
    results = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for no, title, fn in TESTS:
            if only and no not in only:
                continue
            try:
                if fn.__code__.co_argcount == 2:
                    fn(browser, pw)
                else:
                    fn(browser)
                results.append((no, title, None))
                print("  통과  [%2d] %s" % (no, title))
            except Fail as e:
                results.append((no, title, str(e)))
                print("  실패  [%2d] %s\n         → %s" % (no, title, e))
            except Exception as e:
                results.append((no, title, repr(e)))
                print("  오류  [%2d] %s\n         → %s" % (no, title, e))
                traceback.print_exc(limit=2)
        browser.close()

    bad = [r for r in results if r[2]]
    print()
    print("결과: %d개 중 %d개 통과, %d개 실패" % (len(results), len(results) - len(bad), len(bad)))
    if not only:
        print()
        print("사람이 직접 확인해야 하는 항목 (자동 테스트 안 함):")
        for no, text in MANUAL:
            print("  - [%2d] %s" % (no, text))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
