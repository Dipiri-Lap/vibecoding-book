'use strict';
// 난이도 표: 화면 없이 봇으로 N판씩 돌려 살아남은 시간의 분포를 표로 보여 준다.
// 사용: node tools/difficulty-table.js [판수=100]
const { loadEngine } = require('./load-engine');

const MAX_TIME = 180;      // 3분
const BUCKETS = [30, 60, 90, 120, 150, 180];

function percentile(sorted, q) {
  if (!sorted.length) return 0;
  const idx = Math.min(sorted.length - 1, Math.floor(q * (sorted.length - 1) + 0.5));
  return sorted[idx];
}

function summarize(results) {
  const n = results.length;
  const times = results.map(r => r.time).sort((a, b) => a - b);
  const buckets = new Array(BUCKETS.length + 1).fill(0);
  let survived = 0, diedBefore120 = 0, lv3in60 = 0, sum = 0;
  for (const r of results) {
    sum += r.time;
    if (r.survived) survived++;
    else if (r.time < 120) diedBefore120++;
    if (r.levelUpsIn60 >= 3) lv3in60++;
    if (r.survived) buckets[BUCKETS.length]++;           // 마지막 칸 = 3분 버팀
    else {
      for (let i = 0; i < BUCKETS.length; i++) {
        if (r.time < BUCKETS[i]) { buckets[i]++; break; }
      }
    }
  }
  return {
    n, survived, diedBefore120, lv3in60,
    survivedRate: survived / n, diedBefore120Rate: diedBefore120 / n, lv3in60Rate: lv3in60 / n,
    min: times[0], p25: percentile(times, 0.25), median: percentile(times, 0.5),
    p75: percentile(times, 0.75), max: times[n - 1], mean: sum / n, buckets
  };
}

function pct(x) { return (x * 100).toFixed(0) + '%'; }
function sec(x) { return x.toFixed(1); }

function bucketLabels() {
  const labels = [];
  let lo = 0;
  for (let i = 0; i < BUCKETS.length; i++) { labels.push(lo + '~' + BUCKETS[i] + '초'); lo = BUCKETS[i]; }
  labels.push('3분 버팀');
  return labels;
}

function formatBot(title, s) {
  const lines = [];
  lines.push('■ ' + title + ' (' + s.n + '판)');
  lines.push('  살아남은 시간(초)  최소 ' + sec(s.min) + ' | 25% ' + sec(s.p25) + ' | 중앙값 ' + sec(s.median) +
    ' | 75% ' + sec(s.p75) + ' | 최대 ' + sec(s.max) + ' | 평균 ' + sec(s.mean));
  const labels = bucketLabels();
  s.buckets.forEach((c, i) => {
    lines.push('  ' + labels[i].padEnd(9, ' ') + String(c).padStart(4, ' ') + '판  ' + '#'.repeat(Math.round(c / s.n * 40)));
  });
  lines.push('  2분 안에 쓰러진 판: ' + pct(s.diedBefore120Rate) + '   3분 버틴 판: ' + pct(s.survivedRate) +
    '   첫 1분에 레벨업 3번 이상: ' + pct(s.lv3in60Rate));
  return lines.join('\n');
}

const BOSS_CAP = 360;      // 보스전은 3분 + 3분까지만 지켜본다 (그래도 안 끝나면 '시간 초과')

// 3분을 버틴 판이 보스와 싸우면 어떻게 되는지: 이김 / 보스에게 짐 / 시간 초과
function summarizeBoss(E, kind, games) {
  let reached = 0, won = 0, lost = 0, timeout = 0;
  const winTimes = [];
  for (let seed = 1; seed <= games; seed++) {
    const r = E.runBotGame(kind, seed, BOSS_CAP);
    if (!r.bossSpawned) continue;                 // 3분 전에 쓰러짐
    reached++;
    if (r.won) { won++; winTimes.push(r.time - 180); }
    else if (r.survived) timeout++;
    else lost++;
  }
  winTimes.sort((a, b) => a - b);
  return { reached, won, lost, timeout, winRate: reached ? won / reached : 0, medianWinSec: percentile(winTimes, 0.5) };
}

function formatBoss(title, b) {
  return '  ' + title + ': 보스까지 간 판 ' + b.reached + '판 중 이김 ' + b.won + ' / 보스에게 짐 ' + b.lost +
    ' / 시간 초과 ' + b.timeout + '  (이긴 비율 ' + pct(b.winRate) + (b.won ? ', 보스 잡는 데 중앙값 ' + sec(b.medianWinSec) + '초' : '') + ')';
}

function buildTable(E, games) {
  games = games || 100;
  const out = {};
  for (const kind of ['novice', 'expert']) {
    const results = [];
    for (let seed = 1; seed <= games; seed++) results.push(E.runBotGame(kind, seed, MAX_TIME));
    out[kind] = summarize(results);
    out[kind].boss = summarizeBoss(E, kind, games);
  }
  const checks = [
    { name: '① 초보 봇의 절반은 2분 안에 쓰러진다', ok: out.novice.diedBefore120Rate >= 0.5, value: pct(out.novice.diedBefore120Rate) },
    { name: '② 숙련 봇의 절반 이상은 3분을 버틴다', ok: out.expert.survivedRate >= 0.5, value: pct(out.expert.survivedRate) },
    { name: '③ 첫 1분 안에 레벨업 3번 이상 (숙련 봇 기준)', ok: out.expert.lv3in60Rate >= 0.5, value: pct(out.expert.lv3in60Rate) }
  ];
  const text = [
    '===== 난이도 표 (봇 ' + games + '판씩, 판마다 seed 1~' + games + ') =====',
    formatBot('초보 봇', out.novice),
    '',
    formatBot('숙련 봇', out.expert),
    '',
    '----- 보스전 (3분 버틴 판만, 보스 등장 후 최대 ' + (BOSS_CAP - 180) + '초) -----',
    formatBoss('초보 봇', out.novice.boss),
    formatBoss('숙련 봇', out.expert.boss),
    '',
    '----- 재미의 기준 확인 -----',
    ...checks.map(c => '  ' + (c.ok ? '통과' : '미달') + '  ' + c.name + '  → ' + c.value)
  ].join('\n');
  return { text, stats: out, checks };
}

module.exports = { buildTable, summarize };

if (require.main === module) {
  const n = Number(process.argv[2]) || 100;
  console.log(buildTable(loadEngine(), n).text);
}
