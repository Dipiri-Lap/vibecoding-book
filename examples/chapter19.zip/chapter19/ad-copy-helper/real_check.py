"""실제 API 를 딱 1번만 부르는 확인용 스크립트 (재시도 없음). 키는 출력하지 않는다."""
import app

cfg = app.load_config()
key = app.load_api_key()
if not key:
    raise SystemExit("API 키가 없어요.")
usage = app.UsageStore(app.BASE_DIR / "usage.json")
inputs = {"name": "가벼운 보온 물병", "features": "무게 250g, 12시간 보온, 등산 가방 옆주머니에 쏙", "audience": "주말 등산객"}
try:
    res = app.generate(inputs, cfg, app.make_claude_caller(key, cfg), usage, max_retries=0, api_key=key)
except app.AppError as e:
    raise SystemExit(app.redact(e.message, key))
for i, c in enumerate(res["candidates"], 1):
    print(f"{i}. [{c['title_len']}/{cfg['title_max']}자{' 초과' if c['title_over'] else ''}] {c['title']}")
    print(f"   [{c['desc_len']}/{cfg['desc_max']}자{' 초과' if c['desc_over'] else ''}] {c['description']}")
print("토큰:", res["tokens"], "| 오늘:", res["today"])
print("글자 수 초과:", res["violations"], "개 | 비용:", res["cost"])
