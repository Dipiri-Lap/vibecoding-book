"""광고 문구 도우미 - 내 PC 전용 로컬 서버 (파이썬 기본 기능만 사용, 추가 설치 없음).

API 키는 이 파일(서버) 안에서만 쓰이고 브라우저로는 절대 나가지 않는다.
"""
import json
import os
import re
import sys
import threading
import urllib.error
import urllib.request
import webbrowser
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
API_URL = "https://api.anthropic.com/v1/messages"
API_VERSION = "2023-06-01"

# 입력 길이 제한 (비용·남용 방지)
MAX_NAME, MAX_FEATURES, MAX_AUDIENCE = 100, 500, 200
MAX_BODY_BYTES = 8 * 1024


class AppError(Exception):
    """화면에 그대로 보여 줘도 안전한 한국어 메시지를 가진 오류."""

    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


# ---------------------------------------------------------------- 설정/키
def load_config(path=None):
    path = Path(path) if path else BASE_DIR / "config.json"
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def load_api_key(env_path=None):
    """.env 에서 ANTHROPIC_API_KEY 를 읽는다. 값은 어디에도 출력하지 않는다."""
    env_path = Path(env_path) if env_path else BASE_DIR / ".env"
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key and env_path.exists():
        for line in env_path.read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if line.startswith("ANTHROPIC_API_KEY="):
                key = line.split("=", 1)[1].strip().strip('"').strip("'")
                break
    return key or None


def redact(text, api_key):
    """어떤 문자열이든 키 모양/키 값이 있으면 지운다 (마지막 안전망)."""
    text = str(text)
    if api_key:
        text = text.replace(api_key, "[숨김]")
    return re.sub(r"sk-ant-[A-Za-z0-9_\-]{8,}", "[숨김]", text)


# ---------------------------------------------------------------- 하루 사용량
class UsageStore:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.Lock()

    def _load(self):
        today = date.today().isoformat()
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if data.get("date") == today:
                return data
        except (OSError, ValueError, AttributeError):
            pass
        return {"date": today, "requests": 0, "input_tokens": 0, "output_tokens": 0}

    def _save(self, data):
        self.path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    def snapshot(self):
        with self.lock:
            return self._load()

    def reserve(self, limit):
        """요청 1회를 미리 센다. 한도를 넘으면 False."""
        with self.lock:
            data = self._load()
            if data["requests"] >= limit:
                return False
            data["requests"] += 1
            self._save(data)
            return True

    def add_tokens(self, input_tokens, output_tokens):
        with self.lock:
            data = self._load()
            data["input_tokens"] += input_tokens
            data["output_tokens"] += output_tokens
            self._save(data)


# ---------------------------------------------------------------- Claude 호출
def make_claude_caller(api_key, cfg):
    """실제 API 를 부르는 함수. 오류 메시지에는 서버 응답 본문을 넣지 않는다."""

    def call(system, user):
        body = json.dumps(
            {
                "model": cfg["model"],
                "max_tokens": cfg["max_tokens"],
                # Haiku 5.5는 기본으로 '생각'을 켜서 출력 한도를 다 써 버린다 -> 끄고 가볍게
                "thinking": {"type": "disabled"},
                "output_config": {"effort": "low"},
                "system": system,
                "messages": [{"role": "user", "content": user}],
            }
        ).encode("utf-8")
        req = urllib.request.Request(
            API_URL,
            data=body,
            method="POST",
            headers={
                "x-api-key": api_key,
                "anthropic-version": API_VERSION,
                "content-type": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            code = e.code
            if code in (401, 403):
                raise AppError("API 키가 올바르지 않거나 권한이 없어요. .env 파일을 확인해 주세요.", 502)
            if code == 429:
                raise AppError("Claude 쪽 요청이 너무 많아요. 잠시 후 다시 해 주세요.", 502)
            if code >= 500:
                raise AppError("Claude 서버가 지금 불안정해요. 잠시 후 다시 해 주세요.", 502)
            raise AppError(f"Claude가 요청을 받아들이지 않았어요. (오류 번호 {code})", 502)
        except (urllib.error.URLError, TimeoutError, OSError):
            raise AppError("Claude에 연결하지 못했어요. 인터넷 연결을 확인해 주세요.", 502)
        except ValueError:
            raise AppError("Claude의 응답을 읽지 못했어요.", 502)

    return call


# ---------------------------------------------------------------- 문구 만들기
SYSTEM_PROMPT = (
    "당신은 한국어 검색광고 카피라이터입니다. 사용자가 준 상품 정보로 검색광고 문구 후보 5개를 씁니다. "
    "각 후보는 제목과 설명으로 이루어집니다. 반드시 지킬 규칙: "
    "제목은 {title_max}자 이내, 설명은 {desc_max}자 이내 (공백 포함 글자 수). "
    "과장·허위 표현은 쓰지 않습니다. "
    '출력은 설명 없이 JSON 한 덩어리만: {{"candidates":[{{"title":"...","description":"..."}}, ...5개]}}'
)


def build_user_prompt(name, features, audience, feedback=None):
    text = f"상품 이름: {name}\n특징: {features}\n대상 고객: {audience}\n"
    if feedback:
        text += "\n이전 시도에서 아래 항목이 글자 수 규칙을 어겼어요. 규칙을 지켜 5개를 처음부터 다시 써 주세요.\n" + feedback
    return text


def parse_candidates(response):
    """응답에서 JSON 후보 목록을 꺼낸다. 실패하면 None."""
    try:
        text = "".join(b.get("text", "") for b in response.get("content", []) if b.get("type") == "text")
        text = text.strip()
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
        data = json.loads(text)
        items = data["candidates"]
        out = []
        for it in items:
            title, desc = str(it["title"]).strip(), str(it["description"]).strip()
            out.append({"title": title, "description": desc})
        return out or None
    except (ValueError, KeyError, TypeError, AttributeError):
        return None


def check_lengths(items, cfg):
    """프로그램이 직접 글자 수를 센다 (AI 말은 믿지 않는다)."""
    checked = []
    for it in items:
        tl, dl = len(it["title"]), len(it["description"])
        checked.append(
            {
                "title": it["title"],
                "description": it["description"],
                "title_len": tl,
                "desc_len": dl,
                "title_over": tl > cfg["title_max"],
                "desc_over": dl > cfg["desc_max"],
            }
        )
    return checked


def count_violations(checked):
    return sum(1 for c in checked if c["title_over"] or c["desc_over"])


def feedback_text(checked, cfg):
    lines = []
    for i, c in enumerate(checked, 1):
        if c["title_over"]:
            lines.append(f"- {i}번 제목 \"{c['title']}\" 은 {c['title_len']}자 (최대 {cfg['title_max']}자)")
        if c["desc_over"]:
            lines.append(f"- {i}번 설명 \"{c['description']}\" 은 {c['desc_len']}자 (최대 {cfg['desc_max']}자)")
    return "\n".join(lines)


def diagnose(response, api_key=None, limit=300):
    """파싱 실패 시 남길 진단 한 줄: 종료 이유, 블록 종류, 응답 앞부분(키는 지움)."""
    try:
        blocks = response.get("content", [])
        kinds = ",".join(str(b.get("type")) for b in blocks)
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
        head = text[:limit].replace("\n", "\\n")
        u = response.get("usage", {})
        line = (f"[진단] stop_reason={response.get('stop_reason')} 블록={kinds} "
                f"출력토큰={u.get('output_tokens')} 앞부분={head!r}")
    except Exception as e:
        line = f"[진단] 응답을 살펴보지 못했어요 ({type(e).__name__})"
    return redact(line, api_key)


def generate(inputs, cfg, call_api, usage, max_retries=None, api_key=None):
    """문구를 만든다. 길이 초과가 있으면 최대 max_retries 번 다시 받는다."""
    if max_retries is None:
        max_retries = cfg.get("max_retries", 2)
    system = SYSTEM_PROMPT.format(title_max=cfg["title_max"], desc_max=cfg["desc_max"])
    used_in = used_out = attempts = 0
    best = None
    feedback = None

    for _ in range(max_retries + 1):
        if not usage.reserve(cfg["daily_limit"]):
            if best is None:
                raise AppError(f"오늘 요청 한도({cfg['daily_limit']}회)를 다 썼어요. 내일 다시 사용해 주세요.", 429)
            break  # 이미 받은 결과가 있으면 그걸 보여 준다
        attempts += 1
        response = call_api(system, build_user_prompt(inputs["name"], inputs["features"], inputs["audience"], feedback))
        u = response.get("usage", {}) if isinstance(response, dict) else {}
        i_tok, o_tok = int(u.get("input_tokens", 0) or 0), int(u.get("output_tokens", 0) or 0)
        used_in, used_out = used_in + i_tok, used_out + o_tok
        usage.add_tokens(i_tok, o_tok)

        items = parse_candidates(response)
        if items is None:
            sys.stderr.write(diagnose(response, api_key) + "\n")
            feedback = "- 이전 응답은 JSON 형식이 아니었거나 너무 길어 잘렸어요. 더 짧게, 형식을 지켜 주세요."
            continue
        checked = check_lengths(items, cfg)
        if best is None or count_violations(checked) < count_violations(best):
            best = checked
        if count_violations(checked) == 0:
            break
        feedback = feedback_text(checked, cfg)

    if best is None:
        raise AppError("문구를 만들지 못했어요. 잠시 후 다시 해 주세요.", 502)

    snap = usage.snapshot()
    pi, po = cfg.get("price_input_per_million"), cfg.get("price_output_per_million")
    cost = None
    if isinstance(pi, (int, float)) and isinstance(po, (int, float)):
        cost = used_in * pi / 1_000_000 + used_out * po / 1_000_000
    return {
        "candidates": best,
        "violations": count_violations(best),
        "attempts": attempts,
        "tokens": {"input": used_in, "output": used_out, "total": used_in + used_out},
        "today": status_view(cfg, snap),
        "cost": cost,
        "currency": cfg.get("currency", ""),
    }


def status_view(cfg, snap):
    return {
        "requests": snap["requests"],
        "limit": cfg["daily_limit"],
        "remaining": max(0, cfg["daily_limit"] - snap["requests"]),
        "input_tokens": snap["input_tokens"],
        "output_tokens": snap["output_tokens"],
        "total_tokens": snap["input_tokens"] + snap["output_tokens"],
    }


def validate_inputs(data):
    if not isinstance(data, dict):
        raise AppError("입력 형식이 올바르지 않아요.")
    out = {}
    for key, label, limit in (
        ("name", "상품 이름", MAX_NAME),
        ("features", "특징", MAX_FEATURES),
        ("audience", "대상 고객", MAX_AUDIENCE),
    ):
        val = data.get(key)
        if not isinstance(val, str) or not val.strip():
            raise AppError(f"'{label}'을(를) 입력해 주세요.")
        val = val.strip()
        if len(val) > limit:
            raise AppError(f"'{label}'은(는) {limit}자 이내로 써 주세요.")
        out[key] = val
    return out


# ---------------------------------------------------------------- 서버
def make_handler(cfg, api_key, call_api, usage, static_dir, port):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    allowed_origins = {f"http://{h}" for h in allowed_hosts}
    index_path = Path(static_dir) / "index.html"

    class Handler(BaseHTTPRequestHandler):
        server_version = "AdCopyHelper"

        def log_message(self, fmt, *args):
            # 요청 내용(본문)은 절대 기록하지 않고, 키가 섞여도 지운다.
            sys.stderr.write(redact(f"[{self.command}] {self.path.split('?')[0]} -> {args[1] if len(args) > 1 else ''}", api_key) + "\n")

        def _send(self, status, body, ctype):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            # 다른 사이트가 이 화면을 몰래 겹쳐 띄우지 못하게 한다 (모든 응답이 이 길을 지난다)
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Content-Security-Policy", "frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(body)

        def _json(self, status, obj):
            text = redact(json.dumps(obj, ensure_ascii=False), api_key)
            self._send(status, text.encode("utf-8"), "application/json; charset=utf-8")

        def _host_ok(self):
            return self.headers.get("Host", "") in allowed_hosts

        def do_GET(self):
            if not self._host_ok():
                return self._json(403, {"error": "허용되지 않은 접근이에요."})
            path = self.path.split("?")[0]
            if path in ("/", "/index.html"):
                return self._send(200, index_path.read_bytes(), "text/html; charset=utf-8")
            if path == "/api/status":
                return self._json(
                    200,
                    {
                        "today": status_view(cfg, usage.snapshot()),
                        "title_max": cfg["title_max"],
                        "desc_max": cfg["desc_max"],
                        "max_tokens": cfg["max_tokens"],
                        "price_set": cfg.get("price_input_per_million") is not None
                        and cfg.get("price_output_per_million") is not None,
                        "key_ready": bool(api_key),
                    },
                )
            self._json(404, {"error": "찾을 수 없어요."})

        def do_POST(self):
            try:
                if not self._host_ok():
                    raise AppError("허용되지 않은 접근이에요.", 403)
                origin = self.headers.get("Origin")
                if origin is not None and origin not in allowed_origins:
                    raise AppError("허용되지 않은 접근이에요.", 403)
                if self.path.split("?")[0] != "/api/generate":
                    raise AppError("찾을 수 없어요.", 404)
                if not self.headers.get("Content-Type", "").startswith("application/json"):
                    raise AppError("요청 형식이 올바르지 않아요.", 415)
                if not api_key:
                    raise AppError("API 키가 설정되지 않았어요. .env 파일의 ANTHROPIC_API_KEY를 확인해 주세요.", 500)
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > MAX_BODY_BYTES:
                    raise AppError("요청 크기가 올바르지 않아요.", 413)
                try:
                    data = json.loads(self.rfile.read(length).decode("utf-8"))
                except ValueError:
                    raise AppError("입력 형식이 올바르지 않아요.")
                result = generate(validate_inputs(data), cfg, call_api, usage, api_key=api_key)
                self._json(200, result)
            except AppError as e:
                self._json(e.status, {"error": e.message})
            except Exception as e:  # 어떤 오류든 내용 대신 종류만 안전하게 알려 준다
                sys.stderr.write(f"[오류] {type(e).__name__}\n")
                self._json(500, {"error": "예상하지 못한 오류가 생겼어요. 다시 시도해 주세요."})

    return Handler


def create_server(cfg, api_key, call_api, usage_path, static_dir=BASE_DIR, port=None):
    port_wanted = cfg["port"] if port is None else port
    usage = UsageStore(usage_path)
    # 포트 0(테스트용)이면 먼저 열어 실제 포트를 알아낸 뒤 핸들러를 만든다
    server = ThreadingHTTPServer(("127.0.0.1", port_wanted), BaseHTTPRequestHandler)
    real_port = server.server_address[1]
    server.RequestHandlerClass = make_handler(cfg, api_key, call_api, usage, static_dir, real_port)
    return server


def main():
    cfg = load_config()
    api_key = load_api_key()
    if not api_key:
        print("[안내] API 키가 없어요. .env 파일에 ANTHROPIC_API_KEY=... 를 넣어 주세요.")
    url = f"http://127.0.0.1:{cfg['port']}/"
    try:
        server = create_server(cfg, api_key, make_claude_caller(api_key, cfg), BASE_DIR / "usage.json")
    except OSError:
        print("이미 실행 중인 것 같아요. 브라우저만 엽니다.")
        webbrowser.open(url)
        return
    print(f"광고 문구 도우미 실행 중: {url}  (끄려면 이 창을 닫으세요)")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
