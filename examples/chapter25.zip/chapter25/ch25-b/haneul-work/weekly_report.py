# -*- coding: utf-8 -*-
"""주간 광고 보고서 자동 생성

다운로드/광고데이터/{네이버,메타,구글} 폴더의 원본 파일을 읽어
보고서/주간보고_NN주.xlsx 를 만들고, 원본과 숫자가 맞는지 검산합니다.

사용법
  python weekly_report.py            # 데이터 중 가장 최근 주(월~일)로 생성
  python weekly_report.py --week 43  # 특정 주차 지정

원본 파일은 읽기만 하며 절대 수정하지 않습니다(실행 전후 해시로 확인).
"""
import argparse
import csv
import datetime as dt
import hashlib
import io
import re
import shutil
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import openpyxl

BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / "다운로드" / "광고데이터"
TEMPLATE_DIRS = [BASE / "보고서", BASE / "다운로드" / "주간보고"]
OUT_DIR = BASE / "보고서"

CHANNELS = ["네이버", "메타", "구글"]          # 보고서 행 순서
FIRST_ROW = 4                                   # 네이버 행 (A4)
TOTAL_ROW = FIRST_ROW + len(CHANNELS)           # 합계 행 (A7)
MEMO_CELL = "A9"
METRICS = ["cost", "imp", "click", "conv"]
METRIC_KO = {"cost": "비용", "imp": "노출", "click": "클릭", "conv": "전환"}

# 메타 '전환' 기준 (2026-11-10 변경): 이번 주부터 아래 캠페인의 Results만 전환으로 센다.
# (42·43·44주는 캠페인 구분 없이 Results 전체를 셌음. 비용·노출·클릭은 계속 전 캠페인 합계.)
# 제외된 캠페인의 Results 건수는 메모 끝에 밝힌다.
META_CONV_CAMPAIGNS = ["가을신상_리타겟팅"]

# 매체마다 다른 열 이름 → 공통 이름
ALIASES = {
    "date": ["일자", "일", "날짜", "Day", "Date", "Reporting starts", "보고 시작"],
    "campaign": ["캠페인", "캠페인 이름", "Campaign name", "Campaign"],
    "imp": ["노출수", "노출", "Impressions", "Impr."],
    "click": ["클릭수", "클릭", "Link clicks", "링크 클릭", "Clicks"],
    "cost": ["총비용(원)", "총비용", "비용", "Amount spent (KRW)", "지출 금액 (KRW)", "Cost"],
    "conv": ["전환수", "전환", "Results", "결과", "Conversions"],
}


# ---------------------------------------------------------------- 읽기
def norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lstrip("﻿")


def to_num(v):
    if v is None:
        return 0
    if isinstance(v, (int, float)):
        return v
    s = str(v).replace(",", "").replace("₩", "").replace("원", "").strip()
    if s in ("", "-", "--"):
        return 0
    n = float(s)
    return int(n) if n.is_integer() else n


def to_date(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    m = re.match(r"^\s*(\d{4})\s*[.\-/년]\s*(\d{1,2})\s*[.\-/월]\s*(\d{1,2})", str(v or ""))
    if not m:
        return None
    try:
        return dt.date(*map(int, m.groups()))
    except ValueError:
        return None


def read_rows(path):
    """파일을 '행 목록(list of list)'으로 읽기 (xlsx/csv 모두)."""
    if path.suffix.lower() in (".xlsx", ".xlsm"):
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.worksheets[0]
        rows = [list(r) for r in ws.iter_rows(values_only=True)]
        wb.close()
        return rows
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-16", "cp949"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError(f"인코딩을 알 수 없습니다: {path}")
    delim = "\t" if text.count("\t") > text.count(",") else ","
    return [r for r in csv.reader(io.StringIO(text), delimiter=delim)]


def parse_file(path):
    """반환: (일자별 행 목록, 파일 자체의 합계 행 or None)"""
    rows = read_rows(path)
    header_idx, colmap = None, None
    for i, r in enumerate(rows[:30]):
        cells = [norm(c) for c in r]
        m = {}
        for key, names in ALIASES.items():
            for j, c in enumerate(cells):
                if c in names and key not in m:
                    m[key] = j
        if all(k in m for k in ("date", *METRICS)):
            header_idx, colmap = i, m
            break
    if header_idx is None:
        raise ValueError(f"머리글(일자·노출·클릭·비용·전환)을 찾지 못했습니다: {path.name}")

    data, file_total = [], None
    for r in rows[header_idx + 1:]:
        if not any(norm(c) for c in r):
            continue
        get = lambda k: r[colmap[k]] if colmap[k] < len(r) else None
        d = to_date(get("date"))
        vals = {k: to_num(get(k)) for k in METRICS}
        if d is None:
            label = norm(r[0]) if r else ""
            if "합계" in label or "총계" in label or "total" in label.lower():
                file_total = vals
            continue
        camp = norm(get("campaign")) if "campaign" in colmap else ""
        data.append({"date": d, "campaign": camp, **vals})
    return data, file_total


def apply_conv_rule(ch, rows):
    """메타는 META_CONV_CAMPAIGNS 캠페인의 Results만 전환으로 센다. 나머지는 conv=0, 원래 값은 conv_raw에 보관."""
    for r in rows:
        r["conv_raw"] = r["conv"]
        if ch == "메타" and r["campaign"] not in META_CONV_CAMPAIGNS:
            r["conv"] = 0
    return rows


def channel_files(ch):
    folder = DATA_DIR / ch
    if not folder.is_dir():
        return []
    return sorted(
        [p for p in folder.iterdir()
         if p.suffix.lower() in (".xlsx", ".xlsm", ".csv", ".tsv")
         and not p.name.startswith("~$")],
        key=lambda p: p.stat().st_mtime,
    )


# ---------------------------------------------------------------- 계산
def round_half_up(x):
    return int(Decimal(str(x)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def ratio(a, b):
    return round_half_up(a / b) if b else 0


def week_range(year, week):
    mon = dt.date.fromisocalendar(year, week, 1)
    return mon, mon + dt.timedelta(days=6)


def sha256(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def find_template(week):
    """가장 최근 이전 주 보고서를 양식으로 사용 (없으면 아무 주간보고 파일)."""
    cands = []
    for d in TEMPLATE_DIRS:
        if d.is_dir():
            for p in d.glob("주간보고_*주.xlsx"):
                m = re.search(r"주간보고_(\d+)주\.xlsx$", p.name)
                if m:
                    cands.append((int(m.group(1)), p))
    prev = [c for c in cands if c[0] < week]
    pool = prev or cands
    if not pool:
        raise FileNotFoundError("양식으로 쓸 '주간보고_NN주.xlsx' 파일이 없습니다.")
    return max(pool, key=lambda c: c[0])


def read_report(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.worksheets[0]
    out = {}
    for i, name in enumerate(CHANNELS + ["합계"]):
        r = FIRST_ROW + i
        out[norm(ws.cell(r, 1).value)] = {
            "cost": ws.cell(r, 2).value, "imp": ws.cell(r, 3).value,
            "click": ws.cell(r, 4).value, "conv": ws.cell(r, 5).value,
            "cpc": ws.cell(r, 6).value, "cpa": ws.cell(r, 7).value,
        }
    wb.close()
    return out


def pct(new, old):
    if not old:
        return None
    return (new - old) / old * 100


def make_memo(cur, prev):
    t = cur["합계"]
    if not prev:
        return (f"메모: (자동 초안) 총 비용 {t['cost']:,}원, 전환 {t['conv']}건, "
                f"전환당 비용 {t['cpa']:,}원.")
    def fmt(new, old):
        p = pct(new, old)
        return "" if p is None else f"(전주 대비 {p:+.1f}%)"
    pt = prev.get("합계", {})
    parts = [
        f"총 비용 {t['cost']:,}원{fmt(t['cost'], pt.get('cost'))}",
        f"전환 {t['conv']}건{fmt(t['conv'], pt.get('conv'))}",
        f"전환당 비용 {t['cpa']:,}원{fmt(t['cpa'], pt.get('cpa'))}",
    ]
    # 전환당 비용 변화가 가장 큰 채널
    best = None
    for ch in CHANNELS:
        p = pct(cur[ch]["cpa"], (prev.get(ch) or {}).get("cpa"))
        if p is not None and (best is None or abs(p) > abs(best[1])):
            best = (ch, p)
    memo = "메모: (자동 초안) " + ", ".join(parts)
    if best:
        word = "상승" if best[1] > 0 else "하락"
        memo += f". {best[0]} 전환당 비용 {abs(best[1]):.1f}% {word}"
    return memo


# ---------------------------------------------------------------- 메인
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--week", type=int, help="ISO 주차 (생략 시 데이터 중 가장 최근 주)")
    ap.add_argument("--year", type=int, help="연도 (생략 시 자동)")
    args = ap.parse_args()

    warnings = []
    # 1) 원본 읽기 + 실행 전 해시
    files = {ch: channel_files(ch) for ch in CHANNELS}
    hashes_before = {p: sha256(p) for fs in files.values() for p in fs}
    rows_by_ch, file_totals = {}, {}
    for ch in CHANNELS:
        if not files[ch]:
            sys.exit(f"[오류] {DATA_DIR / ch} 폴더에 파일이 없습니다.")
        merged = {}   # (날짜, 캠페인) → 행   (쌓인 파일 중복 제거, 최신 파일 우선)
        for p in files[ch]:
            data, ftot = parse_file(p)
            apply_conv_rule(ch, data)
            file_totals[p] = (ch, ftot, data)
            for r in data:
                key = (r["date"], r["campaign"])
                if key in merged and any(merged[key][k] != r[k] for k in METRICS):
                    warnings.append(f"{ch}: {key[0]} '{key[1]}' 값이 파일마다 다름 → 최신 파일({p.name}) 값 사용")
                merged[key] = {**r, "file": p}
        rows_by_ch[ch] = list(merged.values())

    # 2) 대상 주 결정
    if args.week:
        year = args.year or max(r["date"] for v in rows_by_ch.values() for r in v).isocalendar()[0]
        week = args.week
    else:
        latest = min(max(r["date"] for r in v) for v in rows_by_ch.values())
        # 세 채널 모두 데이터가 있는 가장 최근 주
        year, week, _ = latest.isocalendar()
    start, end = week_range(year, week)

    agg, used_files = {}, {}
    for ch in CHANNELS:
        wk = [r for r in rows_by_ch[ch] if start <= r["date"] <= end]
        days = {r["date"] for r in wk}
        if not wk:
            sys.exit(f"[오류] {ch}: {start}~{end} 데이터가 없습니다.")
        if len(days) < 7:
            missing = [str(start + dt.timedelta(i)) for i in range(7)
                       if start + dt.timedelta(i) not in days]
            warnings.append(f"{ch}: 빠진 날짜 {', '.join(missing)}")
        agg[ch] = {k: sum(r[k] for r in wk) for k in METRICS}
        used_files[ch] = sorted({r["file"].name for r in wk})
    total = {k: sum(agg[ch][k] for ch in CHANNELS) for k in METRICS}

    report = {}
    for name, v in [*agg.items(), ("합계", total)]:
        report[name] = {**v, "cpc": ratio(v["cost"], v["click"]), "cpa": ratio(v["cost"], v["conv"])}

    # 3) 양식 복사해서 채우기 (양식 파일은 읽기만)
    tpl_week, tpl_path = find_template(week)
    if tpl_path.parent != OUT_DIR:
        hashes_before[tpl_path] = sha256(tpl_path)
    prev =read_report(tpl_path) if tpl_week == week - 1 else None
    wb = openpyxl.load_workbook(tpl_path)
    ws = wb.worksheets[0]
    ws.title = f"{week}주"
    ws["A1"] = f"주간 광고 보고서 ({week}주, {start.month}/{start.day}~{end.month}/{end.day})"
    for i, name in enumerate(CHANNELS + ["합계"]):
        r, v = FIRST_ROW + i, report[name]
        ws.cell(r, 1).value = name
        for c, k in enumerate(["cost", "imp", "click", "conv", "cpc", "cpa"], start=2):
            ws.cell(r, c).value = v[k]
    memo = make_memo(report, prev)
    meta_wk = [r for r in rows_by_ch["메타"] if start <= r["date"] <= end]
    memo += f". 메타 전환은 {', '.join(META_CONV_CAMPAIGNS)} 캠페인 Results만 집계"
    for camp in sorted({r["campaign"] for r in meta_wk} - set(META_CONV_CAMPAIGNS)):
        n = sum(r["conv_raw"] for r in meta_wk if r["campaign"] == camp)
        memo += f"({camp} {n:,}건 제외)"
    ws[MEMO_CELL] = memo

    OUT_DIR.mkdir(exist_ok=True)
    out = OUT_DIR / f"주간보고_{week}주.xlsx"
    if out.exists():
        bak = OUT_DIR / f"주간보고_{week}주_백업_{dt.datetime.now():%Y%m%d-%H%M%S}.xlsx"
        shutil.copy2(out, bak)
        print(f"기존 보고서를 백업했습니다: {bak.name}")
    wb.save(out)

    # 4) 검산: 저장한 파일을 다시 열어 원본과 비교
    saved = read_report(out)
    lines, ok_all = [], True
    def check(label, a, b):
        nonlocal ok_all
        ok = a == b
        ok_all &= ok
        return f"{'OK ' if ok else 'NG '} {label}: 보고서 {a:,} / 원본 {b:,}"

    lines.append(f"[검산] {week}주 ({start}~{end})  양식: {tpl_path.name}")
    for ch in CHANNELS:
        lines.append(f"\n■ {ch}  (사용 파일: {', '.join(used_files[ch])})")
        # (a) 원본 행 다시 합산 (집계 코드와 별도로 파일을 새로 읽음)
        fresh = {}
        for p in files[ch]:
            for r in apply_conv_rule(ch, parse_file(p)[0]):
                fresh[(r["date"], r["campaign"])] = r
        raw = {k: sum(r[k] for (d, _), r in fresh.items() if start <= d <= end) for k in METRICS}
        for k in METRICS:
            lines.append("  " + check(f"{METRIC_KO[k]}(일자별 합산)", saved[ch][k], raw[k]))
        # (b) 원본 파일에 적힌 합계/총계 행과 비교 (그 파일이 해당 주만 담은 경우)
        for p in files[ch]:
            _, ftot, data = file_totals[p]
            if ftot and data and all(start <= r["date"] <= end for r in data) \
                    and {r["date"] for r in data} == {start + dt.timedelta(i) for i in range(7)}:
                for k in METRICS:
                    if ch == "메타" and k == "conv":
                        continue  # 합계 행은 전 캠페인 합이라 캠페인 필터를 건 전환과 비교 불가
                    lines.append("  " + check(f"{METRIC_KO[k]}(원본 '합계/총계' 행, {p.name})",
                                              saved[ch][k], ftot[k]))
        if not any(file_totals[p][1] for p in files[ch]):
            lines.append("  (원본에 합계 행 없음 → 일자별 합산으로만 검산)")
        lines.append("  " + check("CPC", saved[ch]["cpc"], ratio(saved[ch]["cost"], saved[ch]["click"])))
        lines.append("  " + check("전환당 비용", saved[ch]["cpa"], ratio(saved[ch]["cost"], saved[ch]["conv"])))

    lines.append("\n■ 합계 행")
    for k in METRICS:
        lines.append("  " + check(f"{METRIC_KO[k]}(세 채널 합)", saved["합계"][k],
                                  sum(saved[ch][k] for ch in CHANNELS)))
    lines.append("  " + check("CPC", saved["합계"]["cpc"], ratio(saved["합계"]["cost"], saved["합계"]["click"])))
    lines.append("  " + check("전환당 비용", saved["합계"]["cpa"], ratio(saved["합계"]["cost"], saved["합계"]["conv"])))

    # 5) 원본 미수정 확인
    changed = [p.name for p, h in hashes_before.items() if sha256(p) != h]
    tpl_note = ""
    if changed:
        ok_all = False
        lines.append(f"\nNG  원본 파일이 바뀌었습니다: {changed}")
    else:
        lines.append(f"\nOK  원본 파일 {len(hashes_before)}개 실행 전후 동일(해시 비교){tpl_note} — 수정 없음")

    if warnings:
        lines.append("\n[주의]")
        lines += ["  - " + w for w in warnings]
    lines.append(f"\n결과: {'모두 일치' if ok_all else '불일치 있음 — 확인 필요'}")
    lines.append(f"저장: {out}")

    text = "\n".join(lines)
    (OUT_DIR / f"검산_{week}주.txt").write_text(text, encoding="utf-8")
    print(text)
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
