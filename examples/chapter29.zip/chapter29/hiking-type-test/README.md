# 나의 주말 등산 유형 테스트

질문 8개, 결과 4가지로 된 심리테스트입니다. 서버 없이 정적 파일만으로 돌아갑니다.

## 폴더 구성
| 폴더 | 내용 | 업로드 |
|---|---|---|
| `site/` | 실제 사이트 (HTML·CSS·JS·이미지, `_headers`) | ✅ **이 폴더만** 올립니다 |
| `tools/` | 결과 페이지·미리보기 이미지를 만드는 도구, 로컬 서버 | ❌ |
| `tests/` | 자동 점검 | ❌ |

## Netlify Drop에 올리기
1. https://app.netlify.com/drop 에 접속해 로그인합니다.
2. **`site` 폴더**를 통째로 끌어다 놓습니다.
3. Site configuration → Change site name에서 이름을 **`hiking-type-test`** 로 바꿉니다.
   - 미리보기 이미지 주소가 `https://hiking-type-test.netlify.app`로 들어가 있어서 이름이 꼭 같아야 합니다.
   - 이미 다른 사람이 쓰는 이름이라면 `site/js/data.js`의 `SITE_URL`과 `site/index.html`의 주소 4곳을 고친 뒤 아래 "문구 수정" 순서대로 다시 만드세요.
4. 업데이트할 때는 사이트의 Deploys 탭에 `site` 폴더를 다시 끌어다 놓습니다.

## 카카오톡 미리보기 확인
- 결과 링크 예: `https://hiking-type-test.netlify.app/result/peak.html` (peak / trail / food / photo)
- 카카오톡은 미리보기를 한동안 저장해 둡니다. 문구나 이미지를 바꾼 뒤에도 예전 미리보기가 나오면,
  [카카오 공유 디버거](https://developers.kakao.com/tool/debugger/sharing)에서 주소를 넣고 캐시를 초기화하세요 (카카오 계정 로그인 필요).

## 문구 수정
1. `site/js/data.js`를 고칩니다. 질문과 결과 문구가 모두 이 파일에 있습니다.
2. 아래 명령을 차례로 실행합니다.
   ```
   node tools/build.mjs      # 결과 페이지 4개 다시 만들기
   node tools/make-og.mjs    # 미리보기 PNG 5장 다시 만들기 (Edge/Chrome 필요)
   node tests/check.mjs      # 자동 점검
   ```
3. 내 컴퓨터에서 확인: `node tools/serve.mjs` → http://localhost:8080

## 개인정보·보안
- 입력칸이 없어서 이름·연락처를 받지 않습니다. 답변은 브라우저 메모리에만 있다가 결과 페이지로 넘어가면 사라집니다.
- 외부 스크립트, 폰트, 분석·광고 코드가 없습니다.
- `site/_headers`의 보안 정책(CSP)은 외부 스크립트 실행과 외부 전송을 막습니다.
