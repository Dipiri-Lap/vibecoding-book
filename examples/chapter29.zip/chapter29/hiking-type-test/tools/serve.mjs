// 로컬 미리보기 서버 (site/_headers 의 보안 헤더도 Netlify처럼 적용)
// 사용법: node tools/serve.mjs  →  http://localhost:8080
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const site = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "site");
const port = Number(process.env.PORT) || 8080;
const types = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".svg": "image/svg+xml", ".png": "image/png" };

const headers = {};
for (const line of fs.readFileSync(path.join(site, "_headers"), "utf8").split(/\r?\n/)) {
  const m = line.match(/^\s+([\w-]+):\s*(.+)$/);
  if (m) headers[m[1]] = m[2];
}

http
  .createServer((req, res) => {
    let p = decodeURIComponent(new URL(req.url, "http://x").pathname);
    if (p.endsWith("/")) p += "index.html";
    let file = path.join(site, p);
    if (!file.startsWith(site)) file = "";
    let status = 200;
    if (!file || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      if (file && fs.existsSync(file + ".html")) file += ".html";
      else { file = path.join(site, "404.html"); status = 404; }
    }
    res.writeHead(status, { ...headers, "Content-Type": types[path.extname(file)] || "application/octet-stream" });
    fs.createReadStream(file).pipe(res);
  })
  .listen(port, () => console.log(`http://localhost:${port}`));
