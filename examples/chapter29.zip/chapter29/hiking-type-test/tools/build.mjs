// 결과 페이지 4개(site/result/*.html)를 site/js/data.js 내용으로 만들어 줍니다.
// 사용법: node tools/build.mjs
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const site = path.join(root, "site");

export function loadData() {
  const ctx = {};
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(site, "js", "data.js"), "utf8"), ctx);
  return ctx.HIKING;
}

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

export function resultPage(H, id) {
  const t = H.TYPES[id];
  const mate = H.TYPES[t.mate];
  const url = `${H.SITE_URL}/result/${id}.html`;
  const ogTitle = `나는 '${t.name}' ${t.emoji} | ${H.TITLE}`;
  return `<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(t.name)} | ${esc(H.TITLE)}</title>
<meta name="description" content="${esc(t.oneLiner)}">
<meta name="theme-color" content="#f6f1e7">
<link rel="canonical" href="${url}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="${esc(H.TITLE)}">
<meta property="og:locale" content="ko_KR">
<meta property="og:url" content="${url}">
<meta property="og:title" content="${esc(ogTitle)}">
<meta property="og:description" content="${esc(t.oneLiner)}">
<meta property="og:image" content="${H.SITE_URL}/img/og-${id}.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="${esc(t.name)} 유형 일러스트">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="../img/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../css/style.css">
</head>
<body class="type-${id}" data-type="${id}">
<main class="app">
  <section class="screen">
    <div class="result-head">
      <a class="site-name" href="../index.html">${esc(H.TITLE)}</a>
      <p id="kicker" class="kicker">친구의 주말 등산 유형은</p>
      <img class="result-art" src="../img/${id}.svg" width="400" height="300" alt="${esc(t.name)} 일러스트">
      <h1 class="result-name">${esc(t.name)} ${t.emoji}</h1>
      <p class="one-liner">${esc(t.oneLiner)}</p>
    </div>

    <div class="card">
      <p>${esc(t.description)}</p>
      <ul class="tags">
${t.tags.map((g) => `        <li>${esc(g)}</li>`).join("\n")}
      </ul>
    </div>

    <div class="card">
      <h2>오늘의 한마디</h2>
      <p>${esc(t.tip)}</p>
    </div>

    <div class="card mate">
      <h2>잘 맞는 등산 메이트</h2>
      <a href="${t.mate}.html">
        <img src="../img/${t.mate}.svg" width="64" height="48" alt="">
        <span><strong>${esc(mate.name)} ${mate.emoji}</strong><small>${esc(t.mateReason)}</small></span>
      </a>
    </div>

    <div class="result-actions">
      <button id="share" class="btn primary" type="button" hidden>친구에게 공유하기</button>
      <button id="copy" class="btn primary" type="button">링크 복사</button>
      <a id="restart" class="btn ghost" href="../index.html">나도 테스트하기</a>
      <p id="manual" class="manual" hidden>복사가 안 되면 아래 주소를 길게 눌러 복사하세요<span></span></p>
    </div>
  </section>
</main>
<p id="toast" class="toast" role="status" aria-live="polite"></p>
<script src="../js/data.js"></script>
<script src="../js/result.js"></script>
</body>
</html>
`;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const H = loadData();
  fs.mkdirSync(path.join(site, "result"), { recursive: true });
  for (const id of Object.keys(H.TYPES)) {
    fs.writeFileSync(path.join(site, "result", `${id}.html`), resultPage(H, id));
    console.log(`site/result/${id}.html 생성`);
  }
}
