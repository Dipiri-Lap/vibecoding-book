// 카카오톡 미리보기용 PNG(1200x630) 5장을 만듭니다. (Edge/Chrome 헤드리스 사용)
// 사용법: node tools/make-og.mjs
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const candidates = [
  "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
  "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
  "C:/Program Files/Google/Chrome/Application/chrome.exe"
];
const browser = candidates.find((p) => fs.existsSync(p));
if (!browser) throw new Error("Edge 또는 Chrome을 찾지 못했어요");

const template = pathToFileURL(path.join(root, "tools", "og-template.html")).href;
const profile = fs.mkdtempSync(path.join(process.env.TEMP || root, "og-profile-"));

for (const id of ["main", "peak", "trail", "food", "photo"]) {
  const out = path.join(root, "site", "img", `og-${id}.png`);
  execFileSync(browser, [
    "--headless=new",
    "--disable-gpu",
    "--hide-scrollbars",
    "--force-device-scale-factor=1",
    `--user-data-dir=${profile}`,
    "--allow-file-access-from-files",
    "--virtual-time-budget=2000",
    "--window-size=1200,630",
    `--screenshot=${out}`,
    `${template}?type=${id}`
  ], { stdio: "ignore" });
  const buf = fs.readFileSync(out);
  console.log(`og-${id}.png  ${buf.readUInt32BE(16)}x${buf.readUInt32BE(20)}  ${Math.round(buf.length / 1024)}KB`);
}
fs.rmSync(profile, { recursive: true, force: true });
