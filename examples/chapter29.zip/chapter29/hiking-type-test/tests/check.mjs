// 자동 점검: node tests/check.mjs
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadData, resultPage } from "../tools/build.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const site = path.join(root, "site");
let failed = 0;
let passed = 0;
function check(name, cond, detail = "") {
  if (cond) passed++;
  else {
    failed++;
    console.log(`✗ ${name}${detail ? "  — " + detail : ""}`);
  }
}

const H = loadData();
const ids = Object.keys(H.TYPES);

// ---------- 1. 데이터 ----------
check("결과 유형은 4개", ids.length === 4, ids.join(","));
check("질문은 8개", H.QUESTIONS.length === 8);
H.QUESTIONS.forEach((q, i) => {
  check(`Q${i + 1} 보기 4개`, q.options.length === 4);
  const types = q.options.map((o) => o.type).sort().join();
  check(`Q${i + 1} 보기가 4유형에 하나씩`, types === [...ids].sort().join(), types);
  q.options.forEach((o) => check(`Q${i + 1} 보기 문구 있음`, o.text.trim().length > 0));
});
ids.forEach((id) => {
  const t = H.TYPES[id];
  for (const k of ["name", "emoji", "oneLiner", "description", "tip", "mateReason"]) {
    check(`${id}.${k} 있음`, typeof t[k] === "string" && t[k].length > 0);
  }
  check(`${id} 메이트가 다른 유효 유형`, ids.includes(t.mate) && t.mate !== id);
});

// ---------- 2. 결과 계산 ----------
ids.forEach((id) => {
  check(`모두 ${id} 선택 → ${id}`, H.computeResult(Array(8).fill(id)) === id);
});
check("최다 득표 유형", H.computeResult(["peak", "food", "food", "trail", "food", "photo", "peak", "trail"]) === "food");
check("동점 → 마지막에 고른 유형", H.computeResult(["peak", "peak", "trail", "trail", "food", "photo", "peak", "trail"]) === "trail");
check("4유형 2:2:2:2 동점 → 마지막 답", H.computeResult(["peak", "trail", "food", "photo", "photo", "food", "trail", "peak"]) === "peak");
// 가능한 모든 답 조합(4^8 = 65,536)에서 결과가 항상 4유형 중 하나인지, 분포가 고른지
const dist = Object.fromEntries(ids.map((id) => [id, 0]));
for (let n = 0; n < 4 ** 8; n++) {
  const ans = [];
  let x = n;
  for (let i = 0; i < 8; i++) {
    ans.push(ids[x % 4]);
    x = Math.floor(x / 4);
  }
  const r = H.computeResult(ans);
  if (!(r in dist)) {
    check("모든 조합 결과 유효", false, ans.join());
    break;
  }
  dist[r]++;
}
const vals = Object.values(dist);
check("모든 답 조합에서 4유형이 고르게 나옴", Math.max(...vals) === Math.min(...vals), JSON.stringify(dist));

// ---------- 3. 페이지 · 미리보기(OG) ----------
const meta = (html, prop) => {
  const m = html.match(new RegExp(`<meta (?:property|name)="${prop}" content="([^"]*)"`));
  return m ? m[1] : null;
};
function pngSize(file) {
  const b = fs.readFileSync(file);
  const sig = b.subarray(0, 8).toString("hex") === "89504e470d0a1a0a";
  return { sig, w: b.readUInt32BE(16), h: b.readUInt32BE(20), kb: b.length / 1024 };
}

const pages = [{ file: "index.html", id: "main", url: `${H.SITE_URL}/` }].concat(
  ids.map((id) => ({ file: `result/${id}.html`, id, url: `${H.SITE_URL}/result/${id}.html` }))
);
const seenImages = new Set();
const seenTitles = new Set();
for (const p of pages) {
  const full = path.join(site, p.file);
  check(`${p.file} 존재`, fs.existsSync(full));
  if (!fs.existsSync(full)) continue;
  const html = fs.readFileSync(full, "utf8");
  const ogTitle = meta(html, "og:title");
  const ogDesc = meta(html, "og:description");
  const ogImage = meta(html, "og:image");
  const ogUrl = meta(html, "og:url");
  check(`${p.file} og:title`, !!ogTitle);
  check(`${p.file} og:description`, !!ogDesc);
  check(`${p.file} og:url 정확`, ogUrl === p.url, ogUrl);
  check(`${p.file} og:image 절대주소(https)`, ogImage === `${H.SITE_URL}/img/og-${p.id}.png`, ogImage);
  check(`${p.file} viewport 설정`, html.includes('name="viewport"'));
  check(`${p.file} lang="ko"`, html.includes('<html lang="ko">'));
  seenImages.add(ogImage);
  seenTitles.add(ogTitle);
  if (p.id !== "main") {
    const t = H.TYPES[p.id];
    check(`${p.file} 제목에 유형 이름`, ogTitle.includes(t.name));
    check(`${p.file} 설명 = 한 줄 소개`, ogDesc === t.oneLiner);
    check(`${p.file} 최신 data.js로 생성됨 (아니면 node tools/build.mjs)`, html === resultPage(H, p.id));
  } else {
    check("index og:description = 데이터 설명", ogDesc === H.MAIN_DESCRIPTION);
  }
  const img = path.join(site, "img", `og-${p.id}.png`);
  check(`og-${p.id}.png 존재`, fs.existsSync(img));
  if (fs.existsSync(img)) {
    const s = pngSize(img);
    check(`og-${p.id}.png 는 PNG`, s.sig);
    check(`og-${p.id}.png 1200x630`, s.w === 1200 && s.h === 630, `${s.w}x${s.h}`);
    check(`og-${p.id}.png 1MB 미만`, s.kb < 1024);
  }
  // 로컬 참조 파일이 실제로 있는지
  for (const m of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
    const ref = m[1];
    if (/^https?:/.test(ref)) continue;
    const target = ref.startsWith("/") ? path.join(site, ref) : path.join(path.dirname(full), ref);
    check(`${p.file} → ${ref} 파일 존재`, fs.existsSync(target.split("#")[0]));
  }
}
check("미리보기 이미지 5장 모두 다름", seenImages.size === 5);
check("미리보기 제목 5개 모두 다름", seenTitles.size === 5);

// ---------- 4. 개인정보 · 외부 코드 ----------
const allFiles = [];
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const f = path.join(dir, e.name);
    if (e.isDirectory()) walk(f);
    else allFiles.push(f);
  }
})(site);
const rel = (f) => path.relative(site, f).replace(/\\/g, "/");
const textFiles = allFiles.filter((f) => /\.(html|js|css|svg)$/.test(f) || f.endsWith("_headers"));
for (const f of textFiles) {
  const src = fs.readFileSync(f, "utf8");
  const name = rel(f);
  if (f.endsWith(".html")) {
    check(`${name}: 입력칸/폼 없음`, !/<(input|form|textarea|select)\b/i.test(src));
    check(`${name}: 인라인 스크립트 없음(CSP)`, !/<script(?![^>]*\bsrc=)[^>]*>/i.test(src));
    check(`${name}: style 속성 없음(CSP)`, !/\sstyle="/i.test(src));
    check(`${name}: iframe 없음`, !/<iframe/i.test(src));
    for (const m of src.matchAll(/<(script|link|img)\b[^>]*(?:src|href)="(https?:[^"]+)"/gi)) {
      if (m[1].toLowerCase() === "link" && /rel="canonical"/.test(m[0])) continue;
      check(`${name}: 외부 리소스 로딩 없음`, false, m[2]);
    }
  }
  if (f.endsWith(".css")) {
    check(`${name}: 외부 CSS/폰트 없음`, !/@import|url\(\s*["']?https?:/i.test(src));
  }
  if (f.endsWith(".js")) {
    check(`${name}: 저장·전송 코드 없음`, !/localStorage|sessionStorage|document\.cookie|indexedDB|fetch\(|XMLHttpRequest|sendBeacon|WebSocket/.test(src));
  }
  check(
    `${name}: 추적·광고 코드 없음`,
    !/google-analytics|googletagmanager|gtag\(|adsbygoogle|doubleclick|facebook\.net|fbq\(|kakao_js_sdk|developers\.kakao|wcs\.naver|hotjar|clarity\.ms/i.test(src)
  );
}
const headers = path.join(site, "_headers");
check("_headers 있음", fs.existsSync(headers));
if (fs.existsSync(headers)) {
  const h = fs.readFileSync(headers, "utf8");
  check("CSP: 스크립트는 자기 사이트만", /script-src 'self'/.test(h));
  check("CSP: 외부 전송 차단", /connect-src 'none'/.test(h));
}

// ---------- 5. Netlify Drop용 폴더 ----------
const allowed = /\.(html|css|js|svg|png)$|^_headers$/;
const odd = allFiles.map(rel).filter((n) => !allowed.test(path.basename(n)));
check("site 폴더에 배포용 파일만 있음", odd.length === 0, odd.join(", "));

console.log(`\n${passed}개 통과, ${failed}개 실패`);
process.exit(failed ? 1 : 0);
