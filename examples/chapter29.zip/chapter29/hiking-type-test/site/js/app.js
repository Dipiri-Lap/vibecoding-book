/* 첫 화면 + 질문 진행 */
(function () {
  "use strict";
  var H = window.HIKING;
  var intro = document.getElementById("intro");
  var quiz = document.getElementById("quiz");
  var loading = document.getElementById("loading");
  var startBtn = document.getElementById("start");
  var backBtn = document.getElementById("back");
  var progressText = document.getElementById("progress-text");
  var progressBar = document.getElementById("progress-bar");
  var progressTrack = document.getElementById("progress-track");
  var questionEl = document.getElementById("question");
  var optionsEl = document.getElementById("options");

  var answers = [];
  var current = 0;
  var locked = false;

  function shuffled(list) {
    var a = list.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = a[i];
      a[i] = a[j];
      a[j] = tmp;
    }
    return a;
  }

  // 질문마다 보기 순서를 한 번만 섞어 둔다 (뒤로 가도 순서 유지)
  var orders = H.QUESTIONS.map(function (q) {
    return shuffled(q.options);
  });

  function show(screen) {
    [intro, quiz, loading].forEach(function (s) {
      s.hidden = s !== screen;
    });
    window.scrollTo(0, 0);
  }

  function render() {
    var total = H.QUESTIONS.length;
    var q = H.QUESTIONS[current];
    progressText.textContent = current + 1 + " / " + total;
    progressBar.style.width = ((current + 1) / total) * 100 + "%";
    progressTrack.setAttribute("aria-valuenow", String(current + 1));
    questionEl.textContent = "Q" + (current + 1) + ". " + q.q;
    backBtn.hidden = false;

    optionsEl.textContent = "";
    orders[current].forEach(function (opt) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "option";
      b.textContent = opt.text;
      b.setAttribute("data-type", opt.type);
      if (answers[current] === opt.type) b.classList.add("selected");
      b.addEventListener("click", function () {
        choose(opt.type, b);
      });
      optionsEl.appendChild(b);
    });
    questionEl.focus({ preventScroll: true });
    locked = false;
  }

  function choose(type, btn) {
    if (locked) return;
    locked = true;
    answers[current] = type;
    btn.classList.add("selected");
    setTimeout(function () {
      if (current < H.QUESTIONS.length - 1) {
        current++;
        render();
      } else {
        finish();
      }
    }, 220);
  }

  function finish() {
    show(loading);
    var result = H.computeResult(answers.slice(0, H.QUESTIONS.length));
    setTimeout(function () {
      window.location.href = "result/" + result + ".html#me";
    }, 700);
  }

  startBtn.addEventListener("click", function () {
    answers = [];
    current = 0;
    show(quiz);
    render();
  });

  backBtn.addEventListener("click", function () {
    if (current === 0) {
      show(intro);
      return;
    }
    current--;
    render();
  });

  // 뒤로 가기 캐시(bfcache)로 돌아왔을 때 로딩 화면에 멈춰 있지 않도록
  window.addEventListener("pageshow", function (e) {
    if (e.persisted) show(intro);
  });
})();
