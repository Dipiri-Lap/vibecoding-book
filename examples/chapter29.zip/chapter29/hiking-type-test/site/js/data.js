/* 나의 주말 등산 유형 테스트 — 질문·결과 데이터 (문구 수정은 이 파일에서) */
(function (root) {
  var SITE_URL = "https://hiking-type-test.netlify.app";

  var TYPES = {
    peak: {
      name: "새벽 정상 정복러",
      emoji: "⛰️",
      oneLiner: "정상석을 봐야 비로소 주말이 시작되는 사람",
      description:
        "남들이 이불 속에 있을 때 이미 산 중턱에 있는 타입이에요. 목표가 보이면 멈추지 않고, 땀 흘린 만큼 뿌듯함을 느껴요. 오늘의 기록이 다음 주의 동기부여가 됩니다.",
      tags: ["#새벽출발", "#정상인증", "#기록덕후"],
      tip: "가끔은 쉼터에서 5분 더 쉬어도 정상은 도망가지 않아요!",
      mate: "food",
      mateReason: "고생한 몸을 맛있게 챙겨 줘요",
      color: "#e8743b"
    },
    trail: {
      name: "느긋한 둘레길 산책러",
      emoji: "🌿",
      oneLiner: "오르는 것보다 머무는 게 좋은 사람",
      description:
        "정상은 꼭 가지 않아도 괜찮아요. 숲 냄새, 새소리, 발밑의 낙엽 같은 걸음마다의 순간을 즐겨요. 함께 걸으면 마음이 편해지는 사람입니다.",
      tags: ["#숲멍", "#보온병차", "#천천히"],
      tip: "오늘 걸은 길도 충분히 멋진 코스였어요.",
      mate: "photo",
      mateReason: "느린 걸음 덕분에 사진이 더 예뻐져요",
      color: "#3f8f5a"
    },
    food: {
      name: "하산 맛집 탐험가",
      emoji: "🍲",
      oneLiner: "등산은 거들 뿐, 진짜 목적지는 하산 식당",
      description:
        "산을 오르는 내내 머릿속엔 파전과 도토리묵이 있어요. 배낭엔 언제나 나눠 먹을 간식이 있어서, 함께 가는 사람들의 체력과 기분을 책임져요.",
      tags: ["#하산후파전", "#간식요정", "#맛집지도"],
      tip: "오늘 칼로리는 이미 산에서 다 태웠어요. 맘껏 드세요!",
      mate: "peak",
      mateReason: "배고픈 정복러에게 당신은 구세주",
      color: "#c9862b"
    },
    photo: {
      name: "인생샷 사냥꾼",
      emoji: "📸",
      oneLiner: "남는 건 사진, 정상은 거들 뿐인 배경",
      description:
        "같은 산도 당신이 찍으면 화보가 돼요. 빛이 좋은 시간, 구름이 예쁜 각도를 본능적으로 알아요. 덕분에 일행의 추억도 고화질로 남습니다.",
      tags: ["#인생샷", "#포토스팟", "#보조배터리필수"],
      tip: "오늘은 내 사진도 한 장 남겨 달라고 부탁해 보세요.",
      mate: "trail",
      mateReason: "천천히 걸어 주니 찍을 시간이 넉넉해요",
      color: "#5b6fd6"
    }
  };

  // 보기 순서는 화면에서 섞여서 보입니다. type = 이 보기를 고르면 점수가 가는 유형
  var QUESTIONS = [
    {
      q: "토요일 아침, 알람이 울렸다. 나는?",
      options: [
        { text: "새벽 5시. 이미 등산화 끈을 묶고 있다", type: "peak" },
        { text: "알람은 끄고 9시쯤 느긋하게 일어난다", type: "trail" },
        { text: "눈 뜨자마자 \"하산하고 뭐 먹지?\"부터 검색한다", type: "food" },
        { text: "창밖 하늘부터 본다. 오늘 사진 잘 나오겠는데?", type: "photo" }
      ]
    },
    {
      q: "배낭에 이것만은 꼭 챙긴다",
      options: [
        { text: "등산 스틱과 넉넉한 물", type: "peak" },
        { text: "돗자리와 따뜻한 차를 담은 보온병", type: "trail" },
        { text: "간식 한 봉지와 저장해 둔 맛집 목록", type: "food" },
        { text: "보조배터리와 셀카봉", type: "photo" }
      ]
    },
    {
      q: "코스를 고를 때 제일 먼저 보는 건?",
      options: [
        { text: "정상 높이와 난이도", type: "peak" },
        { text: "경사가 완만한지, 그늘이 많은지", type: "trail" },
        { text: "하산길 근처에 식당이 있는지", type: "food" },
        { text: "전망대와 포토스팟 후기", type: "photo" }
      ]
    },
    {
      q: "갈림길 표지판: '정상 1.2km (급경사)' vs '우회로 2.5km (완만)'",
      options: [
        { text: "고민할 것도 없이 급경사로 직진", type: "peak" },
        { text: "우회로로 숲 냄새 맡으며 천천히", type: "trail" },
        { text: "어느 쪽이 내려가는 식당가에 더 가깝지?", type: "food" },
        { text: "경치가 더 좋다는 쪽으로", type: "photo" }
      ]
    },
    {
      q: "중간 쉼터에 도착했다",
      options: [
        { text: "물 한 모금만 마시고 바로 출발", type: "peak" },
        { text: "벤치에 앉아 새소리를 듣는다", type: "trail" },
        { text: "싸 온 김밥과 과일을 꺼낸다", type: "food" },
        { text: "쉼터를 배경으로 일단 한 컷", type: "photo" }
      ]
    },
    {
      q: "드디어 정상! 제일 먼저 하는 일은?",
      options: [
        { text: "정상석을 손으로 탁 치고 기록 앱을 확인한다", type: "peak" },
        { text: "바람 맞으며 한참 멍하니 있는다", type: "trail" },
        { text: "하산해서 먹을 파전 생각에 벌써 설렌다", type: "food" },
        { text: "정상석 인증샷 줄에 선다", type: "photo" }
      ]
    },
    {
      q: "같이 간 친구가 숨을 헐떡인다",
      options: [
        { text: "\"거의 다 왔어!\" 옆에서 페이스메이커가 된다", type: "peak" },
        { text: "\"우리 좀 쉬었다 가자\" 같이 주저앉는다", type: "trail" },
        { text: "주머니에서 초콜릿을 꺼내 건넨다", type: "food" },
        { text: "\"이 표정도 추억이야\" 하고 찍어 준다", type: "photo" }
      ]
    },
    {
      q: "다음 날 단톡방에 올리는 건?",
      options: [
        { text: "거리·고도·시간이 찍힌 기록 캡처", type: "peak" },
        { text: "하늘 사진 한 장에 감성 한 줄", type: "trail" },
        { text: "하산 후 먹은 도토리묵과 막걸리 사진", type: "food" },
        { text: "보정까지 마친 인생샷 10장", type: "photo" }
      ]
    }
  ];

  /*
   * 결과 계산: 가장 많이 고른 유형.
   * 동점이면 동점 유형 중 '가장 마지막에 고른' 유형이 이깁니다.
   * answers: 유형 id 배열 (질문 순서대로)
   */
  function computeResult(answers) {
    var counts = {};
    var lastIndex = {};
    for (var i = 0; i < answers.length; i++) {
      var t = answers[i];
      counts[t] = (counts[t] || 0) + 1;
      lastIndex[t] = i;
    }
    var best = null;
    Object.keys(counts).forEach(function (t) {
      if (
        best === null ||
        counts[t] > counts[best] ||
        (counts[t] === counts[best] && lastIndex[t] > lastIndex[best])
      ) {
        best = t;
      }
    });
    return best;
  }

  root.HIKING = {
    SITE_URL: SITE_URL,
    TITLE: "나의 주말 등산 유형 테스트",
    MAIN_DESCRIPTION: "8개 질문으로 알아보는 나의 산행 스타일! 친구와 비교해 보세요",
    TYPES: TYPES,
    QUESTIONS: QUESTIONS,
    computeResult: computeResult
  };
})(typeof window !== "undefined" ? window : globalThis);
