/* 결과 화면: 공유하기 + 링크 복사 */
(function () {
  "use strict";
  var H = window.HIKING;
  var type = document.body.getAttribute("data-type");
  var info = H.TYPES[type];
  var shareUrl = H.SITE_URL + "/result/" + type + ".html";

  var kicker = document.getElementById("kicker");
  var restart = document.getElementById("restart");
  var shareBtn = document.getElementById("share");
  var copyBtn = document.getElementById("copy");
  var toast = document.getElementById("toast");
  var manual = document.getElementById("manual");

  // 테스트를 직접 끝내고 온 경우(#me)와 친구가 보낸 링크로 온 경우를 구분
  if (window.location.hash === "#me") {
    kicker.textContent = "나의 주말 등산 유형은";
    restart.textContent = "테스트 다시 하기";
    if (window.history && history.replaceState) {
      history.replaceState(null, "", window.location.pathname + window.location.search);
    }
  }

  var toastTimer = null;
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.remove("show");
    }, 2200);
  }

  function legacyCopy(text) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.top = "-1000px";
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try {
      ok = document.execCommand("copy");
    } catch (e) {
      ok = false;
    }
    document.body.removeChild(ta);
    return ok;
  }

  function copyLink() {
    function fail() {
      if (legacyCopy(shareUrl)) {
        showToast("링크를 복사했어요! 카톡에 붙여 넣어 보세요");
      } else {
        manual.hidden = false;
        manual.querySelector("span").textContent = shareUrl;
        showToast("아래 주소를 길게 눌러 복사해 주세요");
      }
    }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(shareUrl).then(function () {
        showToast("링크를 복사했어요! 카톡에 붙여 넣어 보세요");
      }, fail);
    } else {
      fail();
    }
  }

  if (navigator.share) {
    shareBtn.hidden = false;
    copyBtn.classList.remove("primary");
    copyBtn.classList.add("secondary");
    shareBtn.addEventListener("click", function () {
      navigator
        .share({
          title: "나는 '" + info.name + "' " + info.emoji,
          text: "나의 주말 등산 유형은 '" + info.name + "'! 너는 어떤 유형이야?",
          url: shareUrl
        })
        .catch(function (err) {
          // 사용자가 공유창을 닫은 경우(AbortError)는 조용히 무시
          if (!err || err.name !== "AbortError") copyLink();
        });
    });
  }

  copyBtn.addEventListener("click", copyLink);
})();
