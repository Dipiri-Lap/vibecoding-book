-- 등산 기록장: hike_logs 표 + 보안 규칙(RLS)
-- Supabase 대시보드 > SQL Editor 에 통째로 붙여 넣고 Run 하세요. (여러 번 실행해도 안전합니다)

create table if not exists public.hike_logs (
  id         uuid primary key default gen_random_uuid(),
  -- 기록 주인. 로그인한 사람의 id가 자동으로 들어갑니다.
  user_id    uuid not null default auth.uid() references auth.users (id) on delete cascade,
  hike_date  date not null,
  mountain   text not null check (char_length(mountain) between 1 and 100),
  companions text check (companions is null or char_length(companions) <= 200),
  memo       text check (memo is null or char_length(memo) <= 2000),
  created_at timestamptz not null default now()
);

create index if not exists hike_logs_user_date_idx
  on public.hike_logs (user_id, hike_date desc);

-- 보안 규칙 켜기 (force: 표 주인에게도 적용)
alter table public.hike_logs enable row level security;
alter table public.hike_logs force row level security;

-- 권한: 로그인 안 한 사람(anon)은 아무 권한 없음, 로그인한 사람만 사용 가능
revoke all on public.hike_logs from anon;
revoke all on public.hike_logs from authenticated;
grant select, insert, update, delete on public.hike_logs to authenticated;

-- 규칙: 내 기록(user_id = 내 id)만 보고, 넣고, 고치고, 지울 수 있음
drop policy if exists "hike_logs_select_own" on public.hike_logs;
drop policy if exists "hike_logs_insert_own" on public.hike_logs;
drop policy if exists "hike_logs_update_own" on public.hike_logs;
drop policy if exists "hike_logs_delete_own" on public.hike_logs;

create policy "hike_logs_select_own" on public.hike_logs
  for select to authenticated
  using ((select auth.uid()) = user_id);

create policy "hike_logs_insert_own" on public.hike_logs
  for insert to authenticated
  with check ((select auth.uid()) = user_id);

-- with check: 고친 뒤에도 내 기록이어야 함 (남에게 기록을 넘기거나 남 이름으로 바꾸기 불가)
create policy "hike_logs_update_own" on public.hike_logs
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy "hike_logs_delete_own" on public.hike_logs
  for delete to authenticated
  using ((select auth.uid()) = user_id);
