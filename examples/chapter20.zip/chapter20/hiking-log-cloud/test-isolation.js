// 보안 시험: 시험 계정 A, B 로 "남의 기록이 보이거나 바뀌는지" 실제 Supabase 에서 확인합니다.
// 사용법: node test-isolation.js   (먼저 setup.sql 을 SQL Editor 에서 실행해 두어야 함)
// .env 에서 값을 읽지만, 이메일/비밀번호/키는 화면에 출력하지 않습니다.
const path = require("path");

try {
  process.loadEnvFile(path.join(__dirname, ".env"));
} catch {
  console.error(".env 파일을 읽을 수 없습니다.");
  process.exit(1);
}
const E = process.env;
for (const k of ["SUPABASE_URL", "SUPABASE_ANON_KEY", "TEST_A_EMAIL", "TEST_A_PASSWORD", "TEST_B_EMAIL", "TEST_B_PASSWORD"]) {
  if (!E[k]) { console.error(`.env 에 ${k} 값이 없습니다.`); process.exit(1); }
}
const URL_ = E.SUPABASE_URL.replace(/\/+$/, "");
const KEY = E.SUPABASE_ANON_KEY;

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log("  통과  " + name); }
  else { fail++; console.log("  실패  " + name + (detail ? "  → " + detail : "")); }
}

async function signIn(label, email, password) {
  const r = await fetch(`${URL_}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: { apikey: KEY, "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.access_token) {
    console.error(`계정 ${label} 로그인 실패 (${r.status}). 계정/비밀번호/이메일 확인 상태를 점검하세요.`);
    process.exit(1);
  }
  return { token: j.access_token, id: j.user.id };
}

// 표 요청. token 이 없으면 로그인 안 한 사람(anon 키만 사용)
async function api(token, method, query, body) {
  const r = await fetch(`${URL_}/rest/v1/hike_logs${query || ""}`, {
    method,
    headers: {
      apikey: KEY,
      Authorization: `Bearer ${token || KEY}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await r.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: r.status, json };
}
const rows = (res) => (Array.isArray(res.json) ? res.json : []);
const denied = (res) => res.status >= 400 || rows(res).length === 0;

(async () => {
  const A = await signIn("A", E.TEST_A_EMAIL, E.TEST_A_PASSWORD);
  const B = await signIn("B", E.TEST_B_EMAIL, E.TEST_B_PASSWORD);
  check("두 시험 계정은 서로 다른 사람", A.id !== B.id);

  const tag = "TEST-" + Date.now();
  let aRowId, bRowId;

  try {
    console.log("\n[준비] 각자 기록 한 개씩 만들기");
    const a = await api(A.token, "POST", "", { hike_date: "2026-01-01", mountain: tag + "-A산", companions: "A친구", memo: "A비밀" });
    check("A가 자기 기록 추가", a.status === 201 && rows(a).length === 1, "상태 " + a.status);
    aRowId = rows(a)[0]?.id;
    check("서버가 기록 주인을 A로 자동 지정", rows(a)[0]?.user_id === A.id);
    const b = await api(B.token, "POST", "", { hike_date: "2026-01-02", mountain: tag + "-B산" });
    check("B가 자기 기록 추가", b.status === 201 && rows(b).length === 1, "상태 " + b.status);
    bRowId = rows(b)[0]?.id;
    if (!aRowId || !bRowId) throw new Error("준비 단계 실패 (setup.sql 을 실행했는지 확인하세요)");

    console.log("\n[보기] 남의 기록이 보이면 안 됨");
    const aList = await api(A.token, "GET", "?select=*");
    check("A의 목록에는 A 기록만 있음", rows(aList).length > 0 && rows(aList).every((r) => r.user_id === A.id));
    check("A는 B의 기록을 볼 수 없음", !rows(aList).some((r) => r.id === bRowId));
    const bList = await api(B.token, "GET", "?select=*");
    check("B의 목록에는 B 기록만 있음", rows(bList).length > 0 && rows(bList).every((r) => r.user_id === B.id));
    const bPeek = await api(B.token, "GET", `?id=eq.${aRowId}&select=*`);
    check("B가 A 기록 id를 정확히 지목해도 안 보임", rows(bPeek).length === 0);
    const bPeek2 = await api(B.token, "GET", `?user_id=eq.${A.id}&select=*`);
    check("B가 'A의 기록 달라'고 해도 안 보임", rows(bPeek2).length === 0);

    console.log("\n[고치기] 남의 기록을 바꾸면 안 됨");
    const bUpd = await api(B.token, "PATCH", `?id=eq.${aRowId}`, { memo: "B가 해킹" });
    check("B의 A 기록 수정은 아무 행도 못 바꿈", denied(bUpd), "상태 " + bUpd.status);
    const aCheck = await api(A.token, "GET", `?id=eq.${aRowId}&select=*`);
    check("A 기록 내용이 그대로", rows(aCheck)[0]?.memo === "A비밀");
    const bSteal = await api(B.token, "PATCH", `?id=eq.${bRowId}`, { user_id: A.id });
    check("B가 자기 기록의 주인을 A로 바꾸는 것도 거부", bSteal.status >= 400 || rows(bSteal).length === 0, "상태 " + bSteal.status);
    const bForge = await api(B.token, "POST", "", { user_id: A.id, hike_date: "2026-01-03", mountain: tag + "-위조" });
    check("B가 A 이름으로 기록을 만드는 것 거부", bForge.status >= 400, "상태 " + bForge.status);

    console.log("\n[지우기] 남의 기록을 지우면 안 됨");
    const bDel = await api(B.token, "DELETE", `?id=eq.${aRowId}`);
    check("B의 A 기록 삭제는 아무 행도 못 지움", denied(bDel), "상태 " + bDel.status);
    const aStill = await api(A.token, "GET", `?id=eq.${aRowId}&select=*`);
    check("A 기록이 아직 있음", rows(aStill).length === 1);

    console.log("\n[로그인 안 한 사람]");
    const nList = await api(null, "GET", "?select=*");
    check("목록 조회: 아무것도 안 보임", nList.status >= 400 || rows(nList).length === 0, "상태 " + nList.status);
    const nIns = await api(null, "POST", "", { hike_date: "2026-01-04", mountain: tag + "-익명" });
    check("기록 추가 거부", nIns.status >= 400, "상태 " + nIns.status);
    const nUpd = await api(null, "PATCH", `?id=eq.${aRowId}`, { memo: "익명 해킹" });
    check("기록 수정 거부", denied(nUpd), "상태 " + nUpd.status);
    const nDel = await api(null, "DELETE", `?id=eq.${aRowId}`);
    check("기록 삭제 거부", denied(nDel), "상태 " + nDel.status);
    const aFinal = await api(A.token, "GET", `?id=eq.${aRowId}&select=*`);
    check("A 기록이 끝까지 안전", rows(aFinal)[0]?.memo === "A비밀");

    console.log("\n[본인 기능 정상]");
    const aOwnUpd = await api(A.token, "PATCH", `?id=eq.${aRowId}`, { memo: "A가 수정" });
    check("A가 자기 기록 수정 가능", aOwnUpd.status === 200 && rows(aOwnUpd)[0]?.memo === "A가 수정");
  } catch (e) {
    fail++;
    console.log("  오류  " + e.message);
  } finally {
    // 시험 데이터 정리 (각자 자기 기록만 지움)
    for (const [who, id] of [[A, aRowId], [B, bRowId]]) {
      if (id) await api(who.token, "DELETE", `?id=eq.${id}`);
    }
    for (const who of [A, B]) {
      await api(who.token, "DELETE", `?mountain=like.${tag}*`);
    }
  }

  console.log(`\n결과: 통과 ${pass}개, 실패 ${fail}개`);
  process.exit(fail ? 1 : 0);
})();
