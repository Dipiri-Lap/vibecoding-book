// .env 의 SUPABASE_URL, SUPABASE_ANON_KEY 를 읽어 public/config.js 를 만듭니다.
// 사용법: node make-config.js
// (브라우저는 .env 를 직접 읽을 수 없어서, 공개해도 되는 두 값만 config.js 로 옮깁니다.)
const fs = require("fs");
const path = require("path");

try {
  process.loadEnvFile(path.join(__dirname, ".env"));
} catch {
  console.error(".env 파일을 읽을 수 없습니다.");
  process.exit(1);
}

const url = (process.env.SUPABASE_URL || "").trim();
const key = (process.env.SUPABASE_ANON_KEY || "").trim();
if (!url || !key) {
  console.error(".env 에 SUPABASE_URL 또는 SUPABASE_ANON_KEY 가 비어 있습니다.");
  process.exit(1);
}
// 관리자용 키가 실수로 들어간 경우 막기
if (/service_role|sb_secret_/.test(key)) {
  console.error("관리자용 키로 보입니다. 공개용(anon/publishable) 키만 사용하세요.");
  process.exit(1);
}

const body =
  "// make-config.js 가 자동으로 만든 파일입니다. (공개용 키만 들어 있음)\n" +
  "window.APP_CONFIG = " +
  JSON.stringify({ SUPABASE_URL: url, SUPABASE_ANON_KEY: key }, null, 2) +
  ";\n";
fs.writeFileSync(path.join(__dirname, "public", "config.js"), body, "utf8");
console.log("public/config.js 를 만들었습니다.");
