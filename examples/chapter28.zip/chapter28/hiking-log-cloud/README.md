# 등산 기록장 (hiking-log-cloud)

Supabase에 등산 기록을 저장하는 앱입니다.

## 폴더 설명

| 위치 | 설명 | 올려도 되나요? |
|---|---|---|
| `public/` | 브라우저에서 쓰는 파일 (`index.html`, `config.js`) | ✅ 이 폴더만 올립니다 |
| `.env` | 시험 계정 정보 등 비밀 값 | ❌ 절대 올리지 않습니다 |
| `setup.sql`, `make-config.js`, `test-isolation.js` | 내 컴퓨터에서만 쓰는 서버·시험용 파일 | ❌ 올리지 않습니다 |

## 올릴 때는 public 폴더만

Netlify Drop 같은 곳에 올릴 때는 **`public` 폴더만** 끌어다 놓으세요.
프로젝트 폴더 전체를 올리면 `.env`(비밀번호 포함)와 서버용 파일까지 공개됩니다.

## 사용 방법

1. `.env`에 `SUPABASE_URL`, `SUPABASE_ANON_KEY` 값을 넣습니다.
2. 설정 파일을 만듭니다. (`public/config.js`가 만들어집니다. 공개용 키만 들어갑니다.)

   ```bash
   node make-config.js
   ```

3. `public/index.html`을 열어 사용합니다.
4. 데이터 분리(계정별 접근 제한) 시험:

   ```bash
   node test-isolation.js
   ```
