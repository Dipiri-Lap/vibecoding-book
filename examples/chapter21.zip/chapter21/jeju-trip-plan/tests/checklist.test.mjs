// 휴대폰 크기 화면으로 site/index.html 의 준비물 체크를 확인한다. (완성 기준 5, 6)
// 실행: tests 폴더에서 `npm test`
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { chromium } from "playwright-core";
import { pathToFileURL, fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const pageUrl = pathToFileURL(path.join(here, "..", "site", "index.html")).href;

const phone = {
  viewport: { width: 375, height: 812 },
  deviceScaleFactor: 3,
  isMobile: true,
  hasTouch: true,
};

let browser;
before(async () => {
  browser = await chromium.launch({ channel: "chrome" });
});
after(async () => {
  await browser?.close();
});

// 새 "폰" 하나 = 저장 공간이 따로인 브라우저 컨텍스트 하나
async function newPhone(opts = {}) {
  const context = await browser.newContext(phone);
  if (opts.blockStorage) {
    await context.addInitScript(() => {
      Object.defineProperty(window, "localStorage", {
        get() { throw new DOMException("blocked", "SecurityError"); },
      });
    });
  }
  return context;
}
async function open(context) {
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto(pageUrl);
  await page.waitForSelector("#packing button");
  page.errors = errors;
  return page;
}
const items = (page) => page.locator('#packing [role="checkbox"]');
const states = (page) =>
  items(page).evaluateAll((bs) => bs.map((b) => b.getAttribute("aria-checked") === "true"));
const checkedLabels = (page) =>
  items(page).evaluateAll((bs) =>
    bs.filter((b) => b.getAttribute("aria-checked") === "true").map((b) => b.innerText.trim())
  );

test("준비물에 '한 명만 챙기면 되는 것'과 '개인' 두 묶음이 있고, 처음엔 모두 체크 안 돼 있다", async () => {
  const ctx = await newPhone();
  const page = await open(ctx);
  const headings = await page.locator("#packing h3").allInnerTexts();
  assert.equal(headings.length, 2);
  assert.equal(headings[0].trim(), "한 명만 챙기면 되는 것");
  assert.match(headings[1], /개인/);
  assert.equal((await page.locator("#packing .who").innerText()).trim(), "누가 챙길지는 단톡방에서 정해요");
  // 안내 줄은 '한 명만' 묶음 제목 바로 아래에 있다
  const order = await page.evaluate(() => {
    const h = [...document.querySelectorAll("#packing h3")][0];
    return h.nextElementSibling.className;
  });
  assert.equal(order, "who");
  assert.ok(
    (await page.locator("#pack-personal").innerText()).includes("핫팩"),
    "개인 준비물에 핫팩이 없다"
  );
  assert.ok((await page.locator("#pack-common button").count()) >= 3, "공통 항목이 너무 적다");
  assert.ok((await page.locator("#pack-personal button").count()) >= 3, "개인 항목이 너무 적다");
  assert.ok((await states(page)).every((s) => s === false), "처음부터 체크된 항목이 있다");
  assert.deepEqual(page.errors, []);
  await ctx.close();
});

test("기준 5: 항목을 누르면 체크되고, 다시 누르면 풀린다", async () => {
  const ctx = await newPhone();
  const page = await open(ctx);
  const first = items(page).nth(0);
  await first.tap();
  assert.equal(await first.getAttribute("aria-checked"), "true");
  await first.tap();
  assert.equal(await first.getAttribute("aria-checked"), "false");
  await ctx.close();
});

test("기준 5: 새로고침해도, 닫았다 다시 열어도 체크가 그대로 남는다", async () => {
  const ctx = await newPhone();
  let page = await open(ctx);
  const total = await items(page).count();
  const picks = [0, 2, total - 1]; // 공통 앞쪽, 공통 중간, 개인 마지막
  for (const i of picks) await items(page).nth(i).tap();
  const before = await states(page);
  assert.deepEqual(
    before.map((s, i) => (s ? i : -1)).filter((i) => i >= 0),
    picks
  );
  const labels = await checkedLabels(page);

  // 새로고침
  await page.reload();
  await page.waitForSelector("#packing button");
  assert.deepEqual(await states(page), before, "새로고침 뒤 체크가 달라졌다");

  // 탭(페이지)을 닫았다가 같은 폰에서 다시 열기
  await page.close();
  page = await open(ctx);
  assert.deepEqual(await states(page), before, "닫았다 열면 체크가 달라졌다");
  assert.deepEqual(await checkedLabels(page), labels);

  // 날짜 탭을 바꿔도 체크는 그대로
  await page.locator('[role="tab"]').nth(1).tap();
  assert.deepEqual(await states(page), before);
  await ctx.close();
});

test("기준 6: 내 폰에서 체크해도 다른 친구 폰의 체크는 바뀌지 않는다", async () => {
  const mine = await newPhone();
  const friend = await newPhone();
  const myPage = await open(mine);
  const friendPage = await open(friend);

  await myPage.locator('#packing [role="checkbox"]').nth(1).tap();
  await myPage.locator('#packing [role="checkbox"]').nth(4).tap();
  assert.equal((await checkedLabels(myPage)).length, 2);

  // 친구 폰: 열려 있던 화면도, 새로고침한 화면도, 새로 연 화면도 모두 그대로 비어 있어야 한다
  assert.ok((await states(friendPage)).every((s) => !s), "열려 있던 친구 화면이 바뀌었다");
  await friendPage.reload();
  await friendPage.waitForSelector("#packing button");
  assert.ok((await states(friendPage)).every((s) => !s), "친구 폰 새로고침 뒤 체크가 생겼다");

  // 친구가 자기 걸 체크해도 내 것은 그대로
  const mineBefore = await states(myPage);
  await friendPage.locator('#packing [role="checkbox"]').nth(0).tap();
  await myPage.reload();
  await myPage.waitForSelector("#packing button");
  assert.deepEqual(await states(myPage), mineBefore, "친구 체크가 내 폰에 들어왔다");
  await mine.close();
  await friend.close();
});

test("기준 6(구조): 체크 저장 때문에 외부로 나가는 요청이 없다", async () => {
  const ctx = await newPhone();
  const page = await ctx.newPage();
  const requests = [];
  page.on("request", (r) => requests.push(r.url()));
  await page.goto(pageUrl);
  await page.waitForSelector("#packing button");
  await items(page).nth(0).tap();
  await items(page).nth(3).tap();
  await page.reload();
  await page.waitForSelector("#packing button");
  const outside = requests.filter((u) => !u.startsWith("file://"));
  assert.deepEqual(outside, [], "외부 주소로 나가는 요청이 있다 (서버 저장 금지)");
  await ctx.close();
});

test("저장이 막힌 폰에서도 화면이 정상으로 나오고 오류가 없다", async () => {
  const ctx = await newPhone({ blockStorage: true });
  const page = await open(ctx);
  assert.ok((await items(page).count()) >= 6, "저장이 막히면 준비물이 안 보인다");
  assert.ok(await page.locator("table").isVisible(), "일정 표가 안 보인다");
  await items(page).nth(0).tap(); // 눌러도 오류가 나면 안 된다
  assert.equal(await items(page).nth(0).getAttribute("aria-checked"), "true");
  assert.deepEqual(page.errors, [], "저장이 막힌 폰에서 오류가 났다");
  await ctx.close();
});

test("준비물 영역: 글씨·버튼 크기가 충분하고 옆으로 밀리지 않는다", async () => {
  const ctx = await newPhone();
  const page = await open(ctx);
  const r = await page.evaluate(() => {
    const de = document.documentElement;
    const bs = [...document.querySelectorAll("#packing button")].map((b) => {
      const x = b.getBoundingClientRect();
      return { w: Math.round(x.width), h: Math.round(x.height), fs: parseFloat(getComputedStyle(b).fontSize) };
    });
    return { scrollW: de.scrollWidth, clientW: de.clientWidth, bs };
  });
  assert.ok(r.scrollW <= r.clientW, "옆으로 밀린다");
  for (const b of r.bs) {
    assert.ok(b.w >= 44 && b.h >= 44, `버튼이 작다 ${b.w}x${b.h}`);
    assert.ok(b.fs >= 16, `글씨가 작다 ${b.fs}px`);
  }
  await ctx.close();
});

test("개인정보 없음: 준비물 글에 전화번호 모양이 없다", async () => {
  const ctx = await newPhone();
  const page = await open(ctx);
  const text = await page.locator("#packing").innerText();
  assert.doesNotMatch(text, /0\d{1,2}-\d{3,4}-\d{4}/);
  await ctx.close();
});

// ----- '체크 모두 지우기' -----
async function checkSome(page) {
  for (const i of [0, 3, 8]) await items(page).nth(i).tap();
  assert.equal((await checkedLabels(page)).length, 3);
}

test("지우기: 확인 창에서 '취소'하면 체크가 그대로 남는다", async () => {
  const ctx = await newPhone();
  const page = await open(ctx);
  await checkSome(page);
  const before = await states(page);
  const messages = [];
  page.once("dialog", (d) => { messages.push(d.message()); d.dismiss(); });
  await page.locator("#clear-checks").tap();
  assert.equal(messages.length, 1, "확인 창이 뜨지 않았다");
  assert.match(messages[0], /정말 지울까요\?/);
  assert.deepEqual(await states(page), before);
  await page.reload();
  await page.waitForSelector("#packing button");
  assert.deepEqual(await states(page), before, "취소했는데 새로고침 뒤 체크가 사라졌다");
  await ctx.close();
});

test("지우기: 확인 창에서 '확인'하면 모두 지워지고, 새로고침해도 비어 있다", async () => {
  const ctx = await newPhone();
  const page = await open(ctx);
  await checkSome(page);
  page.once("dialog", (d) => d.accept());
  await page.locator("#clear-checks").tap();
  assert.ok((await states(page)).every((s) => !s), "지웠는데 체크가 남아 있다");
  await page.reload();
  await page.waitForSelector("#packing button");
  assert.ok((await states(page)).every((s) => !s), "새로고침 뒤 체크가 되살아났다");
  // 지운 뒤 다시 체크해도 정상
  await items(page).nth(1).tap();
  assert.equal((await checkedLabels(page)).length, 1);
  await ctx.close();
});

test("지우기: 내 폰에서 지워도 친구 폰의 체크는 그대로다", async () => {
  const mine = await newPhone();
  const friend = await newPhone();
  const myPage = await open(mine);
  const friendPage = await open(friend);
  await checkSome(myPage);
  await checkSome(friendPage);
  const friendBefore = await states(friendPage);
  myPage.once("dialog", (d) => d.accept());
  await myPage.locator("#clear-checks").tap();
  await friendPage.reload();
  await friendPage.waitForSelector("#packing button");
  assert.deepEqual(await states(friendPage), friendBefore);
  await mine.close();
  await friend.close();
});

test("지우기: 버튼이 보이고 누르기 편한 크기이며, 저장이 막힌 폰에서도 오류가 없다", async () => {
  const ctx = await newPhone({ blockStorage: true });
  const page = await open(ctx);
  const box = await page.locator("#clear-checks").boundingBox();
  assert.ok(box.width >= 44 && box.height >= 44, `버튼이 작다 ${box.width}x${box.height}`);
  assert.equal((await page.locator("#clear-checks").innerText()).trim(), "체크 모두 지우기");
  await items(page).nth(0).tap();
  page.once("dialog", (d) => d.accept());
  await page.locator("#clear-checks").tap();
  assert.ok((await states(page)).every((s) => !s));
  assert.deepEqual(page.errors, []);
  await ctx.close();
});
