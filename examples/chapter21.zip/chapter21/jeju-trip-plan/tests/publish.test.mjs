// 4단계 확인: 링크 미리보기 태그의 주소, 이미지 크기, site 폴더에 올릴 파일만 있는지
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const siteDir = path.join(here, "..", "site");
const html = fs.readFileSync(path.join(siteDir, "index.html"), "utf8");
const BASE = "https://jeju-trip-plan.netlify.app/";

const meta = (attr, name) => {
  const m = html.match(new RegExp(`<meta\\s+${attr}="${name}"\\s+content="([^"]*)"`));
  return m ? m[1] : undefined;
};

test("미리보기 태그: 제목·설명·주소·이미지가 모두 있다", () => {
  for (const k of ["og:title", "og:description", "og:url", "og:image"]) {
    assert.ok(meta("property", k), `${k} 태그가 없다`);
  }
  assert.ok(meta("name", "description"), "description 태그가 없다");
  assert.equal(meta("property", "og:title"), "제주 2박 3일");
});

test("미리보기 태그: og:url과 og:image는 정해 둔 사이트 주소로 시작하는 전체 주소다", () => {
  assert.equal(meta("property", "og:url"), BASE);
  const img = meta("property", "og:image");
  assert.ok(img.startsWith(BASE), `og:image가 ${BASE}로 시작하지 않는다: ${img}`);
});

test("미리보기 이미지: og:image가 가리키는 파일이 site에 있고 1200x630 PNG다", () => {
  const img = meta("property", "og:image");
  const file = path.join(siteDir, img.slice(BASE.length));
  assert.ok(fs.existsSync(file), `site 폴더에 ${img.slice(BASE.length)} 파일이 없다`);
  const buf = fs.readFileSync(file);
  assert.equal(buf.subarray(1, 4).toString("ascii"), "PNG", "PNG 파일이 아니다");
  const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
  assert.deepEqual([w, h], [1200, 630], `이미지 크기가 ${w}x${h}`);
  assert.equal(meta("property", "og:image:width"), "1200");
  assert.equal(meta("property", "og:image:height"), "630");
  assert.ok(buf.length < 1024 * 1024, "이미지가 1MB보다 크다");
  console.log(`  ${path.basename(file)}: ${w}x${h}, ${buf.length} bytes`);
});

test("site 폴더에는 올릴 파일(index.html, preview.png)만 있다", () => {
  const list = fs.readdirSync(siteDir, { recursive: true }).sort();
  console.log("  site 폴더:", list.join(", "));
  assert.deepEqual(list, ["index.html", "preview.png"]);
});

test("미리보기 글에 전화번호 모양·이메일이 없다", () => {
  const heads = html.slice(0, html.indexOf("</head>"));
  assert.ok(!/\d{2,4}-\d{3,4}-\d{4}/.test(heads), "전화번호 모양이 있다");
  assert.ok(!/@/.test(heads), "@ 문자가 있다");
});

test("고친 문구: 고기국수 메모는 바뀌었고, '일정은 초안이에요'는 없다", () => {
  assert.ok(html.includes("식당은 당일 줄 보고 정해요"));
  assert.ok(!html.includes("식당은 정해서 고치기"));
  assert.ok(!html.includes("일정은 초안이에요"));
});
