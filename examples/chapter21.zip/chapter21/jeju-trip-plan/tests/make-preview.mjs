// 링크 미리보기 이미지(1200x630 PNG)를 만든다. 외부 그림·서비스 없이 페이지 색과 글자만 쓴다.
// 실행: tests 폴더에서 `node make-preview.mjs`  →  ../site/preview.png
import { chromium } from "playwright-core";
import { fileURLToPath } from "node:url";
import path from "node:path";

const out = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "site", "preview.png");

const html = `<!doctype html><meta charset="utf-8"><style>
  * { box-sizing: border-box; margin: 0; }
  body { width: 1200px; height: 630px; background: #0b7285; color: #fff;
    font-family: "Malgun Gothic", "Apple SD Gothic Neo", "Noto Sans KR", sans-serif;
    padding: 70px 80px; display: flex; flex-direction: column; justify-content: center; }
  h1 { font-size: 120px; line-height: 1.2; font-weight: 800; }
  .dates { font-size: 54px; margin-top: 16px; }
  .row { display: flex; gap: 24px; margin-top: 48px; }
  .chip { background: #d3eef3; color: #08515f; border-radius: 20px; padding: 18px 32px; font-size: 40px; font-weight: 700; }
</style>
<h1>제주 2박 3일</h1>
<div class="dates">12월 4일(금) ~ 6일(일)</div>
<div class="row">
  <div class="chip">일정</div>
  <div class="chip">지도</div>
  <div class="chip">준비물 체크</div>
</div>`;

const browser = await chromium.launch({ channel: "chrome" });
const page = await browser.newPage({ viewport: { width: 1200, height: 630 }, deviceScaleFactor: 1 });
await page.setContent(html);
await page.screenshot({ path: out, type: "png", clip: { x: 0, y: 0, width: 1200, height: 630 } });
await browser.close();
console.log("만들었어요:", out);
