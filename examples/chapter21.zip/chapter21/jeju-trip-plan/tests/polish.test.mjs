// 3단계 확인: 완성 기준 4(지도 열기), 7(개인정보 없음), 8(글씨·버튼 크기, 옆으로 안 밀림 — 지도 버튼 포함)
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { chromium } from "playwright-core";
import { pathToFileURL, fileURLToPath } from "node:url";
import path from "node:path";
import fs from "node:fs";

const here = path.dirname(fileURLToPath(import.meta.url));
const htmlPath = path.join(here, "..", "site", "index.html");
const pageUrl = pathToFileURL(htmlPath).href;

let browser, context, page;

before(async () => {
  browser = await chromium.launch({ channel: "chrome" });
  context = await browser.newContext({
    viewport: { width: 375, height: 812 },
    deviceScaleFactor: 3,
    isMobile: true,
    hasTouch: true,
  });
  // 지도 사이트로 진짜 나가지 않게 막고, 어디로 가려는지만 기록한다.
  await context.route(/^https?:\/\//, (route) => route.fulfill({ status: 200, contentType: "text/html", body: "<title>map</title>" }));
  page = await context.newPage();
  await page.goto(pageUrl);
  await page.waitForSelector("table");
});

after(async () => {
  await browser?.close();
});

const tabs = () => page.locator('[role="tab"]');
const rows = () => page.locator("tbody tr");

async function eachDay(fn) {
  for (let i = 0; i < 3; i++) {
    await tabs().nth(i).tap();
    await fn(i);
  }
}

test("기준 4: 장소 옆 '지도 열기'를 누르면 지도에서 그 장소 검색이 열린다", async () => {
  let total = 0;
  await eachDay(async (i) => {
    const info = await rows().evaluateAll((trs) =>
      trs.map((tr) => {
        const a = tr.cells[1].querySelector("a");
        return { place: tr.cells[1].childNodes[0].textContent.trim(), text: a?.textContent.trim(), href: a?.href, target: a?.target };
      })
    );
    for (const r of info) {
      if (r.place.includes("숙소")) {
        assert.equal(r.href, undefined, `${i + 1}일차 숙소에는 지도 버튼이 없어야 한다(주소 보호)`);
        continue;
      }
      assert.equal(r.text, "지도 열기", `${i + 1}일차 '${r.place}'에 지도 열기 버튼이 없다`);
      const u = new URL(r.href);
      assert.equal(u.origin + u.pathname, "https://www.google.com/maps/search/");
      assert.equal(u.searchParams.get("api"), "1");
      const q = u.searchParams.get("query");
      assert.ok(q && q.length >= 3, `검색어가 비었다: ${r.place}`);
      assert.ok(q.startsWith("제주 "), `검색어에 '제주'가 없다: ${q}`);
      total++;
    }
    console.log(`  ${i + 1}일차: 지도 버튼 ${info.filter((r) => r.href).length}개 / 칸 ${info.length}개`);
  });
  assert.ok(total >= 15, `지도 버튼이 너무 적다 (${total})`);

  // 실제로 눌러 본다: 1일차 '협재해수욕장' 칸
  await tabs().nth(0).tap();
  const row = rows().filter({ hasText: "협재해수욕장" }).first();
  const [popup] = await Promise.all([context.waitForEvent("page"), row.locator("a.map").tap()]);
  const url = new URL(popup.url());
  assert.equal(url.hostname, "www.google.com");
  assert.equal(url.searchParams.get("query"), "제주 협재해수욕장");
  console.log("  눌렀더니 열린 주소:", popup.url());
  await popup.close();

  // 고기국수 식당도 지도로 열린다
  await tabs().nth(2).tap();
  const noodle = rows().filter({ hasText: "고기국수" }).first();
  assert.match((await noodle.locator("a.map").getAttribute("href")) ?? "", /%EA%B3%A0%EA%B8%B0%EA%B5%AD%EC%88%98/);
});

test("기준 7: 페이지 어디에도 전화번호·숙소 주소·이름이 없다", async () => {
  const source = fs.readFileSync(htmlPath, "utf8");
  const texts = [];
  const hrefs = [];
  await eachDay(async () => {
    texts.push(await page.evaluate(() => document.body.innerText));
    hrefs.push(...(await page.$$eval("a", (as) => as.map((a) => decodeURIComponent(a.href)))));
  });
  const all = texts.join("\n") + "\n" + hrefs.join("\n");

  // 전화번호 (휴대폰, 지역번호, 국가번호, 붙여 쓴 번호)
  const phone = [/0\d{1,2}[-.\s]?\d{3,4}[-.\s]?\d{4}/, /\+82/, /\b\d{3,4}-\d{4}\b/, /tel:/i, /\b01[016789]\d{7,8}\b/];
  for (const re of phone) {
    assert.doesNotMatch(all, re, `화면에 전화번호 모양: ${re}`);
    assert.doesNotMatch(source, re, `파일에 전화번호 모양: ${re}`);
  }
  // 정확한 주소 (도로명·번지·호수·상세주소)
  const addr = [/[가-힣0-9]+(로|길)\s?\d+(-\d+)?(?![가-힣]*\d*일)/, /\d+번지/, /\d+동\s?\d+호/, /제주특별자치도|제주시\s[가-힣]+(읍|면|동)\s?\d/, /\d{5}\b/];
  for (const re of addr) {
    const m = all.match(re);
    assert.equal(m, null, `주소 모양 발견: ${m?.[0]}`);
  }
  // 숙소는 '애월 숙소'처럼 동네 이름만, 지도 링크 없음
  assert.ok(!hrefs.some((h) => h.includes("숙소")), "숙소가 지도 검색어에 들어 있다");
  assert.match(all, /숙소 주소는 단톡방 참고/);
  // 예약번호/이메일 모양
  assert.doesNotMatch(all, /[\w.-]+@[\w-]+\.\w+/, "이메일 모양");
  assert.doesNotMatch(source, /[\w.-]+@[\w-]+\.\w+/, "파일 안 이메일 모양");
  assert.doesNotMatch(source, /예약번호\s*[:：]?\s*\w{4,}/, "예약번호 모양");
});

test("기준 8: 지도 버튼 포함 — 글씨 14px 이상, 버튼 44px 이상, 옆으로 안 밀림 (3일 모두)", async () => {
  await eachDay(async (i) => {
    const r = await page.evaluate(() => {
      const de = document.documentElement;
      const small = [];
      let minSize = Infinity;
      const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (w.nextNode()) {
        const n = w.currentNode;
        if (!n.textContent.trim() || n.parentElement.closest("script,style")) continue;
        const fs = parseFloat(getComputedStyle(n.parentElement).fontSize);
        minSize = Math.min(minSize, fs);
        if (fs < 14) small.push(n.textContent.trim().slice(0, 12) + "(" + fs + "px)");
      }
      const over = [];
      document.querySelectorAll("body *").forEach((e) => {
        const b = e.getBoundingClientRect();
        if (b.width && b.right > de.clientWidth + 0.5) over.push(e.tagName + ":" + e.textContent.trim().slice(0, 10));
      });
      const targets = [...document.querySelectorAll("button, a")].map((e) => {
        const b = e.getBoundingClientRect();
        return { kind: e.tagName, w: Math.round(b.width), h: Math.round(b.height), text: e.textContent.trim().slice(0, 8) };
      });
      // 눌러야 하는 것끼리 겹치거나 너무 붙어 있지 않은가 (위아래 간격 4px 이상)
      const links = [...document.querySelectorAll("a")].map((e) => e.getBoundingClientRect());
      let tight = 0;
      for (let a = 0; a < links.length; a++)
        for (let b = a + 1; b < links.length; b++) {
          const gapY = Math.max(links[a].top - links[b].bottom, links[b].top - links[a].bottom);
          const overlapX = Math.min(links[a].right, links[b].right) - Math.max(links[a].left, links[b].left);
          if (overlapX > 0 && gapY < 4) tight++;
        }
      return { scrollW: de.scrollWidth, clientW: de.clientWidth, minSize, small, over, targets, tight };
    });
    const label = `${i + 1}일차`;
    assert.ok(r.scrollW <= r.clientW, `${label}: 옆으로 밀림 ${r.scrollW} > ${r.clientW}`);
    assert.deepEqual(r.over, [], `${label}: 화면 밖으로 나감`);
    assert.deepEqual(r.small, [], `${label}: 작은 글씨`);
    const links = r.targets.filter((t) => t.kind === "A");
    assert.ok(links.length >= 5, `${label}: 지도 버튼이 보이지 않는다`);
    for (const t of r.targets) assert.ok(t.w >= 44 && t.h >= 44, `${label}: ${t.kind} '${t.text}' 가 작다 ${t.w}x${t.h}`);
    assert.equal(r.tight, 0, `${label}: 지도 버튼끼리 너무 붙어 있다`);
    console.log(`  ${label}: 가장 작은 글씨 ${r.minSize}px, 지도 버튼 ${links.length}개 (가장 작은 것 ${Math.min(...links.map((t) => t.w))}x${Math.min(...links.map((t) => t.h))}px)`);
  });
});

test("덤: 지도 버튼을 누르기 전에는 외부 요청이 없다 (기준 9 보호)", async () => {
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const p = await ctx.newPage();
  const outside = [];
  p.on("request", (r) => { if (!r.url().startsWith("file://")) outside.push(r.url()); });
  await p.goto(pageUrl);
  await p.waitForSelector("table");
  assert.deepEqual(outside, []);
  await ctx.close();
});
