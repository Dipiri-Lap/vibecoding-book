// 휴대폰 크기 화면(375x812, 터치)으로 site/index.html 을 열어 완성 기준 1, 2, 3, 8을 확인한다.
// 실행: tests 폴더에서 `npm test`
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { chromium } from "playwright-core";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const pageUrl = pathToFileURL(path.join(here, "..", "site", "index.html")).href;

let browser, context, page, requests;

before(async () => {
  browser = await chromium.launch({ channel: "chrome" }); // 이 컴퓨터의 Chrome 사용
  context = await browser.newContext({
    viewport: { width: 375, height: 812 },
    deviceScaleFactor: 3,
    isMobile: true,
    hasTouch: true,
  });
  page = await context.newPage();
  requests = [];
  page.on("request", (r) => requests.push(r.url()));
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto(pageUrl);
  await page.waitForSelector("table");
  assert.deepEqual(errors, [], "페이지 안에서 오류가 나면 안 된다");
});

after(async () => {
  await browser?.close();
});

const tabs = () => page.locator('[role="tab"]');
const rows = () => page.locator("tbody tr");
const toMin = (t) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

test("기준 1: 맨 위에 12월 4일~6일과 비행기 시간이 보인다", async () => {
  const header = page.locator("header");
  assert.ok(await header.isVisible());
  const text = await header.innerText();
  assert.match(text, /12월 4일/);
  assert.match(text, /6일/);
  assert.match(text, /김포 → 제주\s*08:10/);
  assert.match(text, /제주 → 김포\s*18:40/);
  // 첫 화면(스크롤 없이)에 들어와 있는가
  const box = await header.boundingBox();
  assert.ok(box.y >= 0 && box.y + box.height <= 812, "맨 위 요약이 첫 화면 안에 있어야 한다");
});

test("기준 2: 탭 3개를 누르면 그날 일정이 시간순으로 바뀐다", async () => {
  assert.equal(await tabs().count(), 3);
  const seen = [];
  for (let i = 0; i < 3; i++) {
    await tabs().nth(i).tap();
    await expect_selected(i);
    const title = await page.locator(".day-title").innerText();
    assert.match(title, new RegExp(`${i + 1}일차`));
    const times = await rows().evaluateAll((trs) => trs.map((tr) => tr.cells[0].innerText.trim()));
    assert.ok(times.length >= 5, `${i + 1}일차 일정이 너무 적다`);
    const mins = times.map(toMin);
    assert.deepEqual(mins, [...mins].sort((a, b) => a - b), `${i + 1}일차가 시간순이 아니다: ${times}`);
    // 다른 날 내용이 같이 보이면 안 된다 (표는 한 개만)
    assert.equal(await page.locator("table").count(), 1);
    seen.push((await rows().allInnerTexts()).join("|"));
  }
  assert.equal(new Set(seen).size, 3, "탭마다 일정 내용이 달라야 한다");
  // 다시 1일차로 돌아와도 되는가
  await tabs().nth(0).tap();
  await expect_selected(0);
});

async function expect_selected(i) {
  const flags = await tabs().evaluateAll((bs) => bs.map((b) => b.getAttribute("aria-selected")));
  assert.deepEqual(flags, [0, 1, 2].map((k) => (k === i ? "true" : "false")));
}

test("기준 3: 일정 중 한 곳에 고기국수 식당이 있다", async () => {
  let found = [];
  for (let i = 0; i < 3; i++) {
    await tabs().nth(i).tap();
    const hit = await rows().evaluateAll((trs) =>
      trs.filter((tr) => tr.innerText.includes("고기국수")).map((tr) => tr.innerText.replace(/\s+/g, " "))
    );
    found.push(...hit.map((h) => `${i + 1}일차: ${h}`));
  }
  assert.ok(found.length >= 1, "고기국수가 일정에 없다");
  console.log("  고기국수 칸:", found.join(" / "));
});

test("기준 8: 글씨가 작지 않고, 옆으로 밀리지 않고, 누르기 편하다", async () => {
  assert.ok(await page.locator('meta[name="viewport"]').count(), "viewport 설정이 없다");
  for (let i = 0; i < 3; i++) {
    await tabs().nth(i).tap();
    const r = await page.evaluate(() => {
      const de = document.documentElement;
      // 글자가 들어 있는 모든 보이는 요소의 글씨 크기
      const small = [];
      let minSize = Infinity;
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const n = walker.currentNode;
        if (!n.textContent.trim()) continue;
        const el = n.parentElement;
        if (el.closest("script,style")) continue;
        const fs = parseFloat(getComputedStyle(el).fontSize);
        minSize = Math.min(minSize, fs);
        if (fs < 14) small.push(`${el.tagName}:${n.textContent.trim().slice(0, 12)}(${fs}px)`);
      }
      // 화면 오른쪽 밖으로 나간 요소
      const over = [];
      document.querySelectorAll("body *").forEach((e) => {
        const b = e.getBoundingClientRect();
        if (b.width && b.right > de.clientWidth + 0.5) over.push(e.tagName + ":" + e.textContent.trim().slice(0, 10));
      });
      const tapSizes = [...document.querySelectorAll("button")].map((b) => {
        const r = b.getBoundingClientRect();
        return { w: Math.round(r.width), h: Math.round(r.height) };
      });
      const bodyFs = parseFloat(getComputedStyle(document.body).fontSize);
      return {
        scrollW: de.scrollWidth, clientW: de.clientWidth, minSize, small, over, tapSizes, bodyFs,
        tableW: document.querySelector("table").getBoundingClientRect().width,
      };
    });
    const label = `${i + 1}일차`;
    assert.ok(r.scrollW <= r.clientW, `${label}: 옆으로 밀림 (scrollWidth ${r.scrollW} > ${r.clientW})`);
    assert.deepEqual(r.over, [], `${label}: 화면 밖으로 나간 요소`);
    assert.ok(r.bodyFs >= 16, `${label}: 본문 글씨 ${r.bodyFs}px (16px 이상이어야 함)`);
    assert.deepEqual(r.small, [], `${label}: 14px보다 작은 글씨`);
    for (const t of r.tapSizes) assert.ok(t.w >= 44 && t.h >= 44, `${label}: 버튼이 작다 ${t.w}x${t.h}px (44px 이상)`);
    console.log(`  ${label}: 가장 작은 글씨 ${r.minSize}px, 본문 ${r.bodyFs}px, 버튼 ${r.tapSizes.map((t) => t.w + "x" + t.h).join(", ")}, 표 너비 ${Math.round(r.tableW)}px / 화면 ${r.clientW}px`);
  }
});

test("덤(기준 9 일부): 외부로 나가는 요청이 없다", async () => {
  const outside = requests.filter((u) => !u.startsWith("file://"));
  assert.deepEqual(outside, [], "외부 주소 요청 발견");
});

test("덤(기준 7 일부): 페이지 글에 전화번호 모양이 없다", async () => {
  const text = await page.evaluate(() => document.body.innerText);
  assert.doesNotMatch(text, /0\d{1,2}-\d{3,4}-\d{4}/);
});
